Page 58023 "Telematel Currency"
{
    //P_58023_Telematel_Currency
    ApplicationArea = all;
    UsageCategory = Lists;
    CaptionML = ENU = 'Telematel Currency', ESP = 'Telematel Divisas';
    SourceTable = "Telematel Currency";
    PageType = List;

    layout
    {
        area(Content)
        {
            repeater(Repeater)
            {
                field("Code Telematel"; Rec."Code Telematel")
                {
                    ApplicationArea = All;
                    Style = Strong;
                    StyleExpr = Rec."Local Currency";
                    ToolTip = 'Specifies the value of the Code Telematel field.';
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = All;
                    Style = Strong;
                    StyleExpr = Rec."Local Currency";
                    ToolTip = 'Specifies the value of the Description field.';
                }
                field("Currency Code"; Rec."Currency Code")
                {
                    ApplicationArea = All;
                    Style = Strong;
                    StyleExpr = Rec."Local Currency";
                    ToolTip = 'Specifies the value of the Currency Code field.';
                }
                field("Nav Description"; Rec."Nav Description")
                {
                    ApplicationArea = All;
                    Style = Strong;
                    StyleExpr = Rec."Local Currency";
                    ToolTip = 'Specifies the value of the Nav Description field.';
                }
                field("Local Currency"; Rec."Local Currency")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Local Currency field.';
                }
            }
        }
    }
    actions
    {
        area(Processing)
        {
            // action(ActionName)
            // {
            //     Visible = false;
            //     ApplicationArea = All;
            //     ShortCutKey = 'Ctrl+A';
            //     CaptionML = ESP = 'Importar XML', ESM = 'Importar XML';
            //     RunObject = XMLport "Imp Divisas GoCatalog";
            //     Promoted = true;
            //     Image = XMLFile;
            //     PromotedCategory = Process;
            //     trigger OnAction()
            //     var
            //     //LText00001@1000000000 : TextConst 'ESP=Funci¢n completada;ESM=Funci¢n completada';
            //     begin
            //     end;
            // }
        }
        area(Navigation)
        {
            action(Info)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Info';
                Image = Web;
                ToolTip = 'Executes the Info action.';

                trigger OnAction()
                begin
                    HYPERLINK('https://www.iso.org/iso-4217-currency-codes.html');
                end;
            }
        }
    }
}
