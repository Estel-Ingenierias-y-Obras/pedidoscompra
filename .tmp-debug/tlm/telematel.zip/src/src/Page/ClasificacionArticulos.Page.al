page 58009 "Clasificacion Articulos"
{
    Editable = false;
    SourceTable = "Clasificacion Articulos";
    PopulateAllFields = true;
    PageType = List;
    RefreshOnActivate = true;

    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field("Id Articulo"; Rec."Id Articulo")
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Id Articulo field.';
                }
                field("Codigo Clasificacion"; Rec."Codigo Clasificacion")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Código Clasificación field.';
                }
                field("Desc.Codigo Clasificacion"; Rec."Desc.Codigo Clasificacion")
                {
                    ApplicationArea = All;
                    Lookup = false;
                    DrillDown = false;
                    ToolTip = 'Specifies the value of the Desc.Codigo Clasificacion field.';
                }
                field("Nivel 1"; Rec."Nivel 1")
                {
                    ApplicationArea = All;
                    AssistEdit = true;
                    ToolTip = 'Specifies the value of the Nivel 1 field.';

                    trigger OnAssistEdit()
                    var
                    begin
                        DoLookup(1);
                    end;
                }
                field("Nivel 2"; Rec."Nivel 2")
                {
                    ApplicationArea = All;
                    AssistEdit = true;
                    ToolTip = 'Specifies the value of the Nivel 2 field.';

                    trigger OnAssistEdit()
                    var
                    begin
                        DoLookup(2);
                    end;
                }
                field("Nivel 3"; Rec."Nivel 3")
                {
                    ApplicationArea = All;
                    AssistEdit = true;
                    ToolTip = 'Specifies the value of the Nivel 3 field.';

                    trigger OnAssistEdit()
                    var
                    begin
                        DoLookup(3);
                    end;
                }
            }
        }
    }
    LOCAL PROCEDURE DoLookup(pwLevel: Integer);
    BEGIN
        Rec.LookupLevel(pwLevel);
        CurrPage.UPDATE();
    END;
}
