page 58005 "Telematel Articulos"
{
    SourceTable = "Telematel Articulos";
    PopulateAllFields = true;
    PageType = List;
    RefreshOnActivate = true;
    PromotedActionCategoriesML = ESP = 'Nuevo, Acciones, Reports, Navegar, Clasificaciones';
    Editable = true;
    //
    ApplicationArea = All;
    UsageCategory = Lists;
    Caption = 'Telematel Articulos';

    //
    layout
    {
        area(Content)
        {
            field(GetFiltroCodClassText; Rec.GetFiltroCodClassText())
            {
                ShowCaption = false;
                ApplicationArea = All;
                Style = Standard;
                StyleExpr = TRUE;
                ColumnSpan = 2;

                trigger OnLookup(var Text: Text): Boolean
                begin
                    CambiaTipoClasificacion();
                end;
            }
            field(FGetClassFullTextPg; GetClassFullTextPg())
            {
                ShowCaption = false;
                ApplicationArea = All;
                Width = 2000;
                Editable = false;
                Style = StandardAccent;
                StyleExpr = TRUE;
                RowSpan = 2;
                ColumnSpan = 4;

                //Image = folder;
                trigger OnLookup(var Text: Text): Boolean
                var
                begin
                    GetFiltrosClass2();
                end;

                trigger OnAssistEdit()
                var
                begin
                    GetFiltrosClass2();
                end;
            }
            group(FiltrosClasificacion)
            {
                CaptionML = ESP = 'Filtros Clasificación';

                grid(FC)
                {
                    GridLayout = Rows;
                    Caption = 'FC';

                    group(TiposDeClasificacion)
                    {
                        CaptionML = ESP = 'Tipo de Clasificación';

                        field(FGetFiltroCodClassText; Rec.GetFiltroCodClassText())
                        {
                            ApplicationArea = All;
                            CaptionML = ESP = 'Tipo de Clasificación';
                            ColumnSpan = 3;
                            ShowCaption = false;

                            trigger OnAssistEdit()
                            begin
                                CambiaTipoClasificacion();
                            end;
                        }
                    }
                    group(Clasificacion1)
                    {
                        CaptionML = ESP = 'Clasificacion 1';

                        field(GetFiltroClassId; Rec.GetFiltroClassId(1))
                        {
                            ApplicationArea = All;
                            AssistEdit = true;
                            BlankZero = true;
                            ShowCaption = false;

                            trigger OnValidate()
                            var
                            begin
                                FindLevelPg(1, Rec.GetFiltroClassId(1));
                            end;

                            trigger OnAssistEdit()
                            var
                            begin
                                GetFiltrosClass();
                            end;
                        }
                        field(GetFiltroClass; Rec.GetFiltroClass(1))
                        {
                            ApplicationArea = All;
                            Importance = Promoted;
                            Editable = false;
                            ColumnSpan = 4;
                            ShowCaption = false;
                        }
                    }
                    group(Clasificacion2)
                    {
                        CaptionML = ESP = 'Clasificación 2';
                        ShowCaption = false;

                        field(GetFiltroClassId2; Rec.GetFiltroClassId(2))
                        {
                            ApplicationArea = All;
                            ToolTip = 'Specifies the value of the GetFiltroClassId(2) field.';
                            Caption = 'GetFiltroClassId(2)';

                            trigger OnValidate()
                            var
                            begin
                                FindLevelPg(2, Rec.GetFiltroClassId(2));
                            end;

                            trigger OnAssistEdit()
                            var
                            begin
                                //LookupLevelFilter(2);
                                GetFiltrosClass();
                            end;
                        }
                        field(GetFiltroClass2; Rec.GetFiltroClass(2))
                        {
                            ApplicationArea = All;
                            Importance = Promoted;
                            Editable = false;
                            ColumnSpan = 4;
                            ShowCaption = false;
                        }
                    }
                    group(Clasificacion3)
                    {
                        Caption = 'Clasificacion3';
                        field(GetFiltroClassId3; Rec.GetFiltroClassId(3))
                        {
                            ApplicationArea = All;
                            AssistEdit = true;
                            BlankZero = true;
                            ShowCaption = false;

                            trigger OnValidate()
                            var
                            begin
                                FindLevelPg(3, Rec.GetFiltroClassId(3));
                            end;

                            trigger OnAssistEdit()
                            var
                            begin
                                //LookupLevelFilter(3);
                                GetFiltrosClass();
                            end;
                        }
                        field(GetFiltroClass3; Rec.GetFiltroClass(3))
                        {
                            ApplicationArea = All;
                            Importance = Promoted;
                            Editable = FALSE;
                            ColumnSpan = 4;
                            ShowCaption = false;
                        }
                    }
                }
            }
            repeater(GroupName)
            {
                //CAMBIO EDITABLES
                Editable = true;
                Caption = 'GroupName';

                // Editable = false;
                //CAMBIO EDITABLES
                field(Id; Rec.Id)
                {
                    ApplicationArea = All;
                    Visible = false;
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the Id field.';
                    Caption = 'Id';
                    //CAMBIO EDITABLES
                }
                field(CodArt; Rec.CodArt)
                {
                    ApplicationArea = All;
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the Código field.';
                    Caption = 'Código';
                    //CAMBIO EDITABLES
                }
                field(Referencia; Rec.Referencia)
                {
                    ApplicationArea = All;
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the Referencia field.';
                    Caption = 'Referencia';
                    //CAMBIO EDITABLES
                }
                field(Descripcion; Rec.Descripcion)
                {
                    ApplicationArea = All;
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the Descripcion field.';
                    Caption = 'Descripcion';
                    //CAMBIO EDITABLES
                }
                field("Id Marca"; Rec."Id Marca")
                {
                    ApplicationArea = All;
                    CaptionML = ESM = 'Id Marca';
                    ToolTip = 'Specifies the value of the Id Marca field.';
                }
                field("Codigo Marca"; Rec."Codigo Marca")
                {
                    ApplicationArea = All;
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the Código Marca field.';
                    Caption = 'Código Marca';
                    //CAMBIO EDITABLES
                }
                field(CodigoUnidad; Rec."CodigoUnidad")
                {
                    ApplicationArea = All;
                    CaptionML = ESM = 'Código Unidad';
                    ToolTip = 'Specifies the value of the CodigoUnidad field.';
                }
                field("Unidad UN20"; Rec."Unidad UN20")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Unidad UN20 field.';
                    Caption = 'Unidad UN20';
                }
                field("Base Unit OF Measure"; Rec."Base Unit OF Measure")
                {
                    ApplicationArea = All;
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the Unidad de Medida Base field.';
                    Caption = 'Unidad de Medida Base';
                    //CAMBIO EDITABLES
                }
                field(FieldGetprecio; Getprecio())
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Precio Coste', ESM = 'Precio Coste';
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the Getprecio() field.';
                    //CAMBIO EDITABLES
                }
                field("No.Item"; Rec."No.Item")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Nº Item field.';
                    Caption = 'Nº Item';
                }
                field("Series Estel"; Rec."Series Estel")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Series Estel field.';
                    Caption = 'Series Estel';
                }
                field("Precio Libre"; Rec."Precio Libre")
                {
                    ApplicationArea = All;
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the Precio Libre field.';
                    Caption = 'Precio Libre';
                    //CAMBIO EDITABLES
                }
                field(Capitulo; Rec.Capitulo)
                {
                    ApplicationArea = All;
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the Capítulo field.';
                    Caption = 'Capítulo';
                    //CAMBIO EDITABLES
                }
                field(EAN; Rec.EAN)
                {
                    ApplicationArea = All;
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the EAN field.';
                    Caption = 'EAN';
                    //CAMBIO EDITABLES
                }
                field(Activo; Rec.Activo)
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Activo field.';
                    Caption = 'Activo';
                }
                field(Eliminado; Rec.Eliminado)
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Eliminado field.';
                    Caption = 'Eliminado';
                }
                field(Perdido; Rec.Perdido)
                {
                    ApplicationArea = All;
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the Perdido field.';
                    Caption = 'Perdido';
                    //CAMBIO EDITABLES
                }
                field(UltimaActualizacion; Rec."UltimaActualizacion")
                {
                    ApplicationArea = All;
                    CaptionML = ESM = 'Última actualización';
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the UltimaActualizacion field.';
                    //CAMBIO EDITABLES
                }
                field("Ultima Actualizacion GOCAT"; Rec."Ultima Actualizacion GOCAT")
                {
                    ApplicationArea = All;
                    //CAMBIO EDITABLES
                    Editable = false;
                    ToolTip = 'Specifies the value of the Ultima Actualizacion GOCAT field.';
                    Caption = 'Ultima Actualizacion GOCAT';
                    //CAMBIO EDITABLES
                }
                field("Classif 1"; Rec."Classif 1")
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Clasificación 1';
                    Editable = false;
                    ToolTip = 'Specifies the value of the Classif 1 field.';
                }
                field("Classif 2"; Rec."Classif 2")
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Clasificación 2';
                    Editable = false;
                    ToolTip = 'Specifies the value of the Classif 2 field.';
                }
                field("Classif 3"; Rec."Classif 3")
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Clasificación 3';
                    Editable = false;
                    ToolTip = 'Specifies the value of the Classif 3 field.';
                }
            }
        }
    }
    actions
    {
        area(Processing)
        {
            group(Opciones)
            {
                Caption = 'Opciones';
                action(Precios)
                {
                    ApplicationArea = All;
                    ShortCutKey = "Ctrl+P";
                    CaptionML = ESP = 'Precios';
                    Promoted = true;
                    PromotedIsBig = true;
                    Image = Price;
                    PromotedCategory = Category4;
                    ToolTip = 'Executes the Precios action.';

                    trigger OnAction()
                    var
                        lrPrec: Record "Telematel Precios Articulo";
                    begin
                        // Muestra todos los articulos
                        CLEAR(lrPrec);
                        lrPrec.SETCURRENTKEY(IdArticulo);
                        lrPrec.SETRANGE(IdArticulo, Rec.Id);
                        PAGE.RUN(0, lrPrec);
                    end;
                }
                action(FichaProducto)
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Ficha Producto';
                    Promoted = true;
                    PromotedIsBig = true;
                    Image = Item;
                    PromotedCategory = Category4;
                    ToolTip = 'Executes the FichaProducto action.';

                    trigger OnAction()
                    begin
                        Rec.ShowItemPage();
                    end;
                }
                action(Hyperlink)
                {
                    ApplicationArea = All;
                    Promoted = true;
                    PromotedIsBig = true;
                    Image = LinkWeb;
                    PromotedCategory = Category4;
                    ToolTip = 'Executes the Hyperlink action.';
                    Caption = 'Hyperlink';

                    trigger OnAction()
                    var
                    // cGestGoCat = Codeunit GestGoCatalog;
                    begin
                        cGestGoCat.HYperlinkProductRequest(Rec);
                    end;
                }
                action(ConversionUnidades)
                {
                    ApplicationArea = All;
                    RunObject = Page "GOCAT Arts. Conversion";
                    RunPageView = SORTING("Art Id");
                    RunPageLink = "Art Id" = FIELD(Id);
                    Promoted = true;
                    PromotedIsBig = true;
                    Image = ProductionSetup;
                    PromotedCategory = Category4;
                    ToolTip = 'Executes the ConversionUnidades action.';
                    Caption = 'ConversionUnidades';
                }
                action(Imagen)
                {
                    ApplicationArea = All;
                    Promoted = true;
                    Enabled = true;
                    PromotedIsBig = true;
                    Image = Picture;
                    PromotedCategory = Category4;
                    ToolTip = 'Executes the Imagen action.';
                    Caption = 'Imagen';

                    trigger OnAction()
                    var
                    begin
                        cGestGoCat.ShowArtImage(Rec.Id);
                    end;
                }
                action(WebPage)
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Página Web';
                    Promoted = true;
                    Enabled = true;
                    PromotedIsBig = true;
                    Image = Web;
                    PromotedCategory = Category4;
                    ToolTip = 'Executes the WebPage action.';

                    trigger OnAction()
                    begin
                        cGestGoCat.ShowArtWebPage(Rec.Id);
                    end;
                }
            }
            group(Clasificaciones)
            {
                Caption = 'Clasificaciones';
                action(Clasificaciones1)
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Clasificaciones';
                    RunObject = Page "Clasificacion Articulos";
                    RunPageLink = "Id Articulo" = FIELD(Id);
                    Promoted = true;
                    PromotedIsBig = true;
                    Image = CodesList;
                    PromotedCategory = Category5;
                    ToolTip = 'Executes the Clasificaciones1 action.';
                }
                action(FiltroClasificación)
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Filtro Clasificación';
                    Promoted = true;
                    PromotedIsBig = true;
                    Image = EditFilter;
                    PromotedCategory = Category5;
                    ToolTip = 'Executes the FiltroClasificación action.';

                    trigger OnAction()
                    begin
                        //GetFiltrosClass;
                        GetFiltrosClass2();
                    end;
                }
                action(EliminarFiltroClasificacion)
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Eliminar Filtro Clasificación';
                    Promoted = true;
                    PromotedIsBig = true;
                    Image = ClearFilter;
                    PromotedCategory = Category5;
                    ToolTip = 'Executes the EliminarFiltroClasificacion action.';

                    trigger OnAction()
                    begin
                        Rec.ClearFiltrosClass();
                        FiltraClassPg();
                    end;
                }
                action(NivelAnterior)
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Nivel Anterior';
                    Promoted = true;
                    Enabled = true;
                    PromotedIsBig = true;
                    Image = PreviousRecord;
                    PromotedCategory = Category5;
                    ToolTip = 'Executes the NivelAnterior action.';

                    trigger OnAction()
                    begin
                        IF Rec.RiseLevel() THEN FiltraClassPg();
                    end;
                }
            }
            Action(ActualizarArticulos)
            {
                ApplicationArea = All;
                ShortCutKey = "Ctrl+A";
                CaptionML = ESP = 'Actualizar Articulo';
                Promoted = true;
                PromotedIsBig = true;
                Image = UpdateXML;
                PromotedCategory = Process;
                ToolTip = 'Executes the ActualizarArticulos action.';

                trigger OnAction()
                var
                    lrArts: Record "Telematel Articulos";
                begin
                    CurrPage.SETSELECTIONFILTER(lrArts);
                    cGestGoCat.UpDateSeveralProducts(lrArts);
                    IF lrArts.COUNT = 1 THEN
                        MESSAGE(LText0001Txt)
                    ELSE
                        MESSAGE(LText0002Txt, lrArts.COUNT);
                    CurrPage.UPDATE();
                end;
            }
            action(MarcarSerieAFiltrados)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Marcar Serie a filtrados';
                Image = CreateSerialNo;
                ToolTip = 'Executes the MarcarSerieAFiltrados action.';

                trigger OnAction()
                begin
                    Rec.AsignaSeriaAFiltrados(Rec."Id Marca");
                end;
            }
            action(DescmarcarSerieSeleccionados)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Descmarcar Serie Seleccionados', ESM = ' ';
                Image = CancelAllLines;
                ToolTip = 'Executes the DescmarcarSerieSeleccionados action.';

                trigger OnAction()
                var
                    lrArts: Record "Telematel Articulos";
                begin
                    CLEAR(lrArts);
                    CurrPage.SETSELECTIONFILTER(lrArts);
                    IF lrArts.FIND('-') THEN
                        IF CONFIRM(Text0002Txt, TRUE, lrArts.COUNT) THEN
                            lrArts.MODIFYALL("Series Estel", '');
                end;
            }
            action(TotalArticulos)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Total Articulos';
                ToolTip = 'Executes the TotalArticulos action.';

                trigger OnAction()
                begin
                    MESSAGE(Text0003Txt, Rec.COUNT);
                end;
            }
        }
    }
    var
        rTlmStp: Record "Telematel Setup";
        cGestGoCat: Codeunit GestGoCatalog;
        LText0001Txt: TextConst ESP = 'Articulo Actualizado', ESM = 'Articulo Actualizado';
        LText0002Txt: TextConst ESP = '%1 Articulos Actualizados', ESM = '%1 Articulos Actualizados';
        Text0002Txt: TextConst ESM = '¿Desea desmarcar la seria a los %1 articulos seleccionados?';
        wClasNames: ARRAY[3] OF Text[60];
        wTextClass: Text;
        Text0003Txt: TextConst ESP = '"Total Articulos = %1"';

    trigger OnOpenPage()

    begin
        rTlmStp.GET();
        IF rTlmStp."Default Classification Type" <> 0 THEN Rec.SETRANGE("Tipo Clasificacion filter", rTlmStp."Default Classification Type");
    end;

    trigger OnAfterGetRecord()

    begin
        Rec.GetClasLevelNames(wClasNames);
    end;

    trigger OnAfterGetCurrRecord()
    begin
        GetValues();
    end;
    //     PROCEDURE CopyFilters(VAR prArts: Record "Telematel Articulos");
    //     BEGIN
    //         // CopyFilters
    //         prArts.COPYFILTERS(Rec);
    //     END;
    PROCEDURE Getprecio(): Decimal;
    BEGIN
        EXIT(cGestGoCat.GetPrecio(Rec, TODAY));
    END;
    //     LOCAL PROCEDURE LookupLevelFilter(pwLevel: Integer);
    //     VAR
    //         lrClass: Record Clasificaciones;
    //         lwParentId: Integer;
    //     BEGIN
    //         IF pwLevel > 1 THEN BEGIN
    //             lwParentId := Rec.GetFiltroClassId(pwLevel - 1);
    //             IF lwParentId = 0 THEN
    //                 EXIT;
    //         END
    //         ELSE
    //             lwParentId := 0;
    //         CLEAR(lrClass);
    //         lrClass.SETRANGE(Nivel, pwLevel);
    //         lrClass.SETRANGE("Id Subordinado", lwParentId);
    ////         IF PAGE.RUNMODAL(50153, lrClass) = ACTION::Yes THEN BEGIN
    //         IF PAGE.RUNMODAL(58002, lrClass) = ACTION::Yes THEN BEGIN
    //             FiltraLevelPg(pwLevel, lrClass.Id, lrClass.Descripcion);
    //         END;
    //     END;
    PROCEDURE FindLevelPg(pwLevel: Integer; pwId: Integer);
    VAR
        lwName: Text;
    BEGIN
        lwName := Rec.FindLevel(pwLevel, pwId);
        FiltraLevelPg(pwLevel, pwId, lwName);
    END;

    LOCAL PROCEDURE FiltraLevelPg(pwLevel: Integer; pwId: Integer; pwName: Text);
    BEGIN
        Rec.AsingLevel(pwLevel, pwId, pwName);
        FiltraClassPg();
    END;

    LOCAL PROCEDURE FiltraClassPg();

    BEGIN
        Rec.FiltraClass();
        //CurrPage.UPDATE
        CurrPage.ACTIVATE(TRUE);
        Rec.GetLastClassFilterLevel();
    END;

    LOCAL PROCEDURE GetFiltrosClass();
    VAR
        TemplwClaArt: Record "Clasificacion Articulos" TEMPORARY;
        lwFiltPage: Page "Filtros Clasificacion";
    BEGIN
        //GetFiltrosClass
        CLEAR(TemplwClaArt); // Utilizamos esta tabla para pasar el filtro de c¢digo de clasificacion
        Rec.COPYFILTER("Tipo Clasificacion filter", TemplwClaArt."Codigo Clasificacion");
        CLEAR(lwFiltPage);
        Rec.SetFilterPageFilters(lwFiltPage);
        lwFiltPage.CopyFilterCodClas(TemplwClaArt);
        lwFiltPage.LOOKUPMODE := TRUE;
        IF lwFiltPage.RUNMODAL() = ACTION::LookupOK THEN BEGIN
            Rec.FilterPageGetValues(lwFiltPage);
            FiltraClassPg();
            // Devolvemos el filtro de clasificaci¢n si ha cambiado
            lwFiltPage.GetFilterCodClas(TemplwClaArt);
            TemplwClaArt.COPYFILTER("Codigo Clasificacion", Rec."Tipo Clasificacion filter");
        END;
    END;

    LOCAL PROCEDURE GetFiltrosClass2();
    VAR
        lwIdTipoClass: Integer;
    BEGIN
        //GetFiltrosClass2
        IF Rec.GETFILTER("Tipo Clasificacion filter") <> '' THEN lwIdTipoClass := Rec.GETRANGEMIN("Tipo Clasificacion filter");
        IF Rec.GestFiltrosTree(lwIdTipoClass) THEN
            //SETRANGE("Tipo Clasificacion filter",lwIdTipoClass);
            FiltraClassPg();
    END;

    LOCAL PROCEDURE CambiaTipoClasificacion();
    VAR
        lrCodsCl: Record "Tipos Clasificacion";
    BEGIN
        IF PAGE.RUNMODAL(0, lrCodsCl) = ACTION::LookupOK THEN BEGIN
            Rec.SETRANGE("Tipo Clasificacion filter", lrCodsCl.Id);
            Rec.ClearFiltrosClass();
            FiltraClassPg();
        END;
    END;

    LOCAL PROCEDURE GetClassFullTextPg() Result: Text;
    BEGIN
        Result := Rec.GetClassFullText();
        wTextClass := Result;
        CurrPage.CAPTION := Result;
    END;

    LOCAL PROCEDURE GetValues();
    BEGIN
        cGestGoCat.HaveArtImage(Rec.Id);
        cGestGoCat.HaveArtWebPage(Rec.Id);
    END;
}
