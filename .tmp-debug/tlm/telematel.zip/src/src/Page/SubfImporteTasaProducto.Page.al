Page 58028 "Subf Importe Tasa Producto"
{
    //P_58028_Subf_Importe_Tasa_Producto
    SourceTable = "Importe Tasa Producto";
    PopulateAllFields = true;
    PageType = ListPart;

    layout
    {
        area(Content)
        {
            repeater(repeater)
            {
                field(Id; Rec.Id)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Id field.';
                }
                field(Importe; Rec.Importe)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Importe field.';
                }
                field(Descripcion; Rec.Descripcion)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Descripción field.';
                }
            }
        }
    }
    actions
    {
        area(Processing)
        {
            group(Lineas)
            {
                CaptionML = ESP = 'Líneas';

                action(Productos)
                {
                    ApplicationArea = All;
                    Image = Item;
                    ToolTip = 'Executes the Productos action.';

                    trigger OnAction()
                    begin
                        //This functionality was copied from page #50125. Unsupported part was commented. Please check it.
                        MuestraProductos();
                    end;
                }
            }
        }
    }
    PROCEDURE MuestraProductos();
    BEGIN
        Rec.ShowProductos();
    END;
}
