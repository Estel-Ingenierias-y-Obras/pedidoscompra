Page 58025 "Clasificaciones Subn"
{
    //P_58025_Clasificaciones_Subn
    Editable = false;
    CaptionML = ESP = 'Clasificaciones';
    SourceTable = Clasificaciones;
    PopulateAllFields = true;
    DataCaptionFields = "Tipo Clasificacion", "Desc. Subordinado";
    PageType = StandardDialog;

    layout
    {
        area(Content)
        {
            repeater(Repeater)
            {

                field(Id; Rec.Id)
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Id field.';
                }
                field("Desc.Codigo Clasificacion"; Rec."Desc.Codigo Clasificacion")
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Código Clasificación field.';
                }
                field("Desc. Subordinado"; Rec."Desc. Subordinado")
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Desc. Subordinado field.';
                }
                field(Nivel; Rec.Nivel)
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Nivel field.';
                }
                field(Descripcion; Rec.Descripcion)
                {
                    ApplicationArea = All;
                    AssistEdit = true;
                    StyleExpr = wStyle;
                    ToolTip = 'Specifies the value of the Descripcion field.';

                    trigger OnAssistEdit()
                    begin
                        Rec.VerSubniveles();
                    end;
                }
                field("Id Subordinado"; Rec."Id Subordinado")
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Id Subordinado field.';
                }
                field(Orden; Rec.Orden)
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Orden field.';
                }
            }
        }
    }
    trigger OnAfterGetRecord()
    begin
        SetStyle();
    end;

    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    begin
        Rec.Manual := TRUE;
    end;

    trigger OnAfterGetCurrRecord()
    begin
        CurrPage.CAPTION := Rec.Descripcion;
    end;

    VAR
        wStyle: Text;

    LOCAL PROCEDURE SetStyle();
    BEGIN
        CASE Rec.Nivel OF
            0:
                wStyle := 'Subordinate';
            1:
                wStyle := 'Strong';
            2:
                wStyle := 'Strongaccent';
            3:
                wStyle := 'Favorable';
        END;
    END;
}
