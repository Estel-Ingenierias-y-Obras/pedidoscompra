page 58000 "Clasificaciones Tree"
{
    Editable = false;
    CaptionML = ESP = 'Clasificaciones';
    SourceTable = Clasificaciones;
    SourceTableView = SORTING(Orden);
    DataCaptionFields = "Desc.Codigo Clasificacion", "Desc. Subordinado";
    PageType = Worksheet;
    SourceTableTemporary = true;
    ShowFilter = false;

    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field(Id; Rec.Id)
                {
                    ApplicationArea = All;
                    Caption = 'Id';
                    Visible = false;
                    Editable = False;
                    ToolTip = 'Specifies the value of the Id field.';
                }
                field(Descripcion; Rec.Descripcion)
                {
                    ApplicationArea = All;
                    Importance = Promoted;
                    Editable = FALSE;
                    StyleExpr = wStyle;
                    ToolTip = 'Specifies the value of the Descripcion field.';

                    // Image = key;
                    trigger OnAssistEdit()
                    begin
                        //VerSubniveles;
                        IF Rec.SubnivelesRM() THEN 
                            CurrPage.UPDATE(FALSE);
                        //RellenaTemp(wCodClas,Id);
                    end;
                }
                field("Id Subordinado"; Rec."Id Subordinado")
                {
                    ApplicationArea = All;
                    Visible = false;
                    Editable = FALSE;
                    ToolTip = 'Specifies the value of the Id Subordinado field.';
                }
            }
        }
    }
    var
        wStyle: Text;

    trigger OnAfterGetRecord()
    var
    begin
        //wNeg := Nivel <=1;
        SetStyle();
    end;

    trigger OnAfterGetCurrRecord()
    var
    begin
        CurrPage.CAPTION := Rec.Descripcion;
    end;

    PROCEDURE RellenaTemp(pwCodClassf: Integer; pwId: Integer; pwIdMarca: Integer);
    VAR
        lrClass: Record "Clasificaciones";
        lrCodClass: Record "Tipos Clasificacion";
        lwOrd: Integer;
    BEGIN
        // RellenaTemp
        // Trabaja con una tabla temporal
        // Reordena para permir la estructura de arbol
        CLEAR(Rec);
        Rec.DELETEALL();
        lwOrd := 0;
        CLEAR(lrClass);
        CLEAR(lrCodClass);
        IF pwCodClassf <> 0 THEN lrCodClass.SETRANGE(Id, pwCodClassf);
        IF lrCodClass.FINDSET() THEN BEGIN
            Rec.INIT();
            lwOrd += 1;
            Rec.Orden := lwOrd;
            Rec.Nivel := 0; // Codigo de Clasificacion
            Rec.Id := -lrCodClass.Id;
            Rec."Tipo Clasificacion" := lrCodClass.Id;
            Rec.Descripcion := lrCodClass.Nombre;
            Rec.INSERT();
            REPEAT
                lrClass.SETRANGE("Tipo Clasificacion", lrCodClass.Id);
                lrClass.SETRANGE(Nivel, 1);
                IF pwIdMarca > 0 THEN lrClass.SETRANGE("Id Marca", pwIdMarca);
                IF lrClass.FINDSET() THEN 
                    REPEAT
                        BuscaSubs(lrClass, lwOrd, pwIdMarca);
                    UNTIL lrClass.NEXT() = 0;
            UNTIL lrCodClass.NEXT() = 0;
        END;
        Rec.SETCURRENTKEY(Orden);
        IF Rec.COUNT > 0 THEN BEGIN
            IF pwId = 0 THEN BEGIN
                Rec.SETRANGE(Nivel, 1);
                IF Rec.FINDFIRST() THEN pwId := Rec.Id;
                Rec.SETRANGE(Nivel);
            END;
            IF pwId <> 0 THEN Rec.Id := pwId
        END;
    END;

    LOCAL PROCEDURE BuscaSubs(prClass: Record "Clasificaciones"; VAR pwOrd: Integer; pwIdMarca: Integer);
    VAR
        lrClass: Record "Clasificaciones";
    BEGIN
        // BuscaSubs
        Rec.COPY(prClass);
        IF NOT Rec.FIND() THEN BEGIN
            pwOrd += 1;
            Rec.Orden := pwOrd;
            //Nivel := prClass.Nivel -1; // Lo hacemos asi para empezar por nivel 0
            Rec.Nivel := prClass.Nivel;
            Rec.INSERT();
        END;
        CLEAR(lrClass);
        lrClass.SETRANGE(Nivel, prClass.Nivel + 1);
        lrClass.SETRANGE("Id Subordinado", prClass.Id);
        IF pwIdMarca > 0 THEN lrClass.SETRANGE("Id Marca", pwIdMarca);
        IF lrClass.FINDSET() THEN 
            REPEAT
                BuscaSubs(lrClass, pwOrd, pwIdMarca);
            UNTIL lrClass.NEXT() = 0;
    END;
    //     PROCEDURE GetDescription() Result: Text;
    //     BEGIN
    //         // GetDescription
    //         // Devuelve la descripcion identada
    //         Result := PADSTR('', Rec.Nivel * 5, ' ') + STRSUBSTNO('%1 - %2', Rec.Nivel, Rec.Descripcion);
    //     END;
    PROCEDURE GetId(): Integer;
    BEGIN
        EXIT(Rec.Id);
    END;

    LOCAL PROCEDURE SetStyle();
    BEGIN
        CASE Rec.Nivel OF
            0:
                wStyle := 'Subordinate';
            1:
                wStyle := 'Strong';
            2:
                wStyle := 'Strongaccent';
            3:
                wStyle := 'Favorable';
        END;
    END;
}
