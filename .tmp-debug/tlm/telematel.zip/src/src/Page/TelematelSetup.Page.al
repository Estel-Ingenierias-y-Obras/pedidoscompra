page 58010 "Telematel Setup"
{
    CaptionML = ESP = 'Configuración Telematel';
    SourceTable = "Telematel Setup";
    PopulateAllFields = true;
    SourceTableView = SORTING(Id) WHERE(Id = FILTER(= ''));
    PageType = Document;
    PromotedActionCategoriesML = ESP = 'Nuevo, Acciones, Reports, Navegar';
    ApplicationArea = All;
    UsageCategory = Administration;

    layout
    {
        area(Content)
        {
            group(GoCatalog)
            {
                field(HashCode; Rec.HashCode)
                {
                    ApplicationArea = All;
                    ToolTipML = ESP = 'Código de seguridad GoCatalog';
                    ColumnSpan = 2;
                }
                field("GOC Version"; Rec."GOC Version")
                {
                    ApplicationArea = All;
                    ColumnSpan = 2;
                    ToolTipML = ESP = 'Versión de dato de GoCalog. Si se omite retornará la ultima versión. Se recomienda definirla ya que si hay un cambio en la estructura de datos en una nueva versión puede afectar al funcionamiento del módulo';
                }
                field(TimeOut; Rec.TimeOut)
                {
                    ApplicationArea = All;
                    ToolTipML = ESP = 'Time Out en Milisegundos. Si se deja a 0 toma el valor por defecto = 100.000 (100 segundos)';
                    ColumnSpan = 2;
                }
                field("Log Duration"; Rec."Log Duration")
                {
                    ApplicationArea = All;
                    ToolTipML = ESP = 'Formula de tiempo tras la cual los registros Log de conexiones Go Catalog Serán eliminados. (25D, 2M...)';
                }
                field("Productos x Commit"; Rec."Productos x Commit")
                {
                    ApplicationArea = All;
                    ToolTipML = ESP = 'Indica cada cuantos productos importados se debe de realizar un Commit (final de transacción). Si se deja a 0 No se realiza el Commit';
                    ColumnSpan = 2;
                }
                /*grid(Group)
                {
                    GridLayout = Columns;*/
                grid(TiposClasificacion)
                {
                    GridLayout = Columns;

                    field("Default Classification Type"; Rec."Default Classification Type")
                    {
                        RowSpan = 2;
                        CaptionML = ESP = 'Tipo de Clasificación por Defecto';
                        ApplicationArea = All;
                        ToolTip = 'Specifies the value of the Tipo de Clasificación por Defecto field.';
                        //ShowCaption = false;
                    }
                    field("Default Classification Name"; Rec."Default Classification Name")
                    {
                        RowSpan = 1;
                        ApplicationArea = All;
                        Style = StandardAccent;
                        StyleExpr = TRUE;
                        ShowCaption = false;
                    }
                }
                grid(TiempoMáximo)
                {
                    GridLayout = Columns;

                    field("Tiempo Maximo"; Rec."Tiempo Maximo")
                    {
                        RowSpan = 2;
                        CaptionML = ESP = 'Tiempo Máximo (minutos)';
                        ApplicationArea = All;
                        ToolTipML = ESP = 'Tiempo de duración máximo del proceso en minutos. Si se deja a 0, no se establecerán límites.';

                        //ShowCaption = false;
                        trigger OnValidate()
                        var
                        begin
                            CurrPage.UPDATE(TRUE);
                        end;
                    }
                    field(GetTiempoMaxText; Rec.GetTiempoMaxText())
                    {
                        RowSpan = 1;
                        ApplicationArea = All;
                        ShowCaption = false;
                    }
                }
                /*}*/
                field("Numero Intentos"; Rec."Numero Intentos")
                {
                    ApplicationArea = All;
                    ToolTipML = ESP = 'Número de veces en que el sistema reintenta el proceso de actualización despues de un error';
                }
                field("Tiempo entre Intentos"; Rec."Tiempo entre Intentos")
                {
                    ApplicationArea = All;
                    ToolTipML = ESP = 'Tiempo en segundos desde que se produce el error hasta el siguiente reintento';
                }
                field("Mail Notificacion Error"; Rec."Mail Notificacion Error")
                {
                    ApplicationArea = All;
                    ExtendedDatatype = EMail;
                    ToolTipML = ESP = 'Dirección de correo donde se enviarán las notificaciones de error de la importación diaria Go Catalog';
                }
                /*fixed(FixedLayout)
                {
                    //Rows?

                    group(GroupName)
                    {
                        ShowCaption = false;

                        field("Items Serie"; Rec."Items Serie")
                        {
                            ApplicationArea = All;
                            // Editable = false;
                            // Style = StandardAccent;
                            // StyleExpr = TRUE;
                            // ShowCaption = false;                        
                        }
                    }
                }*/
                field("Items Serie"; Rec."Items Serie")
                {
                    ApplicationArea = All;
                    Visible = true;
                    ToolTip = 'Specifies the value of the Items Serie field.';
                }
                field("Inventory Posting"; Rec."Inventory Posting")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Inventory Posting field.';
                }
                field("Gen. Prod. Posting"; Rec."Gen. Prod. Posting")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Gen. Prod. Posting field.';
                }
                field("Codigo RAEE"; Rec."Codigo RAEE")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Codigo RAEE field.';
                }
                field(Activo; Rec.Activo)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Activo field.';
                }
                fixed(FL2)
                {
                    //Rows?
                    CaptionML = ESP = 'Actualizaciones';
                    Visible = False;

                    group(group1)
                    {
                        field("Ini Act Datos"; Rec."Ini Act Datos")
                        {
                            ApplicationArea = All;
                            CaptionML = ESP = 'Ult. Hora Inicio';
                            Editable = FALSE;
                            Style = StandardAccent;
                            StyleExpr = TRUE;
                            ToolTip = 'Specifies the value of the Ini Act Datos field.';
                        }
                        field("Fin Act Datos"; Rec."Fin Act Datos")
                        {
                            ApplicationArea = All;
                            CaptionML = ESP = 'Ult. Hora Fin';
                            Editable = FALSE;
                            Style = StandardAccent;
                            StyleExpr = TRUE;
                            ToolTip = 'Specifies the value of the Fin Act Datos field.';
                        }
                    }
                }
                field("Error Act"; Rec."Error Act")
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Mensaje de Error';
                    Visible = False;
                    Editable = FALSE;
                    MultiLine = true;
                    RowSpan = 4;
                    ColumnSpan = 4;
                    ToolTip = 'Specifies the value of the Error Act field.';
                }
                field(URL; Rec.URL)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the URL field.';
                }
                field(Port; Rec.Port)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Port field.';
                }
            }
        }
    }
    actions
    {
        area(Processing)
        {
            action(LogDeConexiones)
            {
                ApplicationArea = All;
                RunObject = Page "Go Catalog Connection Log";
                Promoted = true;
                PromotedIsBig = true;
                Image = InteractionLog;
                PromotedCategory = Category4;
                ToolTip = 'Executes the LogDeConexiones action.';
            }
        }
    }
    //     PROCEDURE NomSerieItem(): Text[50];
    //     VAR
    //         lrNSerie: Record 308;
    //     BEGIN
    //         // NomSerieItem
    //         IF lrNSerie.GET(Rec."Items Serie") THEN
    //             EXIT(lrNSerie.Description);
    //     END;
}
