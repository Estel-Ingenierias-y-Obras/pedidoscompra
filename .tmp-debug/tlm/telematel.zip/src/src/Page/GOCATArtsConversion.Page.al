Page 58029 "GOCAT Arts. Conversion"
{
    //P_58029_GOCAT_Arts_Conversion
    Editable = false;
    CaptionML = ESP = 'Conversión Artículos';
    SourceTable = "GOCAT Arts. Conversion";
    PageType = List;

    layout
    {
        area(Content)
        {
            repeater(repeater)
            {
                field("Art Id"; Rec."Art Id")
                {
                    ApplicationArea = All;
                    Visible = False;
                    ToolTip = 'Specifies the value of the Art Id field.';
                }
                field("Unit of Measure Code"; Rec."Unit of Measure Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Cód. unidad medida field.';
                }
                field("Codigo Unidad"; Rec."Codigo Unidad")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Código Unidad field.';
                }
                field("Unidad UN20"; Rec."Unidad UN20")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Unidad UN20 field.';
                }
                field(Valor; Rec.Valor)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Valor field.';
                }
            }
        }
    }
}
