page 58011 "Articulos X Clasificacion"
{
    InsertAllowed = false;
    DeleteAllowed = false;
    ModifyAllowed = false;
    SourceTable = "Clasificacion Articulos";
    PageType = List;
    RefreshOnActivate = true;
    Caption = 'Articulos X Clasificacion';

    layout
    {
        area(Content)
        {
            field(GetFiltroCodClassText; Rec.GetFiltroCodClassText())
            {
                ApplicationArea = All;
                Style = Standard;
                StyleExpr = TRUE;
                ColumnSpan = 2;
                ToolTip = 'Specifies the value of the GetFiltroCodClassText() field.';
                Caption = 'GetFiltroCodClassText()';

                trigger OnLookup(var Text: Text): Boolean
                var
                begin
                    CambiaTipoClasificacion();
                end;
            }
            field(GetClassFullText; Rec.GetClassFullText())
            {
                ApplicationArea = All;
                Width = 2000;
                Editable = false;
                Style = StandardAccent;
                StyleExpr = TRUE;
                RowSpan = 2;
                ColumnSpan = 4;
                ToolTip = 'Specifies the value of the GetClassFullText() field.';
                Caption = 'GetClassFullText()';

                //Image = Folder;
                trigger OnLookup(var Text: Text): Boolean
                var
                begin
                    GetFiltrosClass2();
                end;

                trigger OnAssistEdit()
                var
                begin
                    GetFiltrosClass2();
                end;
            }
            group(FiltrosClasificacion)
            {
                CaptionML = ESP = 'Filtros Clasificación';

                grid(FiltroClasificacion2)
                {
                    GridLayout = Rows;
                    Caption = 'FiltroClasificacion2';

                    group(TipoDeClasificacion)
                    {
                        Caption = 'TipoDeClasificacion';
                        field(FieldGetFiltroCodClassText; Rec.GetFiltroCodClassText())
                        {
                            ApplicationArea = All;
                            CaptionML = ESP = 'Tipo de Clasificación';
                            ColumnSpan = 3;
                            ShowCaption = false;

                            trigger OnAssistEdit()
                            var
                            begin
                                CambiaTipoClasificacion();
                            end;
                        }
                    }
                    group(Clasificacion1)
                    {
                        Caption = 'Clasificacion1';
                        field(GetFiltroClassId; Rec.GetFiltroClassId(1))
                        {
                            ApplicationArea = All;
                            AssistEdit = true;
                            BlankZero = true;
                            ShowCaption = false;

                            trigger OnValidate()
                            var
                            begin
                                FindLevelPg(1, Rec.GetFiltroClassId(1));
                            end;

                            trigger OnAssistEdit()
                            var
                            begin
                                //LookupLevelFilter(1);
                                GetFiltrosClass();
                            end;
                        }
                        field(GetFiltroClass; Rec.GetFiltroClass(1))
                        {
                            ApplicationArea = All;
                            CaptionML = ESM = 'Filtro Clasificación';
                            Importance = Promoted;
                            Editable = false;
                            ColumnSpan = 4;
                            ShowCaption = false;
                        }
                    }
                    group(Clasificacion2)
                    {
                        Caption = 'Clasificacion2';
                        field(GetFiltroClassId2; Rec.GetFiltroClassId(2))
                        {
                            ApplicationArea = All;
                            BlankZero = true;
                            ShowCaption = false;

                            trigger OnValidate()
                            var
                            begin
                                FindLevelPg(2, Rec.GetFiltroClassId(2));
                            end;

                            trigger OnAssistEdit()
                            var
                            begin
                                //LookupLevelFilter(2);
                                GetFiltrosClass();
                            end;
                        }
                        field(GetFiltroClass2; Rec.GetFiltroClass(2))
                        {
                            ApplicationArea = All;
                            Importance = Promoted;
                            Editable = false;
                            ColumnSpan = 4;
                            ShowCaption = false;
                        }
                    }
                    group(Clasificacion3)
                    {
                        Caption = 'Clasificacion3';
                        field(GetFiltroClassId3; Rec.GetFiltroClassId(3))
                        {
                            ApplicationArea = All;
                            AssistEdit = true;
                            BlankZero = true;
                            ShowCaption = false;

                            trigger OnValidate()
                            var
                            begin
                                FindLevelPg(3, Rec.GetFiltroClassId(3));
                            end;

                            trigger OnAssistEdit()
                            var
                            begin
                                //LookupLevelFilter(3);
                                GetFiltrosClass();
                            end;
                        }
                        field(GetFiltroClass3; Rec.GetFiltroClass(3))
                        {
                            ApplicationArea = All;
                            Importance = Promoted;
                            Editable = FALSE;
                            ColumnSpan = 4;
                            ShowCaption = false;
                        }
                    }
                }
            }
            repeater(Group)
            {
                Caption = 'Group';
                field("Id Articulo"; Rec."Id Articulo")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Id Articulo field.';
                    Caption = 'Id Articulo';
                }
                field(Referencia; Rec.Referencia)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Referencia field.';
                    Caption = 'Referencia';
                }
                field("Descripcion Articulo"; Rec."Descripcion Articulo")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Descripción Artículo field.';
                    Caption = 'Descripción Artículo';
                }
                field("Codigo Marca"; Rec."Codigo Marca")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Código Marca field.';
                    Caption = 'Código Marca';
                }
                field("Cod Item"; Rec."Cod Item")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Cod Item field.';
                    Caption = 'Cod Item';
                }
                field("Nivel 1"; Rec."Nivel 1")
                {
                    ApplicationArea = All;
                    AssistEdit = true;
                    ToolTip = 'Specifies the value of the Nivel 1 field.';
                    Caption = 'Nivel 1';

                    trigger OnAssistEdit()
                    var
                    begin
                        DoLookup(1);
                    end;
                }
                field("Nivel 2"; Rec."Nivel 2")
                {
                    ApplicationArea = All;
                    AssistEdit = true;
                    ToolTip = 'Specifies the value of the Nivel 2 field.';
                    Caption = 'Nivel 2';

                    trigger OnAssistEdit()
                    var
                    begin
                        DoLookup(2);
                    end;
                }
                field("Nivel 3"; Rec."Nivel 3")
                {
                    ApplicationArea = All;
                    AssistEdit = true;
                    ToolTip = 'Specifies the value of the Nivel 3 field.';
                    Caption = 'Nivel 3';

                    trigger OnAssistEdit()
                    var
                    begin
                        DoLookup(3);
                    end;
                }
            }
        }
    }
    actions
    {
        area(Processing)
        {
            //Caption=ESP='Opciones';
            action(Precios)
            {
                ApplicationArea = All;
                ShortCutKey = "Ctrl+P";
                CaptionML = ESP = 'Precios';
                Promoted = true;
                PromotedIsBig = true;
                Image = Price;
                PromotedCategory = Category4;
                ToolTip = 'Executes the Precios action.';

                trigger OnAction()
                var
                    lrPrec: Record "Telematel Precios Articulo";
                begin
                    // Muestra todos los articulos
                    CLEAR(lrPrec);
                    lrPrec.SETCURRENTKEY(IdArticulo);
                    lrPrec.SETRANGE(IdArticulo, Rec."Id Articulo");
                    PAGE.RUN(0, lrPrec);
                end;
            }
            action(FichaProducto)
            {
                ApplicationArea = All;
                Promoted = true;
                PromotedIsBig = true;
                Image = Item;
                PromotedCategory = Category4;
                ToolTip = 'Executes the FichaProducto action.';
                Caption = 'FichaProducto';

                trigger OnAction()
                var
                    lrItem: Record 27;
                begin
                    IF Rec."Cod Item" = '' THEN EXIT;
                    IF lrItem.GET(Rec."Cod Item") THEN PAGE.RUN(PAGE::"Item Card", lrItem);
                end;
            }
        }
        area(Creation)
        {
            action(Clasificaciones)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Clasificaciones';
                RunObject = Page "Clasificacion Articulos";
                RunPageLink = "Id Articulo" = FIELD("Id Articulo");
                Promoted = true;
                PromotedIsBig = true;
                Image = CodesList;
                PromotedCategory = Category5;
                ToolTip = 'Executes the Clasificaciones action.';
            }
            action(FiltroClasificacion)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Filtro Clasificación';
                Promoted = true;
                PromotedIsBig = true;
                Image = EditFilter;
                PromotedCategory = Category5;
                ToolTip = 'Executes the FiltroClasificacion action.';

                trigger OnAction()
                var
                begin
                    GetFiltrosClass2();
                end;
            }
            action(EliminarFiltroClasificacion)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Eliminar Filtro Clasificación';
                Promoted = true;
                PromotedIsBig = true;
                Image = ClearFilter;
                PromotedCategory = Category5;
                ToolTip = 'Executes the EliminarFiltroClasificacion action.';

                trigger OnAction()
                var
                begin
                    Rec.ClearFiltrosClass();
                    FiltraClassPg();
                end;
            }
            action(NivelAnterior)
            {
                ApplicationArea = All;
                Promoted = true;
                Enabled = true;
                PromotedIsBig = true;
                Image = PreviousRecord;
                PromotedCategory = Category5;
                ToolTip = 'Executes the NivelAnterior action.';
                Caption = 'NivelAnterior';

                trigger OnAction()
                var
                begin
                    IF Rec.RiseLevel() THEN FiltraClassPg();
                end;
            }
        }
    }
    trigger OnOpenPage()
    var
    begin
        rTlmStp.GET();
        IF rTlmStp."Default Classification Type" <> 0 THEN
            Rec.SETRANGE("Codigo Clasificacion", rTlmStp."Default Classification Type")
        ELSE
            Rec.SETRANGE("Codigo Clasificacion", -1);
    end;

    var
        rTlmStp: Record "Telematel Setup";

    LOCAL PROCEDURE DoLookup(pwLevel: Integer);
    BEGIN
        Rec.LookupLevel(pwLevel);
        CurrPage.UPDATE();
    END;

    LOCAL PROCEDURE CambiaTipoClasificacion();
    VAR
        lrCodsCl: Record "Tipos Clasificacion";

    BEGIN
        IF PAGE.RUNMODAL(0, lrCodsCl) = ACTION::LookupOK THEN BEGIN
            Rec.SETRANGE("Codigo Clasificacion", lrCodsCl.Id);
            Rec.ClearFiltrosClass();
            FiltraClassPg();
        END;
    END;

    LOCAL PROCEDURE FiltraClassPg();
    BEGIN
        Rec.FiltraClass();
        //CurrPage.UPDATE
        CurrPage.ACTIVATE(TRUE);
        Rec.GetLastClassFilterLevel();
    END;

    LOCAL PROCEDURE GetFiltrosClass2();
    VAR
        lwIdTipoClass: Integer;
    BEGIN
        //GetFiltrosClass2
        IF Rec.GETFILTER("Codigo Clasificacion") <> '' THEN lwIdTipoClass := Rec.GETRANGEMIN("Codigo Clasificacion");
        IF Rec.GestFiltrosTree(lwIdTipoClass) THEN FiltraClassPg();
    END;

    PROCEDURE FindLevelPg(pwLevel: Integer; pwId: Integer);
    VAR
        lwName: Text;
    BEGIN
        lwName := Rec.FindLevel(pwLevel, pwId);
        FiltraLevelPg(pwLevel, pwId, lwName);
    END;

    LOCAL PROCEDURE FiltraLevelPg(pwLevel: Integer; pwId: Integer; pwName: Text);
    BEGIN
        Rec.AsingLevel(pwLevel, pwId, pwName);
        FiltraClassPg();
    END;

    LOCAL PROCEDURE GetFiltrosClass();
    VAR
        lwFiltPage: Page "Filtros Clasificacion";
    BEGIN
        //GetFiltrosClass
        CLEAR(lwFiltPage);
        Rec.SetFilterPageFilters(lwFiltPage);
        lwFiltPage.CopyFilterCodClas(Rec);
        lwFiltPage.LOOKUPMODE := TRUE;
        IF lwFiltPage.RUNMODAL() = ACTION::LookupOK THEN BEGIN
            Rec.FilterPageGetValues(lwFiltPage);
            FiltraClassPg();
            // Devolvemos el filtro de clasificaci¢n si ha cambiado
            lwFiltPage.GetFilterCodClas(Rec);
        END;
    END;
}
