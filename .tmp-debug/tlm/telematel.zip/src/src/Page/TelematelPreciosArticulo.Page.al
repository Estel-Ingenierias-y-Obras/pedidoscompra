page 58006 "Telematel Precios Articulo"
{
    Editable = false;
    SourceTable = "Telematel Precios Articulo";
    PageType = List;

    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field(IdArticulo; Rec.IdArticulo)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the IdArticulo field.';
                }
                field(CodArt; Rec.CodArt)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the CodArt field.';
                }
                field(IdMarca; Rec.IdMarca)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the IdMarca field.';
                }
                field("Fecha Inicio"; Rec."Fecha Inicio")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Fecha Inicio field.';
                }
                field("Fecha Final"; Rec."Fecha Final")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Fecha Final field.';
                }
                field(Precio; Rec.Precio)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Precio field.';
                }
                field("Telematel Currency"; Rec."Telematel Currency")
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Telematel Currency field.';
                }
                field("Currency Code"; Rec."Currency Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Currency Code field.';
                }
                field("Minimum Quantity"; Rec."Minimum Quantity")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Minimum Quantity field.';
                }
                field("Unit of Measure Code"; Rec."Unit of Measure Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Unit of Measure Code field.';
                }
                field(Quantity; Rec.Quantity)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Quantity field.';
                }
                field(RAEE; Rec.RAEE)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the RAEE field.';
                }
                field(Manual; Rec.Manual)
                {
                    ApplicationArea = All;
                    Visible = FALSE;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Manual field.';
                }
                field(Vendor; Rec.Vendor)
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Vendor field.';
                }
                field("Codigo Unidad"; Rec."Codigo Unidad")
                {
                    ApplicationArea = All;
                    Visible = FALSE;
                    Editable = FALSE;
                    ToolTip = 'Specifies the value of the Codigo Unidad field.';
                }
                field("Unidad UN20"; Rec."Unidad UN20")
                {
                    ApplicationArea = All;
                    Visible = FALSE;
                    Editable = FALSE;
                    ToolTip = 'Specifies the value of the Unidad UN20 field.';
                }
                field(Pendiente; Rec.Pendiente)
                {
                    ApplicationArea = All;
                    Visible = false;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Pendiente field.';
                }
            }
        }
    }
}
