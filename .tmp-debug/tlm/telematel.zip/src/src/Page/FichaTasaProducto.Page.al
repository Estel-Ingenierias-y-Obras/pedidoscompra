Page 58027 "Ficha Tasa Producto"
//P_58027_Ficha_Tasa_Producto
{
    SourceTable = "Tasa Producto";
    PageType = Card;

    layout
    {
        area(Content)
        {
            group(General)
            {
                field(Codigo; Rec.Codigo)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Código field.';
                }
                field("Tipo Aplicacion"; Rec."Tipo Aplicacion")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Tipo Aplicación field.';
                }
                field(Cuenta; Rec.Cuenta)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Cuenta field.';
                }
                field(Blocked; Rec.Blocked)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Bloqueado field.';
                }
                field(Descripcion; Rec.Descripcion)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Descripción field.';
                }
                field("VAT Prod. Posting Group"; Rec."VAT Prod. Posting Group")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Grupo registro IVA prod. field.';
                }
                field("Global Dimension 1 Code"; Rec."Global Dimension 1 Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Cód. dimensión global 1 field.';
                }
                field("Global Dimension 2 Code"; Rec."Global Dimension 2 Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Cód. dimensión global 2 field.';
                }
                part(Lineas; "Subf Importe Tasa Producto")
                {
                    ApplicationArea = All;
                    SubPageLink = "Codigo Tasa/Prod" = FIELD(Codigo);
                }
            }
        }
    }
    actions
    {
        area(Navigation)
        {
            group(Ficha)
            {
                CaptionML = ESP = '&Ficha';
                Image = Card;

                action(Dimensiones)
                {
                    ApplicationArea = All;
                    ShortCutKey = 'Shift+Ctrl+D';
                    CaptionML = ESP = 'Dimensiones';
                    Image = Dimensions;
                    ToolTip = 'Executes the Dimensiones action.';

                    trigger OnAction()
                    begin
                        Rec.ShowDims();
                        CurrPage.UPDATE();
                    end;
                }
                action(Productos)
                {
                    ApplicationArea = All;
                    Image = Item;
                    ToolTip = 'Executes the Productos action.';

                    trigger OnAction()
                    begin
                        Rec.ShowProductos();
                    end;
                }
            }
        }
    }
}
