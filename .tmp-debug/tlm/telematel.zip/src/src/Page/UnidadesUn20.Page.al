Page 58022 "Unidades Un20"
{
    //P_58022_Unidades_Un20
    ApplicationArea = all;
    UsageCategory = Lists;
    // InsertAllowed = false;
    InsertAllowed = true;
    // DeleteAllowed = false;    
    DeleteAllowed = true;
    SourceTable = "Unidades UN20";
    PageType = List;

    layout
    {
        area(Content)
        {
            repeater(Repeaer)
            {
                field("UN20 Code"; Rec."UN20 Code")
                {
                    ApplicationArea = All;
                    // Editable = false;
                    Editable = true;
                    ToolTip = 'Specifies the value of the Código UN20 field.';
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = All;
                    // Editable = false;
                    Editable = true;
                    ToolTip = 'Specifies the value of the Descripción field.';
                }
                field("Telematel Code"; Rec."Telematel Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Código Telmatel field.';
                }
                field("NAV Code"; Rec."NAV Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Código BC field.';
                }
            }
        }
    }
    // actions
    // {
    //     area(Processing)
    //     {
    //         action(ActionName)
    //         {
    //             Visible = false;
    //             ApplicationArea = All;
    //             ShortCutKey = 'Ctrl+A';
    //             CaptionML = ESP = 'Importar CSV', ESM = 'Importar XML';
    //             RunObject = XMLport "Imp Unidades UN20";
    //             Promoted = true;
    //             Image = XMLFile;
    //             PromotedCategory = Process;
    //             trigger OnAction()
    //             var
    //             //LText00001: TextConst 'ESP=Función completada;ESM=Funci¢n completada';
    //             begin
    //             end;
    //         }
    //     }
    // }
}
