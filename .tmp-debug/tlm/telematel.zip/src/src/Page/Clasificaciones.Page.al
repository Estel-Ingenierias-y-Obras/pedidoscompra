Page 58026 Clasificaciones
//P_58026_Clasificaciones
{
    SaveValues = true;
    SourceTable = Clasificaciones;
    PageType = List;

    layout
    {
        area(Content)
        {
            repeater(repeater)
            {
                field(Id; Rec.Id)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Id field.';
                }
                field("Tipo Clasificacion"; Rec."Tipo Clasificacion")
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Tipo Clasificacion field.';
                }
                field("Desc.Codigo Clasificacion"; Rec."Desc.Codigo Clasificacion")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Código Clasificación field.';
                }
                field(Nivel; Rec.Nivel)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Nivel field.';
                }
                field(Descripcion; Rec.Descripcion)
                {
                    ApplicationArea = All;
                    AssistEdit = true;
                    ToolTip = 'Specifies the value of the Descripcion field.';

                    trigger OnAssistEdit()
                    begin
                        Rec.VerSubniveles();
                    end;
                }
                field("Id Subordinado"; Rec."Id Subordinado")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Id Subordinado field.';
                }
                field("Id Telematel"; Rec."Id Telematel")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Id Telematel field.';
                }
                field(Orden; Rec.Orden)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Orden field.';
                }
            }
        }
    }
}
