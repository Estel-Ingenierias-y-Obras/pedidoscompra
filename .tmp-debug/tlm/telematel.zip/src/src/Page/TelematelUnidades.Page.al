page 58003 "Telematel Unidades"
{
    ApplicationArea = All;
    UsageCategory = Lists;
    SourceTable = "Telematel Unidades";
    PageType = List;

    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field("Codigo TLM"; rec."Codigo TLM")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Codigo TLM field.';
                }
                field("Codigo Nav"; Rec."Codigo Nav")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Codigo BC field.';
                }
                field(Descripcion; Rec.Descripcion)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Descripcion field.';
                }
            }
        }
    }
    // actions
    // {
    //     area(Processing)
    //     {
    //         action(ActionName)
    //         {
    //             ApplicationArea = All;
    //             ShortCutKey = "Ctrl+A";
    //             CaptionML = ESP = 'Importar CSV', ESM = 'Importar XML';
    //             RunObject = XMLport "Imp Unidades GoCatalog";
    //             Promoted = true;
    //             Image = XMLFile;
    //             PromotedCategory = Process;
    //             trigger OnAction()
    //             var
    //                 LText00001: TextConst ESP = 'Función completada', ESM = 'Función completada';
    //             begin
    //             end;
    //         }
    //     }
    // }
    //     var
    //         T00001: TextConst ESP = 'Proceso Terminado', ESM = 'Proceso Terminado';
}
