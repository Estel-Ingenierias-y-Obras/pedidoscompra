page 58002 "Clasificaciones Lookup"
{
    Editable = false;
    CaptionML = ESP = 'Clasificaciones';
    SourceTable = Clasificaciones;
    SourceTableView = SORTING(Nivel, Orden);
    PageType = StandardDialog;
    ShowFilter = true;

    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {

                field(Id; Rec.Id)
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Id field.';
                }
                field("Desc.Codigo Clasificacion"; Rec."Desc.Codigo Clasificacion")
                {
                    ApplicationArea = All;
                    Lookup = false;
                    ToolTip = 'Specifies the value of the Código Clasificación field.';
                }
                field(Nivel; Rec.Nivel)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Nivel field.';
                }
                field(Descripcion; Rec.Descripcion)
                {
                    ApplicationArea = All;
                    ColumnSpan = 3;
                    ToolTip = 'Specifies the value of the Descripcion field.';

                    trigger OnLookup(var Text: Text): Boolean
                    var
                    begin
                        Rec.VerSubniveles();
                    end;
                }
                field("Id Subordinado"; Rec."Id Subordinado")
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Id Subordinado field.';
                }
                field("Id Telematel"; Rec."Id Telematel")
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Id Telematel field.';
                }
                field(Orden; Rec.Orden)
                {
                    ApplicationArea = All;
                    Visible = false;
                    ToolTip = 'Specifies the value of the Orden field.';
                }
            }
        }
    }
}
