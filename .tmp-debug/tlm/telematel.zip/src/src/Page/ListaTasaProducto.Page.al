Page 58019 "Lista Tasa Producto"
{
    //P_58019_Lista_Tasa_Producto
    SourceTable = "Tasa Producto";
    PageType = List;
    CardPageID = "Ficha Tasa Producto";

    layout
    {
        area(Content)
        {
            repeater(Repeater)
            {
                ShowCaption = false;
                Editable = false;

                field(Codigo; Rec.Codigo)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Código field.';
                }
                field(Descripcion; Rec.Descripcion)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Descripción field.';
                }
                field("VAT Prod. Posting Group"; Rec."VAT Prod. Posting Group")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Grupo registro IVA prod. field.';
                }
                field("Global Dimension 1 Code"; Rec."Global Dimension 1 Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Cód. dimensión global 1 field.';
                }
                field("Global Dimension 2 Code"; Rec."Global Dimension 2 Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Cód. dimensión global 2 field.';
                }
                field("Tipo Aplicacion"; Rec."Tipo Aplicacion")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Tipo Aplicación field.';
                }
                field(Cuenta; Rec.Cuenta)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Cuenta field.';
                }
                field(Blocked; Rec.Blocked)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Bloqueado field.';
                }
            }
        }
    }
    actions
    {
        area(Navigation)
        {
            group(Linea)
            {
                CaptionML = ENU = '&Line', ESP = '&Línea';

                action(Ficha)
                {
                    ApplicationArea = All;
                    ShortCutKey = 'Shift+F5';
                    CaptionML = ENU = 'Card', ESP = 'Ficha';
                    Image = Card;
                    ToolTip = 'Executes the Ficha action.';

                    trigger OnAction()
                    begin
                        PAGE.RUN(PAGE::"Ficha Tasa Producto", Rec);
                    end;
                }
                action(Dimensiones)
                {
                    ApplicationArea = All;
                    ShortCutKey = 'Shift+Ctrl+D';
                    Image = Dimensions;
                    ToolTip = 'Executes the Dimensiones action.';

                    trigger OnAction()
                    begin
                        Rec.ShowDims();
                        CurrPage.UPDATE();
                    end;
                }
                action(Productos)
                {
                    ApplicationArea = All;
                    Image = Item;
                    ToolTip = 'Executes the Productos action.';

                    trigger OnAction()
                    begin
                        Rec.ShowProductos();
                    end;
                }
            }
        }
    }
}
