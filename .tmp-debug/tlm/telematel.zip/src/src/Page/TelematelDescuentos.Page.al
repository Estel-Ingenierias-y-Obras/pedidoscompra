Page 58020 "Telematel Descuentos"
{
    //P_58020_Telematel_Descuentos
    SourceTable = "Telematel Descuentos";
    PopulateAllFields = true;
    PageType = List;

    layout
    {
        area(Content)
        {
            repeater(Repeater)
            {
                field("Id Marca"; Rec."Id Marca")
                {
                    ApplicationArea = All;
                    Visible = IdMarcaVisible;
                    Editable = IdMarcaVisible;
                    ToolTip = 'Specifies the value of the Id Marca field.';
                }
                field(Vendor; Rec.Vendor)
                {
                    ApplicationArea = All;
                    Visible = VendorVisible;
                    Editable = VendorVisible;
                    ToolTip = 'Specifies the value of the Vendor field.';
                }
                field("Tipo Descuento"; Rec."Tipo Descuento")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Tipo Descuento field.';

                    trigger OnValidate()
                    BEGIN
                        TipoDescuentoOnAfterValidate();
                    END;
                }
                field("Codigo Dto"; wCodDto)
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Codigo Dto.', ESM = 'Codigo Dto.';
                    Editable = Rec."Tipo Descuento" <> Rec."Tipo Descuento"::Marca;
                    ToolTip = 'Specifies the value of the wCodDto field.';

                    trigger OnValidate()
                    BEGIN
                        Rec.SetValDto(wCodDto);
                        wCodDto := Rec.GetValDto();
                    END;

                    trigger OnLookup(var wCodDto: Text): Boolean
                    BEGIN
                        Rec.ValLookup();
                        wCodDto := Rec.GetValDto();
                    END;
                }
                field(GetDescription; Rec.GetDescription())
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Descripción', ESM = 'Descripción';
                    ToolTip = 'Specifies the value of the GetDescription field.';
                }
                field("Currency Code"; Rec."Currency Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Currency Code field.';
                }
                field("Starting Date"; Rec."Starting Date")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Starting Date field.';
                }
                field("Line Discount %"; Rec."Line Discount %")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Line Discount % field.';
                }
                field("Minimum Quantity"; Rec."Minimum Quantity")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Minimum Quantity field.';
                }
                field("Ending Date"; Rec."Ending Date")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Ending Date field.';
                }
                field("Unit of Measure Code"; Rec."Unit of Measure Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Unit of Measure Code field.';
                }
                field("Variant Code"; Rec."Variant Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Variant Code field.';
                }
            }
        }
    }
    trigger OnInit()
    BEGIN
        IdMarcaVisible := TRUE;
        VendorVisible := TRUE;
    END;

    trigger OnOpenPage()
    BEGIN
        VendorVisible := Rec.GETFILTER(Vendor) = '';
        IdMarcaVisible := Rec.GETFILTER("Id Marca") = '';
    END;

    trigger OnAfterGetRecord()
    BEGIN
        wCodDto := Rec.GetValDto();
    END;

    trigger OnAfterGetCurrRecord()
    BEGIN
        wCodDto := Rec.GetValDto();
    END;

    VAR
        wCodDto: Code[20];       
        VendorVisible: Boolean;
        IdMarcaVisible: Boolean;

    LOCAL PROCEDURE TipoDescuentoOnAfterValidate();
    BEGIN
        wCodDto := Rec.GetValDto();
    END;
}
