Page 58021 "Cod. Clasificaciones"
{
    //P_58021_Cod_Clasificaciones
    ApplicationArea = All;
    UsageCategory = Lists;
    InsertAllowed = false;
    ModifyAllowed = false;
    SourceTable = "Tipos Clasificacion";
    PromotedActionCategoriesML = ESP = 'Nuevo, Acciones, Reports, Navegar';

    layout
    {
        area(Content)
        {
            repeater(Repeater)
            {

                field(Id; Rec.Id)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Id field.';
                }
                field(Nombre; Rec.Nombre)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Nombre field.';
                }
                field("Tipo Go Catalog"; Rec."Tipo Go Catalog")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Tipo Go Catalog field.';
                }
            }
        }
    }
    actions
    {
        area(Processing)
        {
            action(ActionName)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Actualizar Clasificaciones';
                Promoted = true;
                PromotedIsBig = true;
                Image = UpdateXML;
                PromotedCategory = Process;
                ToolTip = 'Executes the ActionName action.';

                trigger OnAction()
                begin
                    cGestGoCat.UpdateClassificacions();
                end;
            }
        }
        area(Navigation)
        {
            action(Clasificaciones)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Clasificaciones';
                Promoted = true;
                PromotedIsBig = true;
                Image = CodesList;
                PromotedCategory = Category4;
                ToolTip = 'Executes the Clasificaciones action.';

                trigger OnAction()
                begin
                    Rec.ShowClasificaciones(Rec.Id);
                end;
            }
        }
    }
    VAR
        cGestGoCat: Codeunit GestGoCatalog;
}
