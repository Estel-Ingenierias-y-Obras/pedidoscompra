page 58012 "Go Catalog Connection Log"
{
    ApplicationArea = All;
    UsageCategory = Administration;
    CaptionML = ESP = 'Conexiones Go Catalog';
    InsertAllowed = false;
    ModifyAllowed = false;
    SourceTable = "Go Catalog Connection Log";
    SourceTableView = SORTING(Id) ORDER(Descending);
    PageType = List;
    PromotedActionCategoriesML = ESP = 'Nuevo, Acciones, Reports, Navegar';

    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field(Date; Rec.Date)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Date field.';
                }
                field(Intento; Rec.Intento)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Intento field.';
                }
                field(InitCnt; Rec.InitCnt)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Inicio field.';
                }
                field(EndCnt; Rec.EndCnt)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Fin field.';
                }
                field(Duration; Rec.Duration)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Duración field.';
                }
                field(Result; Rec.Result)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Resultado field.';
                }
                field(GetError; Rec.GetError())
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Texto de Error';
                    ToolTip = 'Specifies the value of the GetError field.';
                }
            }
        }
    }
    actions
    {
        area(Processing)
        {
            action(Actualizar)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Actualizar';
                Promoted = true;
                PromotedIsBig = true;
                Image = WorkCenterLoad;
                PromotedCategory = Process;
                ToolTip = 'Executes the Actualizar action.';

                trigger OnAction()
                begin
                    //cGestGoCat.ManualUpdateAllBrands();
                    IF CONFIRM(Text001Txt, FALSE) THEN CODEUNIT.RUN(CODEUNIT::UpdateDataTelematel);
                end;
            }
            action(LanzarCorreo)
            {
                ApplicationArea = All;
                Visible = False;
                ToolTip = 'Executes the LanzarCorreo action.';

                trigger OnAction()
                var
                    cTLMMail: Codeunit "ErrorMailTelematel";
                begin
                    cTLMMail.SendMail(Rec);
                end;
            }
        }
    }
    var
        Text001Txt: TextConst ESP = '¿Desea lanzar una nueva actualización Telematel?';
}
