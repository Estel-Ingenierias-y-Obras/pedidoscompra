page 58004 "Telematel Series Estel"
{
    Caption = 'Telematel Series';
    SourceTable = "Telematel Series Estel";
    //     PopulateAllFields = true;
    PageType = List;
    //     //
    ApplicationArea = All;
    UsageCategory = Lists;

    //     //
    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field(Codigo; Rec.Codigo)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Codigo field.';
                }
                field(Descripcion; Rec.Descripcion)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Descripcion field.';
                }
                field("Precio Libre"; Rec."Precio Libre")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the value of the Precio Libre field.';
                }
            }
        }
    }
    actions
    {
        area(Processing)
        {
            // CaptionML =ESP='Opciones',ESM='Opciones';
            action(Articulos)
            {
                ApplicationArea = All;
                shortCutKey = "Ctrl+F10";
                CaptionML = ESP = 'Articulos', ESM = 'Articulos';
                RunObject = Page "Telematel Articulos";
                RunPageLink = "Id Marca" = FIELD("Id Marca"), "Series Estel" = FIELD(Codigo);
                Image = Item;
                ToolTip = 'Executes the Articulos action.';

                trigger OnAction()
                begin
                end;
            }
            action(AnadirArticulos)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Añadir Articulos';
                Image = NewItem;
                ToolTip = 'Executes the AnadirArticulos action.';

                trigger OnAction()
                begin
                    Rec.AnadirArticulos();
                end;
            }
        }
    }
}
