page 58001 "Filtros Clasificacion"
{
    PageType = StandardDialog;

    layout
    {
        area(Content)
        {
            group(GroupName)
            {
                ShowCaption = false;

                field(fieldGetFiltroCodClassText; GetFiltroCodClassText())
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Tipo de Clasificación';
                    ToolTip = 'Specifies the value of the GetFiltroCodClassText field.';

                    trigger OnAssistEdit()
                    VAR
                        lrCodsCl: Record "Tipos Clasificacion";
                    BEGIN
                        IF PAGE.RUNMODAL(0, lrCodsCl) = ACTION::LookupOK THEN BEGIN
                            TempwTempClaArt.SETRANGE("Codigo Clasificacion", lrCodsCl.Id);
                            CLEAR(wFiltroClassId);
                            CLEAR(wFiltroClass);
                        END;
                    END;
                }
                grid(Filtro)
                {
                    CaptionML = ESP = 'Filtro Clasificación';
                    GridLayout = Rows;

                    group(Clas1)
                    {
                        CaptionML = ESP = 'Clasificación 1';

                        field(wFiltroClassId1; wFiltroClassId[1])
                        {
                            ShowCaption = false;
                            AssistEdit = true;
                            BlankZero = true;
                            ColumnSpan = 1;
                            ApplicationArea = All;

                            trigger OnValidate()
                            begin
                                FindLevel(1, wFiltroClassId[1]);
                            end;

                            trigger OnAssistEdit()
                            begin
                                LookupLevel(1);
                            end;
                        }
                        field(wFiltroClass1; wFiltroClass[1])
                        {
                            ApplicationArea = All;
                            Editable = false;
                            ColumnSpan = 3;
                            ShowCaption = false;
                        }
                    }
                    group(Clas2)
                    {
                        CaptionML = ESP = 'Clasificación 2';

                        field(wFiltroClassId2; wFiltroClassId[2])
                        {
                            ShowCaption = false;
                            AssistEdit = true;
                            BlankZero = true;
                            ColumnSpan = 1;
                            ApplicationArea = All;

                            trigger OnValidate()
                            begin
                                FindLevel(2, wFiltroClassId[2]);
                            end;

                            trigger OnAssistEdit()
                            begin
                                LookupLevel(2);
                            end;
                        }
                        field(wFiltroClass2; wFiltroClass[2])
                        {
                            ApplicationArea = All;
                            Editable = false;
                            ColumnSpan = 3;
                            ShowCaption = false;
                        }
                    }
                    group(Clas3)
                    {
                        CaptionML = ESP = 'Clasificación 3';

                        field(wFiltroClassId3; wFiltroClassId[3])
                        {
                            ShowCaption = false;
                            AssistEdit = true;
                            BlankZero = true;
                            ColumnSpan = 1;
                            ApplicationArea = All;

                            trigger OnValidate()
                            begin
                                FindLevel(3, wFiltroClassId[3]);
                            end;

                            trigger OnAssistEdit()
                            begin
                                LookupLevel(3);
                            end;
                        }
                        field(wFiltroClass3; wFiltroClass[3])
                        {
                            ApplicationArea = All;
                            Editable = false;
                            ColumnSpan = 3;
                            ShowCaption = false;
                        }
                    }
                }
            }
        }
    }
    var
        TempwTempClaArt: Record "Clasificacion Articulos" TEMPORARY;
        wFiltroClass: ARRAY[3] OF Text;
        wFiltroClassId: ARRAY[3] OF Integer;

    LOCAL PROCEDURE LookupLevel(pwLevel: Integer);
    VAR
        lrClass: Record "Clasificaciones";
        lwParentId: Integer;
        lwVal: Integer;
    BEGIN
        IF pwLevel > 1 THEN BEGIN
            lwParentId := wFiltroClassId[pwLevel - 1];
            IF lwParentId = 0 THEN EXIT;
        END
        ELSE
            lwParentId := 0;
        CLEAR(lrClass);
        lrClass.SETRANGE(Nivel, pwLevel);
        lrClass.SETRANGE("Id Subordinado", lwParentId);
        TempwTempClaArt.COPYFILTER("Codigo Clasificacion", lrClass."Tipo Clasificacion");
        lwVal := wFiltroClassId[pwLevel];
        IF lwVal > 0 THEN lrClass.GET(lwVal);
        //IF PAGE.RUNMODAL(50153,lrClass) = ACTION::Yes THEN BEGIN
        IF PAGE.RUNMODAL(Page::"Clasificaciones Lookup", lrClass) = ACTION::LookupOK THEN BEGIN
            FiltraLevel(pwLevel, lrClass.Id, lrClass.Descripcion);
            TempwTempClaArt.SETRANGE("Codigo Clasificacion", lrClass."Tipo Clasificacion");
        END;
    END;

    PROCEDURE FindLevel(pwLevel: Integer; pwId: Integer);
    VAR
        lrClasf: Record "Clasificaciones";
        lwName: Text;
        lwParentId: Integer;
    BEGIN
        CLEAR(lwName);
        CLEAR(lrClasf);
        IF pwId > 0 THEN BEGIN
            lwParentId := 0;
            IF pwLevel > 1 THEN lwParentId := wFiltroClassId[pwLevel - 1];
            // De paso comprobamos coherencia
            lrClasf.SETRANGE("Id Subordinado", lwParentId);
            lrClasf.SETRANGE(Id, pwId);
            lrClasf.SETRANGE(Nivel, pwLevel);
            lrClasf.FINDFIRST();
            lwName := lrClasf.Descripcion;
        END;
        FiltraLevel(pwLevel, pwId, lwName);
    END;

    LOCAL PROCEDURE FiltraLevel(pwLevel: Integer; pwId: Integer; pwName: Text);
    BEGIN
        AsingLevel(pwLevel, pwId, pwName);
    END;

    LOCAL PROCEDURE AsingLevel(pwLevel: Integer; pwId: Integer; pwDescription: Text);
    VAR
        lwId: Integer;
    BEGIN
        // AsingLevel
        IF pwId = 0 THEN pwDescription := '';
        wFiltroClassId[pwLevel] := pwId;
        wFiltroClass[pwLevel] := pwDescription;
        IF pwLevel < 3 THEN
            FOR lwId := pwLevel + 1 TO 3 DO AsingLevel(lwId, 0, '');
    END;

    PROCEDURE GetValues(VAR pwFiltrosNom: ARRAY[3] OF Text; VAR pwFiltrosId: ARRAY[3] OF Integer);
    VAR
        lwId: Integer;
    BEGIN
        //COPYARRAY(pwFiltrosId , wFiltroClassId, 1);
        //COPYARRAY(pwFiltrosNom, wFiltroClass, 1);
        FOR lwId := 1 TO 3 DO BEGIN
            pwFiltrosId[lwId] := wFiltroClassId[lwId];
            pwFiltrosNom[lwId] := wFiltroClass[lwId];
        END;
    END;

    PROCEDURE SetValues(pwFiltrosNom: ARRAY[3] OF Text; pwFiltrosId: ARRAY[3] OF Integer);
    BEGIN
        COPYARRAY(wFiltroClassId, pwFiltrosId, 1);
        COPYARRAY(wFiltroClass, pwFiltrosNom, 1);
    END;

    PROCEDURE CopyFilterCodClas(VAR pwTempClaArt: Record "Clasificacion Articulos");
    BEGIN
        TempwTempClaArt.COPYFILTERS(pwTempClaArt);
    END;

    PROCEDURE GetFilterCodClas(VAR pwTempClaArt: Record "Clasificacion Articulos");
    BEGIN
        pwTempClaArt.COPYFILTERS(TempwTempClaArt);
    END;

    PROCEDURE GetFiltroCodClassText() wText: Text;
    VAR
        lrCodlasf: Record "Tipos Clasificacion";
        lwFilt: Integer;
    BEGIN
        wText := '';
        IF TempwTempClaArt.GETFILTER("Codigo Clasificacion") <> '' THEN BEGIN
            lwFilt := TempwTempClaArt.GETRANGEMIN("Codigo Clasificacion");
            IF lrCodlasf.GET(lwFilt) THEN
                wText := STRSUBSTNO('%1 - %2', lrCodlasf.Id, lrCodlasf.Nombre);
        END;
    END;
}
