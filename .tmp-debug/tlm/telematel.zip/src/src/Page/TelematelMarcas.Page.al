Page 58018 "Telematel Marcas"
{
    //P_58018_Telematel_Marcas
    //BORRAR
    ApplicationArea = All;
    UsageCategory = Lists;
    //BORRAR
    SourceTable = "Telematel Marcas";
    PageType = List;
    PromotedActionCategoriesML = ESP = 'Nuevo, Acciones, Reports, Navegar';

    layout
    {
        area(Content)
        {
            repeater(Group)
            {
                field(Id; Rec.Id)
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Id field.';
                }
                field(Codigo; Rec.Codigo)
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Código field.';
                }
                field(IdEntidad; Rec.IdEntidad)
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Id Entidad field.';
                }
                field(NomEntidad; Rec.NomEntidad)
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Nombre Entidad field.';
                }
                field(Origen; Rec.Origen)
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Origen field.';
                }
                field(wImportar; wImportar)
                {
                    ApplicationArea = All;
                    CaptionML = ESP = 'Importar';
                    Editable = ImportarEditable;
                    ToolTip = 'Specifies the value of the wImportar field.';

                    trigger OnValidate()
                    BEGIN
                        Rec.UltimaActualizacion := CURRENTDATETIME;
                        Rec.VALIDATE(Importar, wImportar);
                        CurrPage.UPDATE();
                    END;
                }
                field(Eliminada; Rec.Eliminada)
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Eliminada field.';
                }
                field(Perdido; Rec.Perdido)
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Perdido field.';
                }
                field(UltimaActualizacion; Rec.UltimaActualizacion)
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the value of the UltimaActualizacion field.';
                }
                field("Ultima Actualizacion GOCAT"; Rec."Ultima Actualizacion GOCAT")
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the value of the Ultima Actualizacion GOCAT field.';
                }
            }
        }
    }
    actions
    {
        area(Processing)
        {
            action(Actualizar)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Actualizar Marca', ESM = 'Actualizar';
                ShortCutKey = 'Ctrl+A';
                Promoted = true;
                Enabled = wImportar;
                PromotedIsBig = true;
                PromotedCategory = Process;
                Image = UpdateXML;
                ToolTip = 'Executes the Actualizar action.';

                trigger OnAction()
                begin
                    // Llama a las funciones de importación de marcas de Telematel
                    cGestGoCat.UpdateBrand(Rec);
                end;
            }
            action("Actualizar Todas")
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Actualizar Todas';
                Image = WorkCenterLoad;
                ToolTip = 'Executes the Actualizar Todas action.';

                trigger OnAction()
                begin
                    //cGestGoCat.ManualUpdateAllBrands();
                    CODEUNIT.RUN(CODEUNIT::UpdateDataTelematel);
                end;
            }
        }
        area(Navigation)
        {
            action(Articulos)
            {
                ApplicationArea = All;
                ShortCutKey = 'F10';
                CaptionML = ESP = 'Artículos', ESM = 'Ver Artículos';
                Promoted = true;
                PromotedIsBig = true;
                Image = Item;
                PromotedCategory = Category4;
                ToolTip = 'Executes the Articulos action.';

                trigger OnAction()
                var
                    lrArt: Record "Telematel Articulos";
                begin
                    CLEAR(lrArt);
                    lrArt.SETCURRENTKEY("Id Marca", CodArt);
                    lrArt.FILTERGROUP(2);
                    lrArt.SETRANGE("Id Marca", Rec.Id);
                    lrArt.FILTERGROUP(0);
                    PAGE.RUN(0, lrArt);
                end;
            }
            action(Descuentos)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Descuentos', ESM = 'Descuentos';
                RunObject = Page "Telematel Descuentos";
                RunPageLink = "Id Marca" = FIELD(Id);
                Promoted = true;
                PromotedIsBig = true;
                Image = Discount;
                PromotedCategory = Category4;
                ToolTip = 'Executes the Descuentos action.';
            }
            action(Serie)
            {
                ApplicationArea = All;
                CaptionML = ESP = 'Serie Estel', ESM = 'Serie Estel';
                RunObject = Page "Telematel Series Estel";
                RunPageLink = "Id Marca" = FIELD(Id);
                Image = SerialNo;
                ToolTip = 'Executes the Serie action.';
            }
        }
    }
    VAR
        cGestGoCat: Codeunit GestGoCatalog;
        ImportarEditable: Boolean;
        wImportar: Boolean;

    trigger OnInit()
    BEGIN
        ImportarEditable := TRUE;
    END;

    trigger OnAfterGetRecord()
    BEGIN
        ReadRegister();
    END;

    trigger OnNewRecord(BelowxRec: Boolean)
    BEGIN
        ReadRegister();
    END;

    LOCAL PROCEDURE ReadRegister();
    BEGIN
        xRec := Rec;
        wImportar := Rec.Importar;
        SetEnabled();
    END;

    PROCEDURE SetEnabled();
    BEGIN
        ImportarEditable := Rec.Origen = Rec.Origen::Telematel;
    END;
}
