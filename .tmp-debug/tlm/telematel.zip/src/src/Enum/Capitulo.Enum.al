enum 58002 Capitulo
{
    Extensible = true;

    value(0; "Sin Capítulo")
    {
    }
    value(1; Electricidad)
    {
    }
    value(2; Telecomunicaciones)
    {
    }
    value(3; Climatizacion)
    {
    Caption = 'Climatización';
    }
    value(4; Fontaneria)
    {
    Caption = 'Fontanería';
    }
    value(5; Contraincendios)
    {
    }
    value(6; "Utillaje y Varios")
    {
    }
}
