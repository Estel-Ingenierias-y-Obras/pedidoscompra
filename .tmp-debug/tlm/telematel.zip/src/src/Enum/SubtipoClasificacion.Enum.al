enum 58000 "Subtipo Clasificacion"
{
    Extensible = true;

    value(0; "None")
    {
    }
    value(1; Telematel)
    {
    }
    value(2; "Brand")
    {
    }
}
