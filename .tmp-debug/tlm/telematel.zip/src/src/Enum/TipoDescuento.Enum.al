enum 58006 "Tipo Descuento"
{
    Extensible = true;

    value(0; Marca)
    {
    }
    value(1; Serie)
    {
    }
    value(2; Articulo)
    {
    }
}
