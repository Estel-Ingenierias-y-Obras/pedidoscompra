enum 58005 "GoCat Referencia Tipo"
{
    Extensible = true;

    value(0; "No Definida")
    {
    }
    value(1; Imagen)
    {
    }
    value(2; WebPage)
    {
    }
}
