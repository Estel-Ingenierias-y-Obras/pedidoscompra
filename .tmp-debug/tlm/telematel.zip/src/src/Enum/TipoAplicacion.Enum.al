enum 58001 "Tipo Aplicacion"
{
    Extensible = true;

    value(0; "Importe Fijo")
    {
    }
    value(1; "% Base")
    {
    }
    value(2; "% IVA Inc")
    {
    }
}
