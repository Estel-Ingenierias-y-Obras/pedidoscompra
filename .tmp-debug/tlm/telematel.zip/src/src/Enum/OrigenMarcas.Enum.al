enum 58003 "Origen Marcas"
{
    Extensible = true;

    value(0; Telematel)
    {
    }
    value(1; Excel)
    {
    }
}
