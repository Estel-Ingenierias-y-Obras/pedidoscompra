enum 58004 "GoCat Log Status"
{
    Extensible = true;

    value(0; Pending)
    {
    }
    value(1; OK)
    {
    }
    value(2; Error)
    {
    }
}
