table 58008 "Telematel Setup"
{
    DataClassification = ToBeClassified;

    fields
    {
        field(1; Id; Code[1])
        {
        }
        field(10; Loaded; Boolean)
        {
        }
        field(100; "Items Serie"; code[20])
        {
            CaptionML = ESP = 'Serie Artículo', ESM = 'Serie Artículo';
            TableRelation = "No. Series";
        }
        field(120; "Inventory Posting"; Code[10])
        {
            CaptionML = ENU = 'Inventory Posting Group', ESP = 'Grupo contable existencias';
            TableRelation = "Inventory Posting Group";
        }
        field(121; "Gen. Prod. Posting"; code[10])
        {
            CaptionML = ENU = 'Gen. Prod. Posting Group', ESP = 'Grupo contable producto';
            TableRelation = "Gen. Product Posting Group";
        }
        field(122; Activo; Boolean)
        {
        }
        field(123; "Codigo RAEE"; code[20])
        {
            TableRelation = "Tasa Producto".Codigo;
        }
        field(124; "Ini Act Datos"; DateTime)
        {
        }
        field(125; "Fin Act Datos"; DateTime)
        {
        }
        field(126; "Error Act"; text[250])
        {
        }
        field(127; "Tiempo Maximo"; Integer)
        {
            MinValue = 0;
        }
        field(1000; HashCode; code[20])
        {
            Caption = 'Código Hash';
        }
        field(1001; "GOC Version"; code[20])
        {
        }
        field(1002; "TimeOut"; Integer)
        {
            Caption = 'Time Out';
            MinValue = 0;
        }
        field(1003; "Default Classification Type"; integer)
        {
            Caption = 'Tipo de Clasificación por Defecto';
            TableRelation = "Tipos Clasificacion".Id;
        }
        field(1004; "Default Classification Name"; text[60])
        {
            Editable = False;
            FieldClass = FlowField;
            CalcFormula = Lookup("Tipos Clasificacion".Nombre WHERE(Id = FIELD("Default Classification Type")));
        }
        field(1005; "Log Duration"; DateFormula)
        {
        }
        field(1006; "Productos x Commit"; Integer)
        {
            BlankZero = True;
        }
        field(1007; "Numero Intentos"; Integer)
        {
            Caption = 'Número de Intentos';
            MinValue = 0;
        }
        field(1008; "Tiempo entre Intentos"; integer)
        {
            MinValue = 0;
        }
        field(2000; "Init Process"; DateTime)
        {
        }
        field(2001; "Ent Process"; DateTime)
        {
        }
        field(2010; "Mail Notificacion Error"; text[250])
        {
            Caption = 'Mail Notificacíon de Error';
        }
        field(3000; "URL"; Text[250])
        {
        }
        field(3001; "Port"; Integer)
        {
        }
    }
    keys
    {
        key(Key1; Id)
        {
            Clustered = true;
        }
    }
    procedure GetTiempoMaxText() Result: Text
    Var
        lwDur: Duration;
        lwDTs: array[2] of DateTime;
    begin
        CLEAR(Result);
        IF "Tiempo Maximo" > 0 THEN BEGIN
            CLEAR(lwDTs);
            lwDTs[1] := CURRENTDATETIME;
            lwDTs[2] := lwDTs[1] + ("Tiempo Maximo" * 60000);
            lwDur := lwDTs[2] - lwDTs[1];
            Result := FORMAT(lwDur);
        END;
    end;
}
