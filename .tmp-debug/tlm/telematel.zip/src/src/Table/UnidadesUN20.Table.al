table 58013 "Unidades UN20"
{
    fields
    {
        field(1; "UN20 Code"; code[5])
        {
            Caption = 'Código UN20';
        }
        field(10; Description; text[50])
        {
            Caption = 'Descripción';
        }
        field(20; "NAV Code"; code[10])
        {
            Caption = 'Código BC';
            TableRelation = "Unit of Measure";
        }
        field(30; "Telematel Code"; code[4])
        {
            Caption = 'Código Telmatel';
            TableRelation = "Telematel Unidades"."Codigo TLM";

            trigger OnValidate()
            var
                lrTLMUnds: Record "Telematel Unidades";
            begin
                IF "Telematel Code" <> '' THEN BEGIN
                    CLEAR(lrTLMUnds);
                    IF lrTLMUnds.GET("Telematel Code") THEN
                        IF "Nav Code" = '' THEN "Nav Code" := lrTLMUnds."Codigo Nav";
                END;
            end;
        }
    }
    keys
    {
        key(Key1; "UN20 Code")
        {
            Clustered = true;
        }
    }
}
