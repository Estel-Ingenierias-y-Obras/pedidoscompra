table 58019 "Telematel Descuentos"
{
    LookupPageID = "Telematel Descuentos";
    DrillDownPageID = "Telematel Descuentos";

    fields
    {
        field(1; Id; Integer)
        {
            AutoIncrement = true;
            Editable = false;
        }
        field(3; "Id Marca"; Integer)
        {
            TableRelation = "Telematel Marcas".Id;
        }
        field(5; "Tipo Descuento"; Enum "Tipo Descuento")
        {
            trigger OnValidate()
            begin
                IF "Tipo Descuento" <> xRec."Tipo Descuento" THEN BEGIN
                    "Codigo Dto" := '';
                    "Id Dto" := 0;
                    IF "Tipo Descuento" = "Tipo Descuento"::Marca THEN "Id Dto" := "Id Marca";
                END;
            end;
        }
        field(6; "Codigo Dto"; Code[30])
        {
            trigger OnValidate()
            var
                lrSerie: Record "Telematel Series Estel";
                lrArt: Record "Telematel Articulos";
            begin
                IF "Codigo Dto" = '' THEN EXIT;
                TESTFIELD("Id Marca");
                CASE "Tipo Descuento" OF
                    "Tipo Descuento"::Marca:
                        "Codigo Dto" := '';
                    "Tipo Descuento"::Serie:
                        BEGIN
                            CLEAR(lrSerie);
                            lrSerie.GET("Id Marca", "Codigo Dto");
                        END;
                    "Tipo Descuento"::Articulo:
                        BEGIN
                            CLEAR(lrArt);
                            lrArt.SETRANGE("Id Marca", "Id Marca");
                            lrArt.SETRANGE(CodArt, "Codigo Dto");
#pragma warning disable AA0181
                            lrArt.FindSet();
#pragma warning restore AA0181
                            "Id Dto" := lrArt.Id;
                        END;
                END;
            end;
        }
        field(9; Vendor; Code[20])
        {
            TableRelation = Vendor."No.";
            CaptionML = ENU = 'Vendor', ESP = 'Proveedor';
        }
        field(10; "Id Dto"; Integer)
        {
            trigger OnValidate()
            var
                lrArt: Record "Telematel Articulos";
                lrMarca: Record "Telematel Marcas";
            begin
                IF "Id Dto" = 0 THEN EXIT;
                TESTFIELD("Id Marca");
                CASE "Tipo Descuento" OF
                    "Tipo Descuento"::Marca:
                        BEGIN
                            lrMarca.GET("Id Marca");
                            "Codigo Dto" := lrMarca.Codigo;
                        END;
                    "Tipo Descuento"::Serie:
                        "Id Dto" := 0;
                    "Tipo Descuento"::Articulo:
                        BEGIN
                            CLEAR(lrArt);
                            lrArt.GET("Id Dto");
                            "Codigo Dto" := lrArt.CodArt;
                        END;
                END;
            end;
        }
        field(20; "Currency Code"; Code[10])
        {
            TableRelation = Currency;
            CaptionML = ENU = 'Currency Code', ESP = 'Cod. divisa';
        }
        field(21; "Starting Date"; Date)
        {
            CaptionML = ENU = 'Starting Date', ESP = 'Fecha inicial';

            trigger OnValidate()
            var
            begin
                IF ("Starting Date" > "Ending Date") AND ("Ending Date" <> 0D) THEN ERROR(Text000Txt, FIELDCAPTION("Starting Date"), FIELDCAPTION("Ending Date"));
            end;
        }
        field(22; "Line Discount %"; Decimal)
        {
            CaptionML = ENU = 'Line Discount %', ESP = '% Descuento línea';
            DecimalPlaces = 0 : 5;
            MinValue = 0;
            MaxValue = 100;
        }
        field(23; "Minimum Quantity"; Decimal)
        {
            CaptionML = ENU = 'Minimum Quantity', ESP = 'Cantidad mínima';
            DecimalPlaces = 0 : 5;
            MinValue = 0;
        }
        field(24; "Ending Date"; Date)
        {
            CaptionML = ENU = 'Ending Date', ESP = 'Fecha final';

            trigger OnValidate()
            begin
                VALIDATE("Starting Date");
            end;
        }
        field(25; "Unit of Measure Code"; Code[10])
        {
            TableRelation = "Item Unit of Measure";
            CaptionML = ENU = 'Unit of Measure Code', ESP = 'Cod. unidad medida';
        }
        field(26; "Variant Code"; Code[10])
        {
            TableRelation = "Item Variant";
            CaptionML = ENU = 'Variant Code', ESP = 'Cod. variante';
        }
        field(50; "Manual"; Boolean)
        {
            Description = 'Indica que este precio no ha sido importado, sino creado manualmente por Usuario';
            Editable = false;
        }
    }
    keys
    {
        key(Key1; Id)
        {
            Clustered = true;
        }
        key(Key2; "Id Marca", "Tipo Descuento", "Starting Date", "Ending Date")
        {
        }
        key(Key3; Vendor, "Id Marca", "Tipo Descuento")
        {
        }
    }
    var
        Text000Txt: TextConst ENU = '%1 cannot be after %2', ESP = '%1 no puede ser posterior %2';
        Text001Txt: TextConst ESP = 'Esta línea se está solapando con otra';

    trigger OnInsert()
    begin
        // Comprueba solapamientos
        CompSolp();
    end;

    trigger OnModify()
    begin
        // Comprueba solapamientos
        CompSolp();
    end;
    //     //     trigger OnDelete()
    //     //     begin
    //     //     end;
    //     //     trigger OnRename()
    //     //     begin
    //     //     end;
    PROCEDURE GetValDto() Return: Code[20];
    VAR
        lrMarca: Record "Telematel Marcas";
    BEGIN
        // GetValDto
        CLEAR(Return);
        CASE "Tipo Descuento" OF
            "Tipo Descuento"::Marca:
                IF lrMarca.GET("Id Marca") THEN
                    Return := lrMarca.Codigo;
            "Tipo Descuento"::Articulo:
                IF "Id Dto" <> 0 THEN
                    Return := FORMAT("Id Dto");
            "Tipo Descuento"::Serie:
                Return := CopyStr("Codigo Dto", 1, MaxStrLen(Return));
        END;
    END;

    PROCEDURE SetValDto(pwVal: Code[20]);
    VAR
        lwId: Integer;
    BEGIN
        // SetValDto
        TESTFIELD("Id Marca");
        CASE "Tipo Descuento" OF
            "Tipo Descuento"::Articulo:
                BEGIN
                    IF pwVal = '' THEN pwVal := '0';
                    EVALUATE(lwId, pwVal);
                    VALIDATE("Id Dto", lwId);
                END;
            "Tipo Descuento"::Serie:
                VALIDATE("Codigo Dto", pwVal);
        END;
    END;

    PROCEDURE GetDescription() Return: Text;
    VAR
        lrArt: Record "Telematel Articulos";
        lrSerie: Record "Telematel Series Estel";
        lrMarca: Record "Telematel Marcas";
    BEGIN
        // GetDescription
        IF "Id Marca" = 0 THEN EXIT;
        CASE "Tipo Descuento" OF
            "Tipo Descuento"::Marca:
                BEGIN
                    CLEAR(lrMarca);
                    IF lrMarca.GET("Id Marca") THEN Return := lrMarca.NomEntidad;
                END;
            "Tipo Descuento"::Serie:
                BEGIN
                    CLEAR(lrSerie);
                    IF lrSerie.GET("Id Marca", "Codigo Dto") THEN Return := lrSerie.Descripcion;
                END;
            "Tipo Descuento"::Articulo:
                BEGIN
                    CLEAR(lrArt);
                    IF lrArt.GET("Id Dto") THEN Return := lrArt.Descripcion;
                END;
        END;
    END;

    PROCEDURE ValLookup();
    VAR
        lrArt: Record "Telematel Articulos";
        lrSerie: Record "Telematel Series Estel";
    BEGIN
        // ValLookup
        TESTFIELD("Id Marca");
        CASE "Tipo Descuento" OF
            "Tipo Descuento"::Serie:
                BEGIN
                    CLEAR(lrSerie);
                    lrSerie.SETRANGE("Id Marca", "Id Marca");
                    IF lrSerie.GET("Id Marca", "Codigo Dto") THEN;
                    IF PAGE.RUNMODAL(0, lrSerie) = ACTION::LookupOK THEN VALIDATE("Codigo Dto", lrSerie.Codigo);
                END;
            "Tipo Descuento"::Articulo:
                BEGIN
                    CLEAR(lrArt);
                    lrArt.SETCURRENTKEY("Id Marca");
                    lrArt.SETRANGE("Id Marca", "Id Marca");
                    IF lrArt.GET("Id Dto") THEN;
                    IF PAGE.RUNMODAL(0, lrArt) = ACTION::LookupOK THEN VALIDATE("Id Dto", lrArt.Id);
                END;
        END;
    END;

    PROCEDURE CompSolp();
    VAR
        lrDto: Record "Telematel Descuentos";
    BEGIN
        // CompSolp
        // Comprueba solapamiento
        CLEAR(lrDto);
        lrDto.SETFILTER(Id, '<>%1', Id);
        lrDto.SETRANGE("Id Marca", "Id Marca");
        lrDto.SETRANGE("Tipo Descuento", "Tipo Descuento");
        lrDto.SETRANGE("Id Dto", "Id Dto");
        lrDto.SETRANGE("Codigo Dto", "Codigo Dto");
        IF "Ending Date" <> 0D THEN lrDto.SETFILTER("Starting Date", '<=%1', "Ending Date");
        lrDto.SETFILTER("Ending Date", '>=%1|%2', "Starting Date", 0D);
        IF not lrDto.IsEmpty THEN ERROR(Text001Txt);
    END;
}
