Table 58020 "Otras Direcciones"
{
    //T_58020_Otras_Direcciones
    LookupPageID = "Otras Direcciones";
    DrillDownPageID = "Otras Direcciones";

    fields
    {
        field(2; Code; Code[10])
        {
            CaptionML = ENU = 'Code', ESP = 'Código';
            NotBlank = true;
        }
        field(10; Name; Text[50])
        {
            CaptionML = ENU = 'Name', ESP = 'Nombre';
        }
        field(11; "Name 2"; Text[50])
        {
            CaptionML = ENU = 'Name 2', ESP = 'Nombre 2';
        }
        field(12; Address; Text[50])
        {
            CaptionML = ENU = 'Address', ESP = 'Dirección';
        }
        field(13; "Address 2"; Text[50])
        {
            CaptionML = ENU = 'Address 2', ESP = 'Dirección 2';
        }
        field(14; City; Text[30])
        {
            CaptionML = ENU = 'City', ESP = 'Población';
            TableRelation = IF ("Country/Region Code" = CONST()) "Post Code".City
            ELSE IF ("Country/Region Code" = FILTER(<> '')) "Post Code".City WHERE("Country/Region Code" = FIELD("Country/Region Code"));
            ValidateTableRelation = false;

            //TestTableRelation = false;
            trigger OnValidate()
            BEGIN
                PostCode.ValidateCity(City, "Post Code", County, "Country/Region Code", (CurrFieldNo <> 0) AND GUIALLOWED);
            END;
        }
        field(15; "Post Code"; Code[20])
        {
            CaptionML = ENU = 'Post Code', ESP = 'C.P.';
            TableRelation = IF ("Country/Region Code" = CONST()) "Post Code"
            ELSE IF ("Country/Region Code" = FILTER(<> '')) "Post Code" WHERE("Country/Region Code" = FIELD("Country/Region Code"));
            ValidateTableRelation = false;

            //TestTableRelation = false;
            trigger OnValidate()
            BEGIN
                PostCode.ValidatePostCode(City, "Post Code", County, "Country/Region Code", (CurrFieldNo <> 0) AND GUIALLOWED);
            END;
        }
        field(16; County; Text[30])
        {
            CaptionML = ENU = 'County', ESP = 'Provincia';
        }
        field(17; "Country/Region Code"; Code[10])
        {
            TableRelation = "Country/Region";
            CaptionML = ENU = 'Country/Region Code', ESP = 'Cód. país/región';
        }
        field(18; "Phone No."; Text[30])
        {
            CaptionML = ENU = 'Phone No.', ESP = 'Nº teléfono';
            ExtendedDatatype = PhoneNo;
        }
        field(19; "Telex No."; Text[20])
        {
            CaptionML = ENU = 'Telex No.', ESP = 'Nº télex';
        }
        field(20; "Extension No."; Text[30])
        {
            CaptionML = ENU = 'Extension No.', ESP = 'Nº extensión';
        }
        field(21; "Mobile Phone No."; Text[30])
        {
            CaptionML = ENU = 'Mobile Phone No.', ESP = 'Nº teléfono móvil';
            ExtendedDatatype = PhoneNo;
        }
        field(22; Pager; Text[30])
        {
            CaptionML = ENU = 'Pager', ESP = 'Nº buscapersona';
        }
        field(23; "E-Mail"; Text[80])
        {
            CaptionML = ENU = 'E-Mail', ESP = 'Correo electrónico';
            ExtendedDatatype = EMail;

            trigger OnValidate()
            begin
                IF (Pager = UPPERCASE(xRec."Country/Region Code")) OR (Pager = '') THEN Pager := "Country/Region Code";
            end;
        }
        field(24; "Home Page"; Text[80])
        {
            CaptionML = ENU = 'Home Page', ESP = 'Página Web';
            ExtendedDatatype = URL;
        }
        field(25; "Fax No."; Text[30])
        {
            CaptionML = ENU = 'Fax No.', ESP = 'Nº fax';
        }
        field(26; "Telex Answer Back"; Text[20])
        {
            CaptionML = ENU = 'Telex Answer Back', ESP = 'Nº télex respuesta';
        }
        field(27; "Last Date Modified"; Date)
        {
            CaptionML = ENU = 'Last Date Modified', ESP = 'Fecha últ. modificación';
        }
        field(28; "Search E-Mail"; Code[80])
        {
            CaptionML = ENU = 'Search E-Mail', ESP = 'Correo electrónico de búsqueda';
        }
        field(30; "Location Code"; Code[10])
        {
            TableRelation = Location WHERE("Use As In-Transit" = CONST(false));
            CaptionML = ENU = 'Location Code', ESP = 'Cód. almacén';
        }
    }
    keys
    {
        key(PK; Code)
        {
            Clustered = true;
        }
        key(Name; Name)
        {
        }
    }
    fieldgroups
    {
        fieldgroup(DropDown; Code, Name)
        {
        }
    }
    VAR
        PostCode: Record "Post Code";
        Text011Txt: TextConst ENU = 'Before you can use Online Map, you must fill in the Online Map Setup window.\See Setting Up Online Map in Help.', ESP = 'Para poder usar Online Map, primero debe rellenar la ventana Configuración Online Map.\Consulte Configuración de Online Map en la Ayuda.';

    PROCEDURE DisplayMap();
    VAR
        MapPoint: Record "Online Map Setup";
        MapMgt: Codeunit "Online Map Management";
    BEGIN
        IF MapPoint.IsEmpty() THEN
            MapMgt.MakeSelection(DATABASE::"Otras Direcciones", CopyStr(GETPOSITION(), 1, 1000))
        ELSE
            MESSAGE(Text011Txt);
    END;
}
