table 58018 "Telematel Currency"
{
    fields
    {
        field(1; "Code Telematel"; Code[10])
        {
            CaptionML = ENU = 'Code Telematel', ESP = 'Codigo Telematel', ESM = 'Code Telematel';
        }
        field(2; Description; Text[40])
        {
            CaptionML = ENU = 'Description', ESP = 'Descripción', ESM = 'Descripción';
        }
        field(10; "Currency Code"; Code[10])
        {
            TableRelation = Currency;
            CaptionML = ENU = 'Currency Code', ESP = 'Código Divisa', ESM = 'Currency Code';

            trigger OnValidate()
            var
            begin
                IF "Currency Code" <> '' THEN TESTFIELD("Local Currency", FALSE);
            end;
        }
        field(20; "Nav Description"; Text[30])
        {
            FieldClass = FlowField;
            CalcFormula = Lookup(Currency.Description WHERE(Code = FIELD("Currency Code")));
            CaptionML = ENU = 'BC Description', ESP = 'Descripción BC';
            Editable = false;
        }
        field(30; "Local Currency"; Boolean)
        {
            CaptionML = ESP = 'Divisa local';
            Description = 'GOC';

            trigger OnValidate()
            begin
                IF "Local Currency" THEN "Currency Code" := '';
            end;
        }
    }
    keys
    {
        key(Key1; "Code Telematel")
        {
            Clustered = true;
        }
        key(Key2; Description)
        {
        }
    }
    FIELDGROUPS
    {
        fieldgroup(DropDown; "Code Telematel", Description)
        {
        }
    }
    //     var
    //         myInt: Integer;
    //     trigger OnInsert()
    //     begin
    //     end;
    //     trigger OnModify()
    //     begin
    //     end;
    //     trigger OnDelete()
    //     begin
    //     end;
    //     trigger OnRename()
    //     begin
    //     end;
}
