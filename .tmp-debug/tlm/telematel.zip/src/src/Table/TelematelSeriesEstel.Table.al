table 58016 "Telematel Series Estel"
{
    CaptionML = ESP = 'Telematel Series Estel', ESM = 'Telematel Series Estel';
    LookupPageID = "Telematel Series Estel";
    DrillDownPageID = "Telematel Series Estel";

    fields
    {
        field(1; "Id Marca"; Integer)
        {
            TableRelation = "Telematel Marcas";
            BlankNumbers = DontBlank;
        }
        field(2; Codigo; Code[20])
        {
        }
        field(10; Descripcion; Text[30])
        {
        }
        field(50; "Precio Libre"; Boolean)
        {
        }
    }
    keys
    {
        key(Key1; "Id Marca", Codigo)
        {
            Clustered = true;
        }
    }
    FIELDGROUPS
    {
        fieldgroup(DropDown; Codigo, Descripcion)
        {
        }
    }
    var
        TEXT0001Txt: TextConst ESP = 'No es posible renombrar este registro', ESM = 'No es posible renombrar este registro';
        TEXT0002Txt: TextConst ESP = '¿Desea marcar los  %1 articulos seleccionados con el código %2?';
    //     trigger OnInsert()
    //     begin
    //     end;
    //     trigger OnModify()
    //     begin
    //     end;
    //     trigger OnDelete()
    //     begin
    //     end;
    trigger OnRename()
    begin
        ERROR(TEXT0001Txt);
    end;

    PROCEDURE AnadirArticulos();
    VAR
        lrArt: Record "Telematel Articulos";
        lrArt2: Record "Telematel Articulos";
        lfrmArt: Page "Telematel Articulos";
    BEGIN
        // A¤adirArticulos
        // Se a¤adiran articulos en masa a esta serie
        IF Codigo = '' THEN EXIT;
        CLEAR(lrArt);
        lrArt.FILTERGROUP(2);
        lrArt.SETRANGE("Id Marca", "Id Marca");
        lrArt.SETFILTER("Series Estel", '<>%1', Codigo);
        lrArt.FILTERGROUP(0);
        lrArt.SETRANGE("Series Estel", '');
        lfrmArt.LOOKUPMODE := TRUE;
        lfrmArt.SETRECORD(lrArt);
        lfrmArt.SETTABLEVIEW(lrArt);
        IF lfrmArt.RUNMODAL() = ACTION::LookupOK THEN BEGIN
            lfrmArt.GETRECORD(lrArt);
            //DUDA
            //lfrmArt.CopyFilters(lrArt);
            lfrmArt.SetSelectionFilter(lrArt);
            //DUDA
            IF lrArt.COUNT > 0 THEN BEGIN
                IF NOT CONFIRM(TEXT0002Txt, TRUE, lrArt.COUNT, Codigo) THEN EXIT;
                IF lrArt.FINDSET(TRUE) THEN
                    REPEAT
                        lrArt2.COPY(lrArt);
                        lrArt2."Series Estel" := CopyStr(Codigo, 1, MaxStrLen(lrArt2."Series Estel"));
                        lrArt2.MODIFY();
                    UNTIL lrArt.NEXT() = 0;
            END;
        END;
    END;
}
