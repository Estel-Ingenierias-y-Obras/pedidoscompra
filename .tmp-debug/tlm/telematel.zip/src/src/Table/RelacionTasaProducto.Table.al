table 58006 "Relacion Tasa Producto"
{
    fields
    {
        field(1; Id; Integer)
        {
            Editable = False;
            AutoIncrement = true;
        }
        field(2; Item; Code[20])
        {
            Caption = 'Producto';
            NotBlank = true;
            TableRelation = Item."No.";
        }
        field(3; "Codigo Tasa/Prod"; code[20])
        {
            Caption = 'Código Tasa/Producto';
            TableRelation = "Tasa Producto".Codigo;
            NotBlank = true;

            trigger OnValidate()
            begin
                IF ("Codigo Tasa/Prod" <> xRec."Codigo Tasa/Prod") AND (xRec."Codigo Tasa/Prod" <> '') THEN VALIDATE("Id Lin Precio", 0);
            end;
        }
        field(4; "Id Lin Precio"; Integer)
        {
            NotBlank = True;
            TableRelation = "Importe Tasa Producto".Id WHERE("Codigo Tasa/Prod" = FIELD("Codigo Tasa/Prod"));
        }
        field(10; Descripcion; text[30])
        {
            Caption = 'Descripción';
            FieldClass = FlowField;
            CalcFormula = Lookup("Importe Tasa Producto".Descripcion WHERE("Codigo Tasa/Prod" = FIELD("Codigo Tasa/Prod"), Id = FIELD("Id Lin Precio")));
            Editable = False;
        }
        field(20; Importe; decimal)
        {
            Caption = 'Importe';
            Editable = false;
            FieldClass = FlowField;
            CalcFormula = Lookup("Importe Tasa Producto".Importe WHERE("Codigo Tasa/Prod" = FIELD("Codigo Tasa/Prod"), Id = FIELD("Id Lin Precio")));
        }
        field(21; "Descripcion Producto"; text[100])
        {
            Caption = 'Descripción';
            Editable = false;
            FieldClass = FlowField;
            CalcFormula = Lookup(Item.Description WHERE("No." = FIELD(Item)));
        }
        field(22; "Fecha Desde"; Date)
        {
            trigger OnValidate()
            var
            begin
                CheckFechas();
            end;
        }
        field(23; "Fecha Hasta"; Date)
        {
            trigger OnValidate()
            var
            begin
                CheckFechas();
            end;
        }
    }
    keys
    {
        key(Key1; Id)
        {
            Clustered = true;
        }
        key(Key2; Item, "Codigo Tasa/Prod", "Id Lin Precio", "Fecha Desde", "Fecha Hasta")
        {
        }
    }
    var //         rCurExc: record "Currency Exchange Rate";
        Text001Txt: TextConst ESP = 'El artículo %1 ya está relacionado con un código de tasa %2';
        Text002Txt: TextConst ESP = '%1 No puede ser posterior a %2';

    trigger OnInsert()
    begin
        CheckFields();
        CheckOverlap();
    end;

    trigger OnModify()
    begin
        CheckFields();
        CheckOverlap();
    end;

    procedure CheckOverLap()
    var
        lrLink: record "Relacion Tasa Producto";
    begin
        //CheckOverlap
        CLEAR(lrLink);
        lrLink.SETCURRENTKEY(Item, "Codigo Tasa/Prod", "Id Lin Precio");
        lrLink.SETRANGE(Item, Item);
        lrLink.SETRANGE("Codigo Tasa/Prod", "Codigo Tasa/Prod");
        lrLink.SETFILTER(Id, '<>%1', Id);
        IF not lrLink.IsEmpty() THEN ERROR(Text001Txt, Item, "Codigo Tasa/Prod");
    end;

    procedure CheckFields()
    begin
        TESTFIELD(Item);
        TESTFIELD("Codigo Tasa/Prod");
        TESTFIELD("Id Lin Precio");
    end;
    //     procedure GestLinCompra(prLinCmp: Record "Purchase Line"; pwDelete: Boolean)
    //     var
    //         lrRel: Record "Relacion Tasa Producto";
    //         lwFecha: Date;
    //     begin
    //         // GestLinCompra
    //         // Gestiona la inclusión de lineas de Tasa en un documento de compra
    //         // Generamos una sola linea por tipo de tasa (Codigo + importe)
    //         IF (prLinCmp."Document No." = '') OR (prLinCmp.Type <> prLinCmp.Type::Item) OR (prLinCmp."No." = '')
    //         OR (prLinCmp."Line No." = 0) THEN
    //             EXIT;
    //         // Buscamos las posibles relacioens del producto
    //         CLEAR(lrRel);
    //         lrRel.SETCURRENTKEY(Item, "Codigo Tasa/Prod", "Id Lin Precio");
    //         lrRel.SETRANGE(Item, prLinCmp."No.");
    //         IF lrRel.FINDSET THEN BEGIN
    //             REPEAT
    //                 GestLinCompraDet(prLinCmp, lrRel, pwDelete);
    //             UNTIL lrRel.NEXT = 0;
    //         END;
    //     end;
    //     procedure GestLinCompraDet(VAR prLinCmp: Record "Purchase Line"; prRel: Record "Relacion Tasa Producto"; pwDelete: Boolean)
    //     var
    //         lrCab: Record "Purchase Header";
    //         lrLimCmp1: Record "Purchase Line";
    //         lrLimCmp2: Record "Purchase Line";
    //         lrLimCmp3: Record "Purchase Line";
    //         lrTmpLimCmp: Record "Purchase Line";
    //         lrTasa: Record "Tasa Producto";
    //         lrImpTasa: Record "Importe Tasa Producto";
    //         lrRel2: Record "Relacion Tasa Producto";
    //         lrTmpVATALine: Record "VAT Amount Line";
    //         lrCurrency: Record Currency;
    //         DimMgt: Codeunit DimensionManagement;
    //         lwCant: Decimal;
    //         lwImpt: Decimal;
    //         lwExits: Boolean;
    //         lwOk: Boolean;
    //         lwFecha: Date;
    //         lwTotal: Decimal;
    //         lwNo: Integer;
    //     begin
    //         // GestLinCompraDet
    //         // Gestiona la inclusión de lineas de Tasa en un documento de compra
    //         // Generamos una sola linea por tipo de tasa (Codigo + importe)
    //         IF (prLinCmp."Document No." = '') OR (prLinCmp.Type <> prLinCmp.Type::Item) OR (prLinCmp."No." = '') THEN EXIT;
    //         IF (prRel."Codigo Tasa/Prod" = '') OR (prRel."Id Lin Precio" = 0) THEN EXIT;
    //         lrTasa.GET(prRel."Codigo Tasa/Prod");
    //         IF lrTasa.Blocked THEN EXIT;
    //         lrTasa.TESTFIELD("VAT Prod. Posting Group");
    //         lrTasa.TESTFIELD(Cuenta);
    //         // Por si acaso....
    //         prLinCmp."Codigo Tasa Producto" := '';
    //         prLinCmp."Id Precio Tasa Producto" := 0;
    //         lrImpTasa.GET(prRel."Codigo Tasa/Prod", prRel."Id Lin Precio");
    //         CLEAR(lrTmpLimCmp); // Temporal de lineas relacionadas con la tasa
    //         lrTmpLimCmp.DELETEALL;
    //         lrCab.GET(prLinCmp."Document Type", prLinCmp."Document No.");
    //         lwFecha := lrCab."Posting Date";
    //         // Buscamos la cantidades de producto
    //         lwCant := 0;
    //         CLEAR(lrLimCmp1);
    //         lrLimCmp1.SETRANGE("Document Type", prLinCmp."Document Type");
    //         lrLimCmp1.SETRANGE("Document No.", prLinCmp."Document No.");
    //         lrLimCmp1.SETFILTER("Line No.", '<>%1', prLinCmp."Line No.");
    //         lrLimCmp1.SETRANGE(Type, lrLimCmp1.Type::Item);
    //         IF lrLimCmp1.FIND('-') THEN BEGIN
    //             CLEAR(lrRel2);
    //             lrRel2.SETCURRENTKEY(Item, "Codigo Tasa/Prod", "Id Lin Precio");
    //             lrRel2.ASCENDING(FALSE);
    //             lrRel2.SETRANGE("Codigo Tasa/Prod", prRel."Codigo Tasa/Prod");
    //             lrRel2.SETRANGE("Id Lin Precio", prRel."Id Lin Precio");
    //             REPEAT
    //                 lrRel2.SETRANGE(Item, lrLimCmp1."No.");
    //                 lwOk := (lrRel2.FIND('-'));
    //                 IF lwOk THEN BEGIN
    //                     lwCant += lrLimCmp1.Quantity;
    //                     lrTmpLimCmp := lrLimCmp1;
    //                     lrTmpLimCmp.INSERT;
    //                 END;
    //             UNTIL lrLimCmp1.NEXT = 0;
    //         END;
    //         // Sumamos la cantidad de la propia linea
    //         IF NOT pwDelete THEN
    //             lwCant += prLinCmp.Quantity;
    //         lwTotal := lwCant * lrImpTasa.Importe;
    //         // Localizamos la linea donde se refleja la tasa, o creamos una, si no existe
    //         CLEAR(lrLimCmp3);
    //         lrLimCmp3.SETRANGE("Document Type", prLinCmp."Document Type");
    //         lrLimCmp3.SETRANGE("Document No.", prLinCmp."Document No.");
    //         lrLimCmp3.SETFILTER("Line No.", '<>%1', prLinCmp."Line No.");
    //         lrLimCmp3.SETRANGE("Codigo Tasa Producto", lrImpTasa."Codigo Tasa/Prod");
    //         lrLimCmp3.SETRANGE("Id Precio Tasa Producto", lrImpTasa.Id);
    //         lwExits := lrLimCmp3.FIND('-');
    //         IF (NOT lwExits) AND (lwTotal <> 0) THEN BEGIN
    //             lrLimCmp3.INIT;
    //             lrLimCmp3.VALIDATE("Document Type", prLinCmp."Document Type");
    //             lrLimCmp3.VALIDATE("Document No.", prLinCmp."Document No.");
    //             lrLimCmp3.VALIDATE(Type, lrLimCmp3.Type::"G/L Account");
    //             lrLimCmp3.VALIDATE("No.", lrTasa.Cuenta);
    //             lrLimCmp3.Description := lrImpTasa.Descripcion;
    //             lwNo := prLinCmp.SigLinNo;
    //             IF lwNo = prLinCmp."Line No." THEN
    //                 lwNo += 10000;
    //             lrLimCmp3.VALIDATE("Line No.", lwNo);
    //             lrLimCmp3.VALIDATE("Codigo Tasa Producto", lrImpTasa."Codigo Tasa/Prod");
    //             lrLimCmp3.VALIDATE("Id Precio Tasa Producto", lrImpTasa.Id);
    //             lrLimCmp3.INSERT(TRUE);
    //         END
    //         ELSE BEGIN
    //             // Por si acaso hubiese más de una, borramos todas menos una de ese tipo
    //             IF (lrLimCmp3.COUNT > 1) OR (lwCant = 0) OR (lrImpTasa.Importe = 0) THEN BEGIN
    //                 lrLimCmp2.COPY(lrLimCmp3);
    //                 IF (lwTotal <> 0) THEN // Si hay cantidad dejamos una, sino lo borramos todo
    //                     lrLimCmp2.SETFILTER("Line No.", '<>%1&<>%2', lrLimCmp3."Line No.", prLinCmp."Line No.");
    //                 lrLimCmp2.DELETEALL(TRUE);
    //             END;
    //         END;
    //         // Si ya no hay cantidad salimos aqui
    //         IF lwTotal = 0 THEN EXIT;
    //         // Aseguramos los valores
    //         IF lrLimCmp3."No." <> lrTasa.Cuenta THEN BEGIN
    //             lrLimCmp3.VALIDATE("No.", lrTasa.Cuenta);
    //             IF lrImpTasa.Descripcion <> '' THEN
    //                 lrLimCmp3.Description := lrImpTasa.Descripcion;
    //         END;
    //         IF lrLimCmp3."VAT Prod. Posting Group" <> lrTasa."VAT Prod. Posting Group" THEN
    //             lrLimCmp3.VALIDATE("VAT Prod. Posting Group", lrTasa."VAT Prod. Posting Group");
    //         lrLimCmp3.VALIDATE("Codigo Tasa Producto", lrImpTasa."Codigo Tasa/Prod");
    //         lrLimCmp3.VALIDATE("Id Precio Tasa Producto", lrImpTasa.Id);
    //         IF lrTasa."Tipo Aplicacion" IN [lrTasa."Tipo Aplicacion"::"% Base",
    //                                     lrTasa."Tipo Aplicacion"::"% IVA Inc"] THEN BEGIN
    //             // Calculamos los importes
    //             IF NOT lrCurrency.GET(lrCab."Currency Code") THEN
    //                 lrCurrency.InitRoundingPrecision;
    //             lrLimCmp3.CalcVATAmountLines(0, lrCab, lrTmpLimCmp, lrTmpVATALine);
    //             lwImpt := 0;
    //             IF lrTmpVATALine.FINDSET THEN BEGIN
    //                 REPEAT
    //                     CASE lrTasa."Tipo Aplicacion" OF
    //                         lrTasa."Tipo Aplicacion"::"% Base":
    //                             lwImpt += lrTmpVATALine."VAT Base";
    //                         lrTasa."Tipo Aplicacion"::"% IVA Inc":
    //                             lwImpt += lrTmpVATALine."Amount Including VAT";
    //                     END;
    //                 UNTIL lrTmpVATALine.NEXT = 0;
    //             END;
    //         END;
    //         CASE lrTasa."Tipo Aplicacion" OF
    //             lrTasa."Tipo Aplicacion"::"Importe Fijo":
    //                 BEGIN
    //                     lrLimCmp3.VALIDATE(Quantity, lwCant);
    //                     lwImpt := lrImpTasa.Importe;
    //                     IF prLinCmp."Currency Code" <> '' THEN // Si está en otra divisa, la convertimos
    //                         lwImpt := rCurExc.ExchangeAmtFCYToFCY(lwFecha, prLinCmp."Currency Code", '', lwImpt);
    //                     lrLimCmp3.VALIDATE("Direct Unit Cost", lwImpt);
    //                 END;
    //             lrTasa."Tipo Aplicacion"::"% Base", lrTasa."Tipo Aplicacion"::"% IVA Inc":
    //                 BEGIN
    //                     lrLimCmp3.VALIDATE(Quantity, 1);
    //                     IF lrImpTasa.Importe = 0 THEN // En realidad esto no puede pasar, dadas las condiciones anteriores, pero porsi....
    //                         lwImpt := 0
    //                     ELSE
    //                         lwImpt := ROUND(lwImpt * 100 / lrImpTasa.Importe, lrCurrency."Amount Rounding Precision");
    //                     lrLimCmp3.VALIDATE("Direct Unit Cost", lwImpt);
    //                 END;
    //         END;
    //         lrLimCmp3.CreateDim(
    //             DATABASE::"Tasa Producto", lrTasa.Codigo,
    //             DimMgt.TypeToTableID3(lrLimCmp3.Type), lrLimCmp3."No.",
    //             DATABASE::Job, lrLimCmp3."Job No.",
    //             DATABASE::"Responsibility Center", lrLimCmp3."Responsibility Center");
    //         lrLimCmp3.MODIFY;
    //     end;
    //     procedure ShowTasaProducto(pwCodPro: Code[20])
    //     var
    //         lrRelTP: record "Relacion Tasa Producto";
    //     begin
    //         // ShowTasaProducto
    //         // $003 JPT 29/09/16 Nueva función "ShowTasaProducto". Muestra las lineas de tasa relacioandas con el producto
    //         CLEAR(lrRelTP);
    //         lrRelTP.SETCURRENTKEY(Item, "Codigo Tasa/Prod", "Id Lin Precio");
    //         lrRelTP.SETRANGE(Item, pwCodPro);
    //         PAGE.RUN(0, lrRelTP);
    //     end;
    PROCEDURE CheckFechas();
    BEGIN
        // CheckFechas
        IF ("Fecha Desde" > "Fecha Hasta") AND ("Fecha Hasta" <> 0D) THEN ERROR(Text002Txt, FIELDCAPTION("Fecha Desde"), FIELDCAPTION("Fecha Hasta"));
    END;
}
