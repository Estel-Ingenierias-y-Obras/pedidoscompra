table 58004 "Tasa Producto"
{
    LookupPageId = "Lista Tasa Producto";
    DrillDownPageId = "Lista Tasa Producto";

    fields
    {
        field(1; Codigo; code[20])
        {
            NotBlank = true;
            Caption = 'Código';
        }
        field(5; Descripcion; text[30])
        {
            Caption = 'Descripción';

            trigger OnValidate()
            begin
                GetLinesDescription();
            end;
        }
        field(50; "VAT Prod. Posting Group"; code[10])
        {
            Caption = 'Grupo registro IVA prod.';
            TableRelation = "VAT Product Posting Group";
        }
        field(51; "Global Dimension 1 Code"; code[20])
        {
            Caption = 'Cód. dimensión global 1';
            TableRelation = "Dimension Value".Code WHERE("Global Dimension No." = CONST(1));
            CaptionClass = '1,1,1';

            trigger OnValidate()
            begin
                ValidateShortcutDimCode(1, "Global Dimension 1 Code");
            end;
        }
        field(52; "Global Dimension 2 Code"; Code[20])
        {
            Caption = 'Cód. dimensión global 2';
            TableRelation = "Dimension Value".Code WHERE("Global Dimension No." = CONST(2));
            CaptionClass = '1,1,2';

            trigger OnValidate()
            begin
                ValidateShortcutDimCode(2, "Global Dimension 2 Code");
            end;
        }
        field(53; "Tipo Aplicacion"; Enum "Tipo Aplicacion")
        {
            Caption = 'Tipo Aplicación';

            trigger OnValidate()
            begin
                GetLinesDescription();
            end;
        }
        field(55; Cuenta; Code[20])
        {
            Caption = 'Cuenta';
            TableRelation = "G/L Account"."No.";

            trigger OnValidate()
            var
                lwCta: Record "G/L Account";
            begin
                IF lwCTa.GET(Cuenta) THEN lwCTa.CheckGLAcc();
            end;
        }
        field(56; Blocked; Boolean)
        {
            Caption = 'Bloqueado';
        }
    }
    keys
    {
        key(Key1; Codigo)
        {
            Clustered = true;
        }
    }
    trigger OnDelete()
    var
        lrImpts: Record "Importe Tasa Producto";
        lrRel: Record "Relacion Tasa Producto";
    begin
        // Borramos las tablas relacionadas
        // Precios
        CLEAR(lrImpts);
        lrImpts.SETRANGE("Codigo Tasa/Prod", Codigo);
        lrImpts.DELETEALL();
        // Relaciones
        CLEAR(lrRel);
        lrRel.SETCURRENTKEY(Item, "Codigo Tasa/Prod", "Id Lin Precio");
        lrRel.SETRANGE("Codigo Tasa/Prod", Codigo);
        lrRel.DELETEALL();
    end;

    procedure ValidateShortcutDimCode(FieldNumber: Integer; VAR ShortcutDimCode: Code[20])
    var
        DimMgt: Codeunit DimensionManagement;
    begin
        DimMgt.ValidateDimValueCode(FieldNumber, ShortcutDimCode);
        DimMgt.SaveDefaultDim(DATABASE::"Tasa Producto", Codigo, FieldNumber, ShortcutDimCode);
        MODIFY();
    end;

    procedure ShowDims()
    var
        lrDims: record "Default Dimension";
    begin
        // ShowDims
        CLEAR(lrDims);
        lrDims.SETRANGE("Table ID", DATABASE::"Tasa Producto");
        lrDims.SETRANGE("No.", Codigo);
        PAGE.RUNMODAL(540, lrDims);
    end;

    procedure ShowProductos()
    var
        lrRel: Record "Relacion Tasa Producto";
    begin
        // ShowProductos
        CLEAR(lrRel);
        lrRel.SETCURRENTKEY(Item, "Codigo Tasa/Prod", "Id Lin Precio");
        lrRel.SETRANGE("Codigo Tasa/Prod", Codigo);
        PAGE.RUN(0, lrRel);
    end;

    procedure GetLinesDescription()
    var
        lrLinTP: Record "Importe Tasa Producto";
        lwText: Text[50];
        lwIs: Boolean;
    begin
        // GestLinesDescription
        CLEAR(lrLinTP);
        lrLinTP.SETRANGE("Codigo Tasa/Prod", Codigo);
        //lrLinTP.SETRANGE(Descripcion       , xRec.Descripcion);
        IF lrLinTP.FIND('-') THEN
            REPEAT
                lwText := '';
                IF lrLinTP.Descripcion <> '' THEN BEGIN
                    lwIs := xRec."Tipo Aplicacion".AsInteger() > xRec."Tipo Aplicacion"::"Importe Fijo".AsInteger();
                    lwText := lrLinTP.GeImptDescription(xRec.Descripcion, lwIs);
                END;
                IF lwText = lrLinTP.Descripcion THEN BEGIN
                    lwIs := "Tipo Aplicacion".AsInteger() > "Tipo Aplicacion"::"Importe Fijo".AsInteger();
                    lwText := lrLinTP.GeImptDescription(Descripcion, lwIs);
                    lrLinTP.VALIDATE(Descripcion, lwText);
                    lrLinTP.MODIFY();
                END;
            UNTIL lrLinTP.NEXT() = 0;
    end;
}
