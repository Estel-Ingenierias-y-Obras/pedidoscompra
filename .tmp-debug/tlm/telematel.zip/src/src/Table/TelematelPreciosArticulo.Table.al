table 58017 "Telematel Precios Articulo"
{
    LookupPageID = "Telematel Precios Articulo";
    DrillDownPageID = "Telematel Precios Articulo";

    fields
    {
        field(1; Id; Integer)
        {
            AutoIncrement = true;
            BlankNumbers = DontBlank;
            Editable = false;
        }
        field(5; IdArticulo; Integer)
        {
            TableRelation = "Telematel Articulos";
            CaptionML = ESP = 'Id. Articulo';
        }
        field(10; CodArt; Code[20])
        {
            TableRelation = "Telematel Articulos".CodArt WHERE(CodArt=FIELD(CodArt));
            CaptionML = ESP = 'Codigo';
        }
        field(11; IdMarca; Integer)
        {
            TableRelation = "Telematel Marcas".Id;
            CaptionML = ESP = 'Id. Marca';
        }
        field(15; "No.Item"; Code[20])
        {
            FieldClass = FlowField;
            CalcFormula = Lookup("Telematel Articulos"."No.Item" WHERE(Id=FIELD(IdArticulo)));
            TableRelation = Item;
            CaptionML = ESP = 'No. Item';
            Editable = false;
        }
        field(20; "Fecha Inicio"; Date)
        {
        }
        field(21; "Fecha Final"; Date)
        {
        }
        field(25; Quantity; Decimal)
        {
            CaptionML = ESP = 'Cantidad';
        }
        field(30; Precio; Decimal)
        {
        }
        field(39; "Telematel Currency"; Code[10])
        {
            TableRelation = "Telematel Currency"."Code Telematel";
            CaptionML = ESP = 'Divisa Telematel';
            Editable = false;
        }
        field(40; "Currency Code"; Code[10])
        {
            TableRelation = "Telematel Currency";
            CaptionML = ENU = 'Currency Code', ESP = 'Cod. divisa';
        }
        field(41; "Minimum Quantity"; Decimal)
        {
            CaptionML = ENU = 'Minimum Quantity', ESP = 'Cantidad mínima';
            MinValue = 0;
        }
        field(42; "Unit of Measure Code"; Code[10])
        {
            TableRelation = "Unit of Measure".Code;
            CaptionML = ENU = 'Unit of Measure Code', ESP = 'Cod. unidad medida';
        }
        field(43; RAEE; Decimal)
        {
            Description = 'Tasa RAEE reciclaje';
        }
        field(50; Manual; Boolean)
        {
            Description = 'Indica que este precio no ha sido importado, sino creado manualmente por Usuario';
        }
        field(51; Vendor; Code[20])
        {
            TableRelation = Vendor."No.";
            CaptionML = ENU = 'Vendor', ESP = 'Proveedor';
            Description = 'Proveedor para los precios manuales';
        }
        field(60; Pendiente; Boolean)
        {
            Description = 'GOCAT';
        }
        field(101; "Codigo Unidad"; Code[4])
        {
            TableRelation = "Telematel Unidades";
            CaptionML = ESP = 'Codigo Unidad';
        }
        field(102; "Unidad UN20"; Code[5])
        {
            TableRelation = "Unidades UN20"."UN20 Code";
            CaptionML = ESP = 'Unidad UN20';
        }
    }
    keys
    {
        key(Key1; Id)
        {
            Clustered = true;
        }
        key(Key2; CodArt)
        {
        }
        key(Key3; IdArticulo, "Minimum Quantity")
        {
        }
        key(Key4; IdArticulo, "Fecha Inicio", "Fecha Final")
        {
        }
        key(Key5; Pendiente, "Fecha Inicio")
        {
        }
    }
//     var
//         myInt: Integer;
//     trigger OnInsert()
//     begin
//     end;
//     trigger OnModify()
//     begin
//     end;
//     trigger OnDelete()
//     begin
//     end;
//     trigger OnRename()
//     begin
//     end;
}
