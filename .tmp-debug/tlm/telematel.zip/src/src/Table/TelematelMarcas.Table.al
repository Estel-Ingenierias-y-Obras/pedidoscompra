table 58009 "Telematel Marcas"
{
    LookupPageId = "Telematel Marcas";
    DrillDownPageId = "Telematel Marcas";

    fields
    {
        field(1; Id; Integer)
        {
            NotBlank = true;
        }
        field(2; Codigo; code[20])
        {
            Caption = 'Código';
        }
        field(20; IdEntidad; Integer)
        {
            Caption = 'Id Entidad';
        }
        field(21; NomEntidad; text[70])
        {
            Caption = 'Nombre Entidad';
        }
        field(100; Importar; Boolean)
        {
            trigger OnValidate()
            var
            begin
                IF Importar THEN 
                    IF Eliminada THEN ERROR('La marca %1  ha sido eliminada', Codigo);
                Modify(True);
            end;
        }
        field(101; "Ultima Actualizacion GOCAT"; DateTime)
        {
            Editable = False;
        }
        field(102; UltimaActualizacion; DateTime)
        {
            Editable = False;
        }
        field(105; Activa; Boolean)
        {
            trigger OnValidate()
            begin
                IF Activa THEN Eliminada := FALSE;
            end;
        }
        field(110; Eliminada; Boolean)
        {
            trigger OnValidate()
            begin
                IF Eliminada THEN VALIDATE(Importar, FALSE);
            end;
        }
        field(115; Perdido; Boolean)
        {
            trigger OnValidate()
            begin
                IF Perdido THEN VALIDATE(Eliminada, TRUE);
            end;
        }
        field(200; Origen; Enum "Origen Marcas")
        {
        }
    }
    keys
    {
        key(Key1; Id)
        {
            Clustered = true;
        }
        key(Key2; Codigo)
        {
        }
        key(Key3; IdEntidad)
        {
        }
        key(Key4; NomEntidad)
        {
        }
        key(key5; UltimaActualizacion)
        {
        }
    }
}
