table 58014 "GOCAT Referencias Articulos"
{
    fields
    {
        field(1; Id; Integer)
        {
            Editable = false;
            AutoIncrement = True;
        }
        field(5; "Id Articulo"; Integer)
        {
            NotBlank = true;
            TableRelation = "Telematel Articulos".Id;
        }
        field(10; Tipo;Enum "GoCat Referencia Tipo")
        {
            BlankZero = true;
        }
        field(20; Url; text[250])
        {
        }
    }
    keys
    {
        key(Key1; Id)
        {
            Clustered = true;
        }
        key(key2; "Id Articulo")
        {
        }
    }
    trigger OnInsert()
    begin
        TESTFIELD("Id Articulo");
    end;
}
