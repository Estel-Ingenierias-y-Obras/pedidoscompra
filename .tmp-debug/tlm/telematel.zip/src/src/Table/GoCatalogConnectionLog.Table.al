table 58011 "Go Catalog Connection Log"
{
    fields
    {
        field(1; Id; Integer)
        {
            Editable = false;
            AutoIncrement = True;
        }
        field(10; Date; date)
        {
        }
        field(20; InitCnt; DateTime)
        {
            Caption = 'Inicio';
        }
        field(21; EndCnt; DateTime)
        {
            Caption = 'Fin';
        }
        field(25; "Duration"; Duration)
        {
            Caption = 'Duración';
        }
        field(30; Result; enum "GoCat Log Status")
        {
            Caption = 'Resultado';
        }
        field(40; ErrorText; text[250])
        {
            Caption = 'Texto de Error';
        }
        field(42; ErrorText2; text[250])
        {
            Caption = 'Texto de Error 2';
        }
        field(50; Intento; Integer)
        {
            BlankZero = true;
            MinValue = 0;
        }
    }
    keys
    {
        key(Key1; Id)
        {
            Clustered = true;
        }
    }
    //     procedure SetError(pwError: Text)
    //     var
    //         lwPos: integer;
    //     begin
    //         lwPos := MAXSTRLEN(ErrorText);
    //         ErrorText := COPYSTR(pwError, 1, lwPos);
    //         ErrorText2 := COPYSTR(pwError, lwPos + 1, MAXSTRLEN(ErrorText2));
    //     end;
    procedure GetError() ResultV: Text
    begin
        ResultV := ErrorText + ErrorText2;
    end;
}
