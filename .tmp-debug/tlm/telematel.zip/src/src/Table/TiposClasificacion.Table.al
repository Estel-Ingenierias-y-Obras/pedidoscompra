table 58001 "Tipos Clasificacion"
{
    LookupPageId = "Cod. Clasificaciones";
    DrillDownPageId = "Cod. Clasificaciones";

    fields
    {
        field(1; Id; Integer)
        {
        }
        field(2; Nombre; text[60])
        {
        }
        field(10; Subtype; enum "Subtipo Clasificacion")
        {
            BlankZero = true;
            Caption = 'SubTipo';

            trigger OnValidate()
            var
                lrTipos: record "Tipos Clasificacion";
            begin
                IF SubType <> SubType::None THEN BEGIN
                    CLEAR(lrTipos);
                    lrTipos.SETRANGE(SubType, SubType);
                    lrTipos.SETFILTER(Id, '<>%1', Id);
                    IF lrTipos.FINDFIRST() THEN ERROR('Ya existe  un registro con %1 = %2   (%3)', FIELDCAPTION(SubType), SubType, STRSUBSTNO('%1 - %2', lrTipos.Id, lrTipos.Nombre));
                END;
            end;
        }
        field(11; "Tipo Go Catalog"; text[30])
        {
            trigger OnValidate()
            var
                lrTipos: record "Tipos Clasificacion";
            begin
                IF "Tipo Go Catalog" <> '' THEN BEGIN
                    CLEAR(lrTipos);
                    lrTipos.SETRANGE("Tipo Go Catalog", "Tipo Go Catalog");
                    lrTipos.SETFILTER(Id, '<>%1', Id);
                    IF lrTipos.FINDFIRST() THEN ERROR('Ya existe  un registro con %1 = %2   (%3)', FIELDCAPTION("Tipo Go Catalog"), "Tipo Go Catalog", STRSUBSTNO('%1 - %2', lrTipos.Id, lrTipos.Nombre));
                END;
            end;
        }
    }
    keys
    {
        key(Key1; Id)
        {
            Clustered = true;
        }
    }
    trigger OnDelete()
    begin
        DeleteRecords();
    end;

    local procedure DeleteRecords()
    var
        lrClass: Record Clasificaciones;
        lrClassArt: Record "Clasificacion Articulos";
    begin
        CLEAR(lrClass);
        lrClass.SETRANGE("Tipo Clasificacion", Id);
        IF NOT lrClass.ISEMPTY THEN lrClass.DELETEALL();
        CLEAR(lrClassArt);
        lrClassArt.SETRANGE("Codigo Clasificacion", Id);
        IF NOT lrClassArt.ISEMPTY THEN lrClassArt.DELETEALL();
    end;

    procedure GetLastId() result: integer
    var
        lrTipos: Record "Tipos Clasificacion";
    begin
        Result := 0;
        IF lrTipos.FINDLAST() THEN Result := lrTipos.Id;
    end;

    procedure ShowClasificaciones(pwId: Integer)
    var
        lwPageTree: Page "Clasificaciones Tree";
    begin
        IF pwId = 0 THEN EXIT;
        lwPageTree.RellenaTemp(pwId, 0, 0);
        lwPageTree.RUN();
    end;
}
