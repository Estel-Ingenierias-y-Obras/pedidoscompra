table 58012 "GOCAT Arts. Conversion"
{
    fields
    {
        field(1; Id; Integer)
        {
            Editable = false;
            AutoIncrement = True;
        }
        field(2; "Art Id"; Integer)
        {
            TableRelation = "Telematel Articulos".Id;
        }
        field(42; "Unit of Measure Code"; code[10])
        {
            Caption = 'Cód. unidad medida';
            TableRelation = "Unit of Measure".Code;
        }
        field(50; Valor; Decimal)
        {
        }
        field(101; "Codigo Unidad"; code[4])
        {
            Caption = 'Código Unidad';
            TableRelation = "Telematel Unidades";
        }
        field(102; "Unidad UN20"; code[5])
        {
            TableRelation = "Unidades UN20"."UN20 Code";
        }
    }
    keys
    {
        key(Key1; Id)
        {
            Clustered = true;
        }
        key(Key2; "Art Id")
        {
        }
    }
}
