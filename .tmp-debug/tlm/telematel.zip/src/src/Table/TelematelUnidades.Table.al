table 58015 "Telematel Unidades"
{
    LookupPageID = "Telematel Unidades";
    DrillDownPageID = "Telematel Unidades";

    fields
    {
        field(1; "Codigo TLM"; Code[4])
        {
        }
        field(2; "Codigo Nav"; Code[10])
        {
            Caption = 'Codigo BC';
            TableRelation = "Unit of Measure";

            trigger OnValidate()
            var
                lwUT: Record "Telematel Unidades";
            begin
                // Avisamos si ya existe el codigo
                IF "Codigo Nav" <> '' THEN BEGIN
                    CLEAR(lwUT);
                    lwUT.SETRANGE("Codigo Nav", "Codigo Nav");
                    lwUT.SETFILTER("Codigo TLM", '<>%1', "Codigo TLM");
#pragma warning disable AA0181
                    IF lwUT.FindSet() THEN MESSAGE(T0001Txt, "Codigo Nav", lwUT."Codigo TLM");
#pragma warning restore AA0181
                END;
            end;
        }
        field(10; Descripcion; Text[50])
        {
        }
    }
    keys
    {
        key(Key1; "Codigo TLM")
        {
            Clustered = true;
        }
    }
    fieldgroups
    {
        fieldgroup(DropDown; "Codigo TLM", "Codigo Nav", Descripcion)
        {
        }
    }
    var
        T0001Txt: TextConst ENU = 'Aviso!. El codigo %1 ya está configurado a la unidad Telematel %2.', ESM = 'Aviso!. El codigo %1 ya está configurado a la unidad Telematel %2';
    //     trigger OnInsert()
    //     begin
    //     end;
    //     trigger OnModify()
    //     begin
    //     end;
    //     trigger OnDelete()
    //     begin
    //     end;
    //     trigger OnRename()
    //     begin
    //     end;
}
