table 58003 "Clasificacion Articulos"
{
    fields
    {
        field(1; "Id Articulo"; Integer)
        {
            NotBlank = true;
            TableRelation = "Telematel Articulos".Id;

            trigger OnValidate()
            var
                lrArtTL: Record "Telematel Articulos";
            begin
                IF lrArtTL.GET("Id Articulo") THEN
                    "Cod Item" := lrArtTL."No.Item"
                ELSE
                    "Cod Item" := '';
            end;
        }
        field(2; "Codigo Clasificacion"; integer)
        {
            Caption = 'Código Clasificación';
            TableRelation = "Tipos Clasificacion".Id;
            NotBlank = true;

            trigger OnValidate()
            begin
                IF "Codigo Clasificacion" <> xRec."Codigo Clasificacion" THEN VALIDATE(N1, 0);
            end;
        }
        field(3; "Cod Item"; code[20])
        {
            TableRelation = Item."No.";
        }
        field(7; "Desc.Codigo Clasificacion"; text[60])
        {
            Caption = 'Desc.Codigo Clasificacion';
            FieldClass = FlowField;
            CalcFormula = Lookup("Tipos Clasificacion".Nombre WHERE(Id = FIELD("Codigo Clasificacion")));
            Editable = False;
        }
        field(11; N1; Integer)
        {
            TableRelation = Clasificaciones.Id WHERE(Nivel = CONST(1), "Id Subordinado" = CONST(0));

            trigger OnValidate()
            begin
                IF N1 <> xRec.N1 THEN VALIDATE(N2, 0);
            end;
        }
        field(12; N2; integer)
        {
            TableRelation = Clasificaciones.Id WHERE(Nivel = CONST(2), "Id Subordinado" = FIELD(N1));

            trigger onvalidate()
            begin
                IF N2 <> xRec.N2 THEN VALIDATE(N3, 0);
            end;
        }
        field(13; N3; Integer)
        {
            TableRelation = Clasificaciones.Id WHERE(Nivel = CONST(3), "Id Subordinado" = FIELD(N2));
        }
        field(101; "Nivel 1"; text[60])
        {
            Editable = False;
            FieldClass = FlowField;
            CalcFormula = Lookup(Clasificaciones.Descripcion WHERE(Id = FIELD(N1)));
        }
        field(102; "Nivel 2"; text[60])
        {
            Editable = false;
            FieldClass = FlowField;
            CalcFormula = Lookup(Clasificaciones.Descripcion WHERE(Id = FIELD(N2)));
        }
        field(103; "Nivel 3"; text[60])
        {
            Editable = false;
            FieldClass = FlowField;
            CalcFormula = Lookup(Clasificaciones.Descripcion WHERE(Id = FIELD(N3)));
        }
        field(110; Referencia; text[40])
        {
            Editable = false;
            FieldClass = FlowField;
            CalcFormula = Lookup("Telematel Articulos".Referencia WHERE(Id = FIELD("Id Articulo")));
        }
        field(120; "Id Marca"; Integer)
        {
            Editable = False;
            FieldClass = FlowField;
            CalcFormula = Lookup("Telematel Articulos"."Id Marca" WHERE(Id = FIELD("Id Articulo")));
        }
        field(130; "Codigo Marca"; code[30])
        {
            Caption = 'Código Marca';
            Editable = false;
            FieldClass = FlowField;
            CalcFormula = Lookup("Telematel Articulos"."Codigo Marca" WHERE(Id = FIELD("Id Articulo")));
        }
        field(201; "Descripcion Articulo"; text[80])
        {
            Caption = 'Descripción Artículo';
            Editable = false;
            FieldClass = FlowField;
            CalcFormula = Lookup("Telematel Articulos".Descripcion WHERE(Id = FIELD("Id Articulo")));
        }
    }
    keys
    {
        key(Key1; "Id Articulo", "Codigo Clasificacion")
        {
            Clustered = true;
        }
        key(Key2; "Cod Item", "Codigo Clasificacion")
        {
            Clustered = false;
        }
        key(Key3; "Codigo Clasificacion", N1, N2, N3)
        {
            Clustered = false;
        }
    }
    var
        wFiltroClass: array[3] of Text;
        wFiltroClassId: array[3] of Integer;

    trigger OnInsert()
    begin
        TESTFIELD("Codigo Clasificacion");
        TESTFIELD("Id Articulo");
    end;

    trigger OnModify()
    begin
        TESTFIELD("Codigo Clasificacion");
    end;

    trigger OnRename()
    begin
        ERROR('');
    end;

    procedure LookupLevel(pwLevel: Integer) result: Boolean
    var
        lwClass: Record Clasificaciones;
        lwParent: Integer;
        lwAct: Integer;
        lwAction: Action;
    begin
        lwParent := GetLevelId(pwLevel - 1);
        lwAct := GetLevelId(pwLevel);
        IF (lwParent = 0) AND (pwLevel > 1) THEN EXIT;
        CLEAR(lwClass);
        lwClass.SETCURRENTKEY(Nivel, Orden);
        lwClass.SETRANGE("Tipo Clasificacion", "Codigo Clasificacion");
        lwClass.SETRANGE(Nivel, pwLevel);
        lwClass.SETRANGE("Id Subordinado", lwParent);
        IF lwAct <> 0 THEN lwClass.GET(lwAct);
        lwAction := PAGE.RUNMODAL(Page::"Clasificaciones Lookup", lwClass);
        Result := lwAction IN [ACTION::LookupOK, ACTION::Yes];
    end;

    procedure GetLevelId(pwLevel: Integer) Result: Integer
    begin
        Result := 0;
        CASE pwLevel OF
            1:
                Result := N1;
            2:
                Result := N2;
            3:
                Result := N3;
        END;
    end;

    procedure GetLevelText(pwLevel: Integer) Result: Text
    begin
        Result := '';
        CASE pwLevel OF
            1:
                Result := "Nivel 1";
            2:
                Result := "Nivel 2";
            3:
                Result := "Nivel 3";
        END;
    end;

    procedure ValidateLevelId(pwLevel: Integer; pwValue: Integer)
    begin
        CASE pwLevel OF
            1:
                VALIDATE(N1, pwValue);
            2:
                VALIDATE(N2, pwValue);
            3:
                VALIDATE(N3, pwValue);
        END;
    end;

    procedure AsignaLevelId(pwLevel: Integer; pwValue: Integer)
    begin
        CASE pwLevel OF
            1:
                N1 := pwValue;
            2:
                N2 := pwValue;
            3:
                N3 := pwValue;
        END;
    end;

    procedure SetNivelFilter(pwLevel: integer; pwFilter: Integer)
    begin
        //SetNivelFilter
        CLEAR(Rec);
        CASE pwLevel OF
            1:
                SETRANGE(N1, pwFilter);
            2:
                SETRANGE(N2, pwFilter);
            3:
                SETRANGE(N3, pwFilter);
        END;
    end;
    //     procedure FiltraLevel(pwLevel: Integer; pwId: Integer; pwName: Text)
    //     begin
    //         AsingLevel(pwLevel, pwId, pwName);
    //         FiltraClass; // update page   
    //     end;
    procedure FiltraClass()
    var
        lwUltnivel: Integer;
    begin
        lwUltnivel := GetLastClassFilterLevel();
        IF lwUltnivel = 1 THEN
            SETRANGE(N1, wFiltroClassId[1])
        ELSE
            SETRANGE(N1);
        IF lwUltnivel = 2 THEN
            SETRANGE(N2, wFiltroClassId[2])
        ELSE
            SETRANGE(N2);
        IF lwUltnivel = 3 THEN
            SETRANGE(N3, wFiltroClassId[3])
        ELSE
            SETRANGE(N3);
    end;

    procedure AsingLevel(pwLevel: Integer; pwId: Integer; pwDescription: Text)
    var
        lwId: Integer;
    begin
        // AsingLevel
        IF pwId = 0 THEN pwDescription := '';
        wFiltroClassId[pwLevel] := pwId;
        wFiltroClass[pwLevel] := pwDescription;
        IF pwLevel < 3 THEN
            FOR lwId := pwLevel + 1 TO 3 DO AsingLevel(lwId, 0, '');
    end;

    procedure FindLevel(pwLevel: Integer; pwId: Integer) Result: Text
    var
        lrClasf: Record Clasificaciones;
        lwParentId: Integer;
    begin
        CLEAR(Result);
        CLEAR(lrClasf);
        IF pwId > 0 THEN BEGIN
            lwParentId := 0;
            IF pwLevel > 1 THEN lwParentId := wFiltroClassId[pwLevel - 1];
            // De paso comprobamos coherencia
            lrClasf.SETRANGE("Id Subordinado", lwParentId);
            lrClasf.SETRANGE(Id, pwId);
            lrClasf.SETRANGE(Nivel, pwLevel);
            lrClasf.FINDFIRST();
            Result := lrClasf.Descripcion;
        END;
    end;
    //     procedure GetClasLevelNames(VAR pwClasNames: ARRAY[3] OF Text[60])
    //     var
    //         lwLevel: Integer;
    //     begin
    //         CLEAR(pwClasNames);
    //         CALCFIELDS("Nivel 1", "Nivel 2", "Nivel 3");
    //         FOR lwLevel := 1 TO 3 DO
    //             pwClasNames[lwLevel] := GetLevelText(lwLevel);
    //     end;
    procedure GetFiltroCodClassText() wText: Text
    var
        lrCodlasf: Record "Tipos Clasificacion";
        lwFilt: Integer;
    begin
        wText := '';
        IF GETFILTER("Codigo Clasificacion") <> '' THEN BEGIN
            lwFilt := GETRANGEMIN("Codigo Clasificacion");
            IF lrCodlasf.GET(lwFilt) THEN
                wText := STRSUBSTNO('%1 - %2', lrCodlasf.Id, lrCodlasf.Nombre);
        END;
    end;

    procedure GestFiltrosTree(VAR pwIdTipoClass: Integer) wResult: Boolean
    var

        lrClass: Record Clasificaciones;
        lrTipoC: Record "Tipos Clasificacion";
        lwPageTree: Page "Clasificaciones Tree";
        lwId: Integer;
        lwUltnivel: Integer;
        lwOk: Boolean;
        lwIdMarca: Integer;
    begin
        lwUltnivel := GetLastClassFilterLevel();
        ;
        lwId := 0;
        IF lwUltnivel > 0 THEN lwId := wFiltroClassId[lwUltnivel];
        CLEAR(lwIdMarca);
        IF NOT lrTipoC.GET(pwIdTipoClass) THEN CLEAR(lrTipoC);
        IF lrTipoC.SubType = lrTipoC.SubType::brand THEN BEGIN
            CALCFIELDS("Id Marca");
            lwIdMarca := "Id Marca";
        END;
        CLEAR(lwPageTree);
        lwPageTree.RellenaTemp(pwIdTipoClass, lwId, lwIdMarca);
        lwPageTree.LOOKUPMODE := TRUE;
        wResult := lwPageTree.RUNMODAL() = ACTION::LookupOK;
        IF wResult THEN BEGIN
            lwId := lwPageTree.GetId();
            IF lwId <> 0 THEN BEGIN
                CLEAR(wFiltroClassId);
                CLEAR(wFiltroClass);
                IF lrClass.GET(lwId) THEN BEGIN
                    pwIdTipoClass := lrClass."Tipo Clasificacion";
                    REPEAT
                        wFiltroClassId[lrClass.Nivel] := lrClass.Id;
                        wFiltroClass[lrClass.Nivel] := lrClass.Descripcion;
                        lwOk := lrClass.GET(lrClass."Id Subordinado");
                    UNTIL NOT lwOk;
                END
                ELSE BEGIN
                    IF lwId < 0 THEN 
                        lwId := -lwId;
                        pwIdTipoClass := lwId;
                END;
            END;
        END;
    end;

    procedure GetClassFullText() Result: Text
    var
        lwN: Integer;
        Text0003Txt: TextConst ESP = '<Filtro de Clasificaciones>';
    begin
        CLEAR(Result);
        FOR lwN := 1 TO 3 DO BEGIN
            IF wFiltroClass[lwN] <> '' THEN 
                IF Result <> '' THEN Result += ' / ';
                Result += wFiltroClass[lwN];
            END;
        IF Result = '' THEN Result := Text0003Txt;
        Result := PADSTR('', 10, ' ') + Result;
    end;

    procedure ClearFiltrosClass()
    begin
        CLEAR(wFiltroClassId);
        CLEAR(wFiltroClass);
    end;

    procedure GetFiltroClassId(pwLevel: Integer) Result: Integer
    begin
        Result := wFiltroClassId[pwLevel];
    end;

    procedure GetFiltroClass(pwLevel: Integer) Result: Text
    begin
        Result := wFiltroClass[pwLevel];
    end;

    procedure SetFilterPageFilters(VAR pwFiltPage: Page "Filtros Clasificacion")
    begin
        pwFiltPage.SetValues(wFiltroClass, wFiltroClassId);
    end;

    procedure FilterPageGetValues(VAR pwFiltPage: Page "Filtros Clasificacion")
    begin
        pwFiltPage.GetValues(wFiltroClass, wFiltroClassId);
    end;

    procedure RiseLevel() Result: Boolean
    var
        lwLevel: Integer;
    begin
        lwLevel := GetLastClassFilterLevel();
        Result := lwLevel > 0;
        IF Result THEN BEGIN
            AsingLevel(lwLevel, 0, '');
            FiltraClass();
        END;
    end;

    procedure GetLastClassFilterLevel() Result: Integer
    var
        lwN: Integer;
    begin
        Result := 0;
        FOR lwN := 1 TO 3 DO
            IF wFiltroClassId[lwN] > 0 THEN Result := lwN;
    end;
}
