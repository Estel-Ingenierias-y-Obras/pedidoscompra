table 58002 Clasificaciones
{
    fields
    {
        field(1; Id; Integer)
        {
            AutoIncrement = true;
        }
        field(10; "Tipo Clasificacion"; integer)
        {
            NotBlank = true;
            TableRelation = "Tipos Clasificacion".Id;
        }
        field(11; Nivel; Integer)
        {
        }
        field(12; Descripcion; text[60])
        {
        }
        field(16; "Id Subordinado"; integer)
        {
        }
        field(20; "Id Telematel"; integer)
        {
        }
        field(21; Orden; integer)
        {
        }
        field(22; "Id Marca"; integer)
        {
            TableRelation = "Telematel Marcas".Id;
        }
        field(50; "Desc.Codigo Clasificacion"; text[60])
        {
            Caption = 'Código Clasificación';
            FieldClass = FlowField;
            CalcFormula = Lookup("Tipos Clasificacion".Nombre WHERE(Id = FIELD("Tipo Clasificacion")));
            Editable = false;
        }
        field(51; "Desc. Subordinado"; text[60])
        {
            Caption = 'Desc. Subordinado';
            Editable = false;
            FieldClass = FlowField;
            CalcFormula = Lookup(Clasificaciones.Descripcion WHERE(Id = FIELD("Id Subordinado")));
        }
        field(100; Manual; Boolean)
        {
        }
    }
    keys
    {
        key(Key1; Id)
        {
            Clustered = true;
        }
        key(Key2; Nivel, Orden)
        {
        }
        key(Key3; Nivel, "Id Subordinado", "Id Telematel")
        {
        }
        key(Key4; Orden)
        {
        }
    }
    var
        Text002Txt: TextConst ESP = 'No puede eliminarse el registro';
        Text003Txt: TextConst ESP = 'No se puede renombrar el registro';

    trigger OnInsert()
    begin
        TESTFIELD("Tipo Clasificacion");
    end;

    trigger OnModify()
    begin
        TESTFIELD("Tipo Clasificacion");
        // IF Descripcion <> xRec.Descripcion THEN BEGIN
        //     IF CONFIRM(Text001, TRUE) THEN BEGIN
        //         CambiaDescripcion;
        //     END;
        // END;
    end;

    trigger OnDelete()
    var
        lrClasArt: Record "Clasificacion Articulos";
    begin
        IF NOT Manual THEN ERROR(Text002Txt);
        // Borramos la clasificación por artículos relacionada
        CLEAR(lrClasArt);
        lrClasArt.SetNivelFilter(Nivel, Id);
        IF lrClasArt.FINDSET() THEN
            IF Nivel = 1 THEN // Si es el primer nivel borra todos los registros relacionados
                lrClasArt.DELETEALL()
            ELSE // Si no, deja en blanco el nivel eliminado
                REPEAT
                    lrClasArt.ValidateLevelId(Nivel, 0);
                    lrClasArt.MODIFY();
                UNTIL lrClasArt.NEXT() = 0;
    end;

    trigger OnRename()
    begin
        ERROR(Text003Txt);
    end;

    procedure VerSubniveles()
    var
        lrClass: Record "Clasificaciones";
    begin
        IF (Id = 0) OR (Nivel > 2) THEN EXIT;
        CLEAR(lrClass);
        lrClass.SETRANGE("Tipo Clasificacion", "Tipo Clasificacion");
        IF Nivel = 0 THEN
            lrClass.SETRANGE(Nivel, 1)
        ELSE BEGIN
            lrClass.SETRANGE(Nivel, Nivel + 1);
            lrClass.SETRANGE("Id Subordinado", Id);
        END;
        PAGE.RUN(Page::"Clasificaciones Subn", lrClass);
    end;

    procedure SubnivelesRM() result: Boolean
    var
        lrClass: Record "Clasificaciones";
    begin
        // SubnivelesRM
        IF (Id = 0) OR (Nivel > 2) THEN EXIT;
        CLEAR(lrClass);
        lrClass.SETRANGE("Tipo Clasificacion", "Tipo Clasificacion");
        lrClass.SETRANGE(Nivel, Nivel + 1);
        lrClass.SETRANGE("Id Subordinado", Id);
        Result := PAGE.RUNMODAL(Page::"Clasificaciones Tree", lrClass) = ACTION::LookupOK;
        IF Result THEN GET(lrClass.Id);
    end;

    // procedure CambiaDescripcion()
    // var
    //     lrClasArt: Record "Clasificacion Articulos";
    // begin
    //     CLEAR(lrClasArt);
    //     CASE Nivel OF 1: BEGIN
    //         lrClasArt.SETRANGE(N1, Id);
    //         lrClasArt.MODIFYALL("Nivel 1", Descripcion);
    //     END;
    //     2: BEGIN
    //         lrClasArt.SETRANGE(N2, Id);
    //         lrClasArt.MODIFYALL("Nivel 2", Descripcion);
    //     END;
    //     3: BEGIN
    //         lrClasArt.SETRANGE(N3, Id);
    //         lrClasArt.MODIFYALL("Nivel 3", Descripcion);
    //     END;
    //     END;
    // end;
}
