table 58005 "Importe Tasa Producto"
{
    fields
    {
        field(1; "Codigo Tasa/Prod"; code[20])
        {
            Caption = 'Código Tasa/Prod';
            TableRelation = "Tasa Producto";
            NotBlank = true;

            trigger OnValidate()
            begin
                SeImptDescription();
            end;
        }
        field(2; Id; Integer)
        {
            Editable = False;
        }
        field(5; Descripcion; text[30])
        {
            Caption = 'Descripción';
        }
        field(10; Importe; Decimal)
        {
            Caption = 'Importe';

            trigger OnValidate()
            begin
                CntrlDupl();
                SeImptDescription();
            end;
        }
    }
    keys
    {
        key(Key1; "Codigo Tasa/Prod", Id)
        {
            Clustered = true;
        }
    }
    var
        Text001Txt: TextConst ESP = 'Ya existe una línea para %1 con importe %2';

    trigger OnInsert()
    var
        lrImpTasas: Record "Importe Tasa Producto";
    begin
        TESTFIELD("Codigo Tasa/Prod");
        CLEAR(lrImpTasas);
        lrImpTasas.SETRANGE("Codigo Tasa/Prod", "Codigo Tasa/Prod");
        lrImpTasas.ASCENDING(FALSE);
#pragma warning disable AA0181
        IF lrImpTasas.FindSet() THEN
#pragma warning restore AA0181
            Id := lrImpTasas.Id + 1
        ELSE
            Id := 1;
    end;

    trigger OnDelete()
    var
        lrRel: Record "Relacion Tasa Producto";
    begin
        // Relaciones
        CLEAR(lrRel);
        lrRel.SETCURRENTKEY(Item, "Codigo Tasa/Prod", "Id Lin Precio");
        lrRel.SETRANGE("Codigo Tasa/Prod", "Codigo Tasa/Prod");
        lrRel.SETRANGE(lrRel."Id Lin Precio", Id);
        lrRel.DELETEALL();
    end;

    procedure ShowProductos()
    var
        lrRel: Record "Relacion Tasa Producto";
    begin
        // ShowProductos
        CLEAR(lrRel);
        lrRel.SETCURRENTKEY(Item, "Codigo Tasa/Prod", "Id Lin Precio");
        lrRel.SETRANGE("Codigo Tasa/Prod", "Codigo Tasa/Prod");
        lrRel.SETRANGE("Id Lin Precio", Id);
        PAGE.RUN(0, lrRel);
    end;

    procedure GeImptDescription(pwCabDescrp: Text[30]; "pwIs%": Boolean): Text[30]
    begin
        // GeImptDescription
        EXIT(GeImptDesc(pwCabDescrp, "pwIs%", Importe));
    end;

    local procedure GeImptDesc(pwCabDescrp: Text[30]; "pwIs%": Boolean; pwImporte: Decimal): Text[30]
    var
        lwTxt: text[150];
    begin
        // GeImptDesc
        IF "pwIs%" THEN
            lwTxt := STRSUBSTNO('%1 %2 %', pwCabDescrp, pwImporte)
        ELSE
            lwTxt := STRSUBSTNO('%1 %2', pwCabDescrp, pwImporte);
        IF STRLEN(lwTxt) > MAXSTRLEN(Descripcion) THEN
            EXIT(pwCabDescrp)
        ELSE
            EXIT(StrSubstNo(lwTxt,1 ,30));
    end;

    procedure SeImptDescription()
    var
        lrTasa: Record "Tasa Producto";
        lwTxt1: Text[30];
        lwTxt2: Text[30];
    begin
        // SeImptDescription
        IF lrTasa.GET("Codigo Tasa/Prod") THEN BEGIN
            lwTxt1 := GeImptDesc(lrTasa.Descripcion, lrTasa."Tipo Aplicacion" <> lrTasa."Tipo Aplicacion"::"Importe Fijo", xRec.Importe);
            IF (lwTxt1 = Descripcion) OR (Descripcion = '') THEN BEGIN
                lwTxt2 := GeImptDescription(lrTasa.Descripcion, lrTasa."Tipo Aplicacion" <> lrTasa."Tipo Aplicacion"::"Importe Fijo");
                Descripcion := lwTxt2;
            END;
        END;
    end;

    procedure CntrlDupl()
    var
        lrImp: Record "Importe Tasa Producto";
    begin
        // CntrlDupl
        // Controlamos que no se dupliquen las lienas
        CLEAR(lrImp);
        lrImp.SETRANGE("Codigo Tasa/Prod", "Codigo Tasa/Prod");
        lrImp.SETRANGE(Importe, Importe);
        lrImp.SETFILTER(Id, '<>%1', Id);
        IF lrImp.IsEmpty() THEN ERROR(Text001Txt, "Codigo Tasa/Prod", Importe);
    end;
}
