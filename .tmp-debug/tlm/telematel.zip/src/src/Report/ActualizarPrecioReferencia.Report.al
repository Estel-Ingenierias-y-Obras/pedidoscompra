Report 58000 "Actualizar Precio Referencia"
//R_58000_Actualizar_Precio_Referencia
{
    ProcessingOnly = true;

    dataset
    {
        dataitem(Item; Item)
        {
            DataItemTableView = SORTING("No.");
            RequestFilterFields = "No.", "Id Marca TLM", "Referencia TLM";

            trigger OnPreDataItem()
            begin
                CLEAR(wCasos);
                IF (Item.GETFILTER(Item."Id Marca TLM") <> '') OR (Item.GETFILTER("Id Articulo TLM") <> '') OR (Item.GETFILTER("Referencia TLM") <> '') THEN Item.SETCURRENTKEY("Marca TLM", "Referencia TLM");
                cDlg.InitDialog(Text0002Txt, Item.COUNT);
            end;

            trigger OnAfterGetRecord()
            begin
                cDlg.UpDateDialog();
                IF "Id Articulo TLM" <> 0 THEN 
                    IF cGestGoCat.UpdateItemPrice(Item) THEN BEGIN
                        Item.MODIFY(TRUE);
                        wCasos += 1;
                    END;
            end;

            trigger OnPostDataItem()
            begin
                cDlg.CloseDialog();
                MESSAGE(Text0001Txt, wCasos);
            end;
        }
    }
    VAR
        
        cDlg: Codeunit "Dialog Mng";
        cGestGoCat: Codeunit GestGoCatalog;
        wCasos: Integer;
        Text0001Txt: TextConst ESP = 'Se han modificado %1 Casos';
        
        Text0002Txt: TextConst ESP = 'Actualizando Precios Referencia';
}
