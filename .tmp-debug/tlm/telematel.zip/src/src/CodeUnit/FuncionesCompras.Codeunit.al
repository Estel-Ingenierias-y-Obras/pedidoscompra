Codeunit 58008 "Funciones Compras"
//C_58008_Funciones_Compras
{
    Permissions = TableData 169 = rimd;

    VAR // Text016: TextConst ESP = 'El pedido debe de estar lanzado';
    // cFunEstel: Codeunit 50000;
    // cMail: Codeunit 397;
    // cFileMng: Codeunit 419;
    // cFunProy: Codeunit 50008;
    // rConfCompras: Record 312;
    // [EventSubscriber(Table, 38, OnBeforeInsertEvent)]
    // LOCAL PROCEDURE OnBeforeInsertPurchHeader@1000000014(VAR Rec@1000000000 : Record 38; RunTrigger@1000000001 : Boolean);
    // BEGIN
    //     // #340459 Bloqueo proveedores
    //     IF RunTrigger THEN
    //         CkeckBlockVendors(Rec, FALSE);
    // END;
    // [EventSubscriber(Table, 38, OnAfterModifyEvent)]
    // LOCAL PROCEDURE OnAftModfyPurchHeader@1000000018(VAR Rec@1000000000 : Record 38; VAR xRec@1000000001 : Record 38; RunTrigger@1000000002 : Boolean);
    // BEGIN
    //     // #340459 Bloqueo proveedores
    //     IF RunTrigger THEN
    //         CkeckBlockVendors(Rec, FALSE);
    // END;
    // [EventSubscriber(Table, 39, OnBeforeInsertEvent)]
    // LOCAL PROCEDURE OnBeforeInsertPurchLine@1000000008(VAR Rec@1000000000 : Record 39; RunTrigger@1000000001 : Boolean);
    // BEGIN
    //     // #340459 Bloqueo proveedores
    //     IF RunTrigger THEN
    //         CkeckLinBlockVendors(Rec);
    // END;
    // [EventSubscriber(Table, 39, OnBeforeModifyEvent)]
    // LOCAL PROCEDURE OnBeforModfyPurchLine@1000000011(VAR Rec@1000000000 : Record 39; VAR xRec@1000000001 : Record 39; RunTrigger@1000000002 : Boolean);
    // BEGIN
    //     // #340459 Bloqueo proveedores
    //     IF RunTrigger THEN
    //         CkeckLinBlockVendors(Rec);
    // END;
    // [EventSubscriber(Table, 38, OnAfterValidateEvent, "Buy-from Vendor No.")]
    // LOCAL PROCEDURE OnValBuyVendorPurchHeader@1000000019(VAR Rec@1000000000 : Record 38; VAR xRec@1000000001 : Record 38; CurrFieldNo@1000000002 : Integer);
    // BEGIN
    //     // #340459 Bloqueo proveedores
    //     CkeckBlockVendors(Rec, FALSE);
    // END;
    // [EventSubscriber(Table, 38, OnAfterValidateEvent, "Pay-to Vendor No.")]
    // LOCAL PROCEDURE OnValPayVendorPurchHeader@1000000022(VAR Rec@1000000000 : Record 38; VAR xRec@1000000001 : Record 38; CurrFieldNo@1000000002 : Integer);
    // BEGIN
    //     // #340459 Bloqueo proveedores
    //     CkeckBlockVendor(Rec, Rec."Pay-to Vendor No.", FALSE);
    // END;
    // [EventSubscriber(Table, 39, OnAfterValidateEvent, "Direct Unit Cost")]
    // LOCAL PROCEDURE OnValDirectUnitCost_PurcLines@1000000005(VAR Rec@1000000000 : Record 39; VAR xRec@1000000001 : Record 39; CurrFieldNo@1000000002 : Integer);
    // BEGIN
    //     IF CurrFieldNo = Rec.FIELDNO("Direct Unit Cost") THEN
    //         BloqueaPrecLinErr(Rec); //  #336441
    // END;
    // [EventSubscriber(Table, 39, OnAfterValidateEvent, "Line Discount Amount")]
    // LOCAL PROCEDURE OnValDiscAmount_PurcLines@1000000012(VAR Rec@1000000000 : Record 39; VAR xRec@1000000001 : Record 39; CurrFieldNo@1000000002 : Integer);
    // BEGIN
    //     IF (CurrFieldNo = Rec.FIELDNO("Line Discount Amount")) AND (Rec."Line Discount Amount" <> xRec."Line Discount Amount") THEN
    //         BloqueaPrecLinErr(Rec); // #336441
    // END;
    // [EventSubscriber(Table, 39, OnAfterValidateEvent, "Line Discount %")]
    // LOCAL PROCEDURE "OnValDisc%_PurcLines"@1000000015(VAR Rec@1000000000 : Record 39; VAR xRec@1000000001 : Record 39; CurrFieldNo@1000000002 : Integer);
    // BEGIN
    //     IF (CurrFieldNo = Rec.FIELDNO(Rec."Line Discount %")) AND (Rec."Line Discount Amount" <> xRec."Line Discount Amount") THEN
    //         BloqueaPrecLinErr(Rec); // #336441
    // END;
    // [EventSubscriber(Table, 39, OnAfterValidateEvent, "Line Amount")]
    // LOCAL PROCEDURE OnValLineAmount_PurcLines@1000000023(VAR Rec@1000000000 : Record 39; VAR xRec@1000000001 : Record 39; CurrFieldNo@1000000002 : Integer);
    // BEGIN
    //     IF (CurrFieldNo = Rec.FIELDNO(Rec."Line Amount")) AND (Rec."Line Discount Amount" <> xRec."Line Discount Amount") THEN
    //         BloqueaPrecLinErr(Rec); // #336441
    // END;
    // [EventSubscriber(Table, 23, OnAfterValidateEvent, Blocked)]
    // LOCAL PROCEDURE OnBlockVendor@1000000003(VAR Rec@1000000000 : Record 23; VAR xRec@1000000001 : Record 23; CurrFieldNo@1000000002 : Integer);
    // BEGIN
    //     // #340459Bloqueo proveedores
    //     //  17/11/20 JPT
    //     IF Rec.Blocked = Rec.Blocked::All THEN BEGIN
    //         Rec."Bloqueo Albaranes" := TRUE;
    //         Rec."Bloqueo Pedidos" := TRUE;
    //         Rec."Bloqueo Facturas" := TRUE;
    //     END;
    // END;
    // PROCEDURE SendMailOrder@1000000021(prCabC@1000000000 : Record 38);
    // VAR
    //     lrCabC@1000000008 : Record 38;
    //   lrVendor@1000000001 : Record 23;
    //   lrCmpInf@1000000002 : Record 79;
    //   lrRepSel@1000000012 : Record 77;
    //   lwBody@1000000003 : Text[250];
    //   lwSubject@1000000004 : Text[250];
    //   lwFilename@1000000005 : Text[1024];
    //   LTEXT0001@1000000006 : TextConst 'ESP=Pedido %1 N§ %2;ESM=Pedido %1 N§ %2';
    //   LTEXT0002@1000000009 : TextConst 'ESP=No pudo crearse el PDF %1;ESM=No pudo crearse el PDF %1';
    //   lwFilename2@1000000017 : Text[1024];
    //   lwFolder2@1000000018 : Text[1024];
    //   lwPath@1000000014 : Text[250];
    //   lwOk@1000000010 : Boolean;
    //   LTEXT0003@1000000011 : TextConst 'ESP=Pedido';
    //   lwAutor@1000000007 : Text[250];
    //   lwIdInf@1000000013 : Integer;
    //   LTEXT0004@1000000015 : TextConst 'ESP=NAVPCPDF';
    //   lwTime@1000000016 : Time;
    // BEGIN
    //   // SendMailOrder
    //   // Mandar por correo un pedido de compra adjuntado PDF
    //   IF prCabC."Document Type" <> prCabC."Document Type"::Order THEN
    //     EXIT;
    //   IF prCabC.Status = prCabC.Status::Open THEN
    //     prCabC.FIELDERROR(Status, Text016);
    //   lrCabC.COPY(prCabC);
    //   lrCabC.SETRECFILTER;
    //   // Buscamos el id de informe configurado
    //   lwIdInf := 0;
    //   CLEAR(lrRepSel);
    //   lrRepSel.SETRANGE(Usage, lrRepSel.Usage::"P.Order");
    //   lrRepSel.FIND('-'); // Si no lo encuentra da un error
    //   lwIdInf := lrRepSel."Report ID";
    //   lwPath := STRSUBSTNO('%1%2', TEMPORARYPATH, LTEXT0004);
    //   //lwPath := STRSUBSTNO('%1%2', cFileMng.ServerTempFileName, LTEXT0004);
    //   cFunEstel.CreaLimpiaFolder(lwPath);
    //   lwFilename := STRSUBSTNO('%1\%2 %3.PDF', lwPath , LTEXT0003 , prCabC."No.") ;
    //   IF EXISTS(lwFilename) THEN
    //     lwOk := ERASE(lwFilename);
    //   CLEAR(lrVendor);
    //   lrVendor.GET(prCabC."Buy-from Vendor No.");
    //   //lrVendor.TESTFIELD("E-Mail");
    //   lrCmpInf.GET;
    //   CLEAR(cMail);
    //   lwSubject := STRSUBSTNO(LTEXT0001, lrCmpInf.Name, prCabC."No.");
    //   lwBody    := ''; // Body en blanco para que no desaparezca la firma
    //   lwAutor   := STRSUBSTNO('%1 - %2', lrCmpInf.Name, USERID);
    //   REPORT.SAVEASPDF(lwIdInf,lwFilename,lrCabC);
    //   // JPT 06/10/2016 Aqui puede haber un error si se manda a importar un archivo que "aœn no se ha creado"
    //   // Por eso he insertado una funci½n de retardo buscando si existe el archivo
    //   lwTime := TIME;
    //   lwOk := FALSE;
    //   REPEAT
    //     lwOk := EXISTS(lwFilename);
    //     IF NOT lwOk THEN // Si pasamos de 7 segundos, cedemos
    //       lwOk := TIME - lwTime > 7000;
    //   UNTIL lwOk;
    //   // Ahora hay que bajarlo
    //   // lwFilename2 := cFileMng.ClientTempFileName('.PDF');
    //   lwFolder2 := cFileMng.CreateClientTempSubDirectory;
    //   lwFilename2 := STRSUBSTNO('%1\%2 %3.PDF', lwFolder2 , LTEXT0003 , prCabC."No.") ;
    //   cFileMng.DownloadToFile(lwFilename,lwFilename2);
    //   lwTime := TIME;
    //   lwOk := FALSE;
    //   REPEAT
    //     lwOk := EXISTS(lwFilename2);
    //     IF NOT lwOk THEN // Si pasamos de 7 segundos, cedemos
    //       lwOk := TIME - lwTime > 7000;
    //   UNTIL lwOk;
    //   lwOk := cMail.NewMessage(lrVendor."E-Mail",'','', lwSubject, lwBody, lwFilename2, TRUE);
    // END;
    // PROCEDURE TraspasaAPedido@1000000028(VAR prLinC@1000000000 : Record 39);
    // VAR
    //   lrOK@1000000001 : Boolean;
    //   lrLinAlb@1000000002 : Record 121;
    //   lrLinPed@1000000003 : Record 39;
    //   lrLinCab2@1000000004 : Record 39;
    //   lrTmpCab@1000000005 : TEMPORARY Record 38;
    //   lrCab@1000000006 : Record 38;
    //   lrLinFact@1000000007 : Record 123;
    //   lrCabFct@1000000008 : Record 122;
    //   lrLinAbn@1000000009 : Record 125;
    //   lrCabAbn@1000000010 : Record 124;
    // BEGIN
    //   //TraspasaAPedido
    //   // PRYTO-2017/026 JPT 20/06/2017
    //   // Al cambiar un precio o descuento en una factura de compra, hay que cambiar ese valor en el pedido relacionado
    //   rConfCompras.GET;
    //   //#91844. Debe de estar configurado para aplicar esta medida
    //   IF NOT rConfCompras."Prec/Dto Factura a Pedido" THEN
    //     EXIT;
    //   IF NOT (prLinC."Document Type" IN [prLinC."Document Type"::Invoice, prLinC."Document Type"::"Credit Memo"]) THEN
    //     EXIT;
    //   // Buscamos el pedido relacioando
    //   lrOK := lrLinAlb.GET(prLinC."Receipt No.", prLinC."Receipt Line No.");
    //   IF lrOK THEN
    //     lrOK := lrLinPed.GET(lrLinPed."Document Type"::Order, lrLinAlb."Order No.", lrLinAlb."Order Line No.");
    //   IF lrOK THEN BEGIN // Si hay diferencias
    //     lrOK := (lrLinPed."Direct Unit Cost" <> prLinC."Direct Unit Cost") OR
    //             (lrLinPed."Line Discount %" <> prLinC."Line Discount %") ;
    //   END;
    //   IF lrOK THEN BEGIN
    //     // Ahora que hemos encontrado el pedido tenemos que determinar que se trata de la ultima factura, que ser  la que pueda cambiar los valores
    //     CLEAR(lrLinCab2);
    //     CLEAR(lrTmpCab);
    //     CLEAR(lrLinAlb);
    //     lrLinAlb.SETRANGE("Order No."      , lrLinPed."Document No.");
    //     lrLinAlb.SETRANGE("Order Line No." , lrLinPed."Line No.");
    //     IF lrLinAlb.FINDSET THEN BEGIN
    //       IF lrLinAlb.COUNT > 1 THEN BEGIN
    //         // Si hay m s de un albaran relacionado con la l¡nea
    //         // Capturamos todas las facturas a las que ha ido
    //         REPEAT
    //           // Cap Compra
    //           CLEAR(lrLinCab2);
    //           lrLinCab2.SETFILTER("Document Type"   ,'%1|%2', lrLinCab2."Document Type"::Invoice, lrLinCab2."Document Type"::"Credit Memo");
    //           lrLinCab2.SETRANGE("Receipt No."     , lrLinAlb."Document No.");
    //           lrLinCab2.SETRANGE("Receipt Line No.", lrLinAlb."Line No.");
    //           IF lrLinCab2.FINDSET THEN BEGIN
    //             REPEAT
    //               IF lrCab.GET(lrLinCab2."Document Type", lrLinCab2."Document No." ) THEN BEGIN
    //                 lrTmpCab := lrCab;
    //                 IF NOT lrTmpCab.FIND THEN
    //                   lrTmpCab.INSERT;
    //               END;
    //             UNTIL lrLinCab2.NEXT=0;
    //           END;
    //           // Factura
    //           CLEAR(lrLinFact);
    //           lrLinFact.SETRANGE("Receipt No."     , lrLinAlb."Document No.");
    //           lrLinFact.SETRANGE("Receipt Line No.", lrLinAlb."Line No.");
    //           IF lrLinFact.FINDSET THEN BEGIN
    //             REPEAT
    //               IF lrCabFct.GET(lrLinFact."Document No." ) THEN BEGIN
    //                 lrTmpCab.TRANSFERFIELDS(lrCabFct);
    //                 lrTmpCab."No." := 'X' + lrTmpCab."No."; // Numero ficticio para que no pueda coincidir con el numero de borrador
    //                 IF NOT lrTmpCab.FIND THEN
    //                   lrTmpCab.INSERT;
    //               END;
    //             UNTIL lrLinCab2.NEXT=0;
    //           END;
    //           // Abono
    //         UNTIL lrLinAlb.NEXT=0;
    //         lrTmpCab.SETCURRENTKEY("Document Date");
    //         IF lrTmpCab.FINDLAST THEN BEGIN
    //           lrOK := lrTmpCab."No." = prLinC."Document No.";
    //         END;
    //       END;
    //     END;
    //   END;
    //   IF lrOK THEN BEGIN
    //     lrCab.GET(lrLinPed."Document Type", lrLinPed."Document No.");
    //     lrLinPed.SetPurchHeader(lrCab);
    //     lrLinPed.SuspendStatusCheck(TRUE);
    //     IF lrLinPed."Direct Unit Cost" <> prLinC."Direct Unit Cost" THEN
    //       lrLinPed.VALIDATE("Direct Unit Cost", prLinC."Direct Unit Cost");
    //     IF lrLinPed."Line Discount %" <> prLinC."Line Discount %" THEN
    //       lrLinPed.VALIDATE("Line Discount %" , prLinC."Line Discount %");
    //     lrLinPed.MODIFY(FALSE);
    //   END;
    // END;
    // PROCEDURE ControlImputacionProyecto@1000000000(prJob@1000000000 : Record 167;prJobJLn@1000000001 : Record 210);
    // BEGIN
    //   // ControlImputacionProyecto
    //   // #323261 "Imputar FV en PV ya cerrado" JPT 12/08/20
    //   // #346456 Modificaci¢n Cierre Imputaci¢n Compras
    //   // Lo movemos a funciones Proyecto que es el lugar m s indicado
    //   cFunProy.ControlImputacionProyecto(prJob,prJobJLn);
    // END;
    PROCEDURE BloqueaPrecLinPedido(VAR prLine: Record 39) Result: Boolean;
    VAR
        lrArt: Record "Telematel Articulos";
        lrUsrSTP: Record 91;
    BEGIN
        // BloqueaPrecLinPedido
        // #336441 Bloqueo de Precios y Descuentos en Pedidos Compra
        // JPT - 23/09/2020
        // Devuelve true si la l¡nea tiene precios y Dtos Bloqueados
        Result := FALSE;
        // WITH prLine DO BEGIN
        //     // En principio unicamente para pedidos
        //     IF (NOT ("Document Type" IN ["Document Type"::Order])) OR ("Id Articulo Marca TLM" = 0) OR (Type <> Type::Item) THEN
        //         EXIT(FALSE);
        //     IF lrArt.GET("Id Articulo Marca TLM") THEN BEGIN
        //         lrArt.CALCFIELDS("Precio Libre");
        //         Result := NOT lrArt."Precio Libre";
        //         IF Result THEN BEGIN // Si est  bloqueado miramos si el usuario tiene permisos
        //             IF lrUsrSTP.GET(USERID) THEN
        //                 Result := NOT lrUsrSTP."Editar Prec/Dto Pedido Compra";
        //         END;
        //     END;
        // END;
        // En principio unicamente para pedidos
        IF (NOT (prLine."Document Type" IN [prLine."Document Type"::Order])) OR (prLine."Id Articulo Marca TLM" = 0) OR (prLine.Type <> prLine.Type::Item) THEN EXIT(FALSE);
        IF lrArt.GET(prLine."Id Articulo Marca TLM") THEN BEGIN
            lrArt.CALCFIELDS("Precio Libre");
            Result := NOT lrArt."Precio Libre";
            IF Result THEN  // Si est  bloqueado miramos si el usuario tiene permisos
                IF lrUsrSTP.GET(USERID) THEN Result := NOT lrUsrSTP."Editar Prec/Dto Pedido Compra";
            
        END;
    END;
    // PROCEDURE BloqueaPrecLinErr@1000000002(VAR prLine@1000000000 : Record 39);
    // VAR
    //   Text00001@1000000002 : TextConst 'ESP=No puede modificar precios ni descuentos en %1 %2';
    // BEGIN
    //   // BloqueaPrecLinErr
    //   // #336441 Bloqueo de Precios y Descuentos en Pedidos Compra
    //   // JPT - 23/09/2020
    //   // Provoca un eror si la l¡nea tiene precios y Dtos Bloqueados
    //   IF BloqueaPrecLinPedido(prLine) THEN
    //     ERROR(Text00001, prLine.TABLECAPTION, prLine.GETPOSITION);
    // END;
    // LOCAL PROCEDURE CkeckBlockVendor@1000000004(prPurcHd@1000000000 : Record 38;pwVendCode@1000000001 : Code[20];pwPost@1000000004 : Boolean);
    // VAR
    //   lrVendor@1000000002 : Record 23;
    //   lText001@1000000003 : TextConst 'ESP="%1 %2. El proveedor %3 %4  "';
    //   lwErrTxt@1000000005 : Text;
    //   lText002@1000000006 : TextConst 'ESP=%1 tiene la marca "%2"';
    // BEGIN
    //   // #340459 Bloqueo proveedores
    //   IF prPurcHd.ISTEMPORARY OR (pwVendCode='') THEN
    //     EXIT;
    //   CLEAR(lrVendor);
    //   lrVendor.GET(pwVendCode);
    //   lwErrTxt := STRSUBSTNO(lText001, prPurcHd."Document Type", prPurcHd."No.", lrVendor."No.", lrVendor.Name);
    //   CASE prPurcHd."Document Type" OF
    //     prPurcHd."Document Type"::Order, prPurcHd."Document Type"::"Return Order" : BEGIN
    //       IF pwPost THEN BEGIN
    //         IF (lrVendor."Bloqueo Albaranes" AND (prPurcHd.Ship OR prPurcHd.Receive)) THEN
    //           ERROR(lText002, lwErrTxt, lrVendor.FIELDCAPTION("Bloqueo Albaranes"));
    //         IF (lrVendor."Bloqueo Facturas" AND prPurcHd.Invoice)  THEN
    //           ERROR(lText002, lwErrTxt, lrVendor.FIELDCAPTION("Bloqueo Facturas"));
    //       END ELSE
    //         IF lrVendor."Bloqueo Pedidos" THEN
    //           ERROR(lText002, lwErrTxt, lrVendor.FIELDCAPTION("Bloqueo Pedidos"));
    //     END;
    //     prPurcHd."Document Type"::Invoice, prPurcHd."Document Type"::"Credit Memo" :
    //         IF lrVendor."Bloqueo Facturas" THEN
    //           ERROR(lText002, lwErrTxt, lrVendor.FIELDCAPTION("Bloqueo Facturas"));
    //   END;
    // END;
    // PROCEDURE CkeckBlockVendors@1000000009(prPurcHd@1000000000 : Record 38;pwPost@1000000001 : Boolean);
    // BEGIN
    //   // #340459 Bloqueo proveedores
    //   CkeckBlockVendor(prPurcHd, prPurcHd."Buy-from Vendor No.", pwPost);
    //   IF prPurcHd."Pay-to Vendor No." <> prPurcHd."Buy-from Vendor No." THEN
    //     CkeckBlockVendor(prPurcHd, prPurcHd."Pay-to Vendor No.", pwPost);
    // END;
    // LOCAL PROCEDURE CkeckLinBlockVendors@1000000006(prPurchLine@1000000000 : Record 39);
    // VAR
    //   lrPurcHd@1000000001 : Record 38;
    // BEGIN
    //   // #340459 Bloqueo proveedores
    //   IF prPurchLine.ISTEMPORARY OR (prPurchLine."Document No."='') THEN
    //     EXIT;
    //   lrPurcHd.GET(prPurchLine."Document Type", prPurchLine."Document No.");
    //   CkeckBlockVendors(lrPurcHd,FALSE);
    // END;
    // LOCAL PROCEDURE HaveChanged@1000000020(pwRec@1000000000 : Variant;pwXRec@1000000001 : Variant) : Boolean;
    // VAR
    //   RecRf@1000000002 : RecordRef;
    //   RecRf2@1000000003 : RecordRef;
    //   lwCnt@1000000004 : Integer;
    //   FldRf@1000000005 : FieldRef;
    //   FldRf2@1000000006 : FieldRef;
    // BEGIN
    //   RecRf.GETTABLE(pwRec);
    //   RecRf2.GETTABLE(pwXRec);
    //   FOR lwCnt := 1 TO RecRf.FIELDCOUNT DO BEGIN
    //     FldRf := RecRf.FIELDINDEX(lwCnt);
    //     FldRf2 := RecRf2.FIELDINDEX(lwCnt);
    //     IF FORMAT(FldRf.VALUE) <> FORMAT(FldRf2.VALUE) THEN
    //       EXIT(TRUE);
    //   END;
    // END;
}
