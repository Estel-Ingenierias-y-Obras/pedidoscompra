Codeunit 58004 "Dialog Mng"
//C_58004_DialogMng
{
    Permissions = TableData 169 = rimd;

    VAR
        wDlg: Dialog;
        wDlTotal: Integer;
        wDLIdx: Integer;
        wDlSteep: Integer;
        wDIShow: Boolean;

    PROCEDURE InitDialog(pwText: Text; pwTotal: Integer);
    BEGIN
        wDIShow := GUIALLOWED;
        IF wDIShow THEN BEGIN
            wDlTotal := pwTotal;
            wDLIdx := 0;
            wDlSteep := wDlTotal DIV 100;
            IF wDlSteep < 1 THEN wDlSteep := 1;
            wDlg.OPEN(pwText + '\@1@@@@@@@@@@@@@@@@@@@')
        END;
    END;

    PROCEDURE UpDateDialog();
    BEGIN
        // CloseDialog
        IF wDIShow THEN BEGIN
            wDLIdx += 1;
            IF (wDLIdx MOD wDlSteep) = 0 THEN wDlg.UPDATE(1, ROUND(wDLIdx / wDlTotal * 10000, 1));
        END;
    END;

    PROCEDURE CloseDialog();
    BEGIN
        IF wDIShow THEN wDlg.CLOSE();
    END;
}
