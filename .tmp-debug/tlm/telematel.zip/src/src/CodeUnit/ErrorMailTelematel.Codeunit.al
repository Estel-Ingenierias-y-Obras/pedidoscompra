Codeunit 58005 ErrorMailTelematel
//C_58005_ErrorMailTelematel
{
    TableNo = "Go Catalog Connection Log";

    trigger OnRun()
    BEGIN
        SendMail(Rec);
    END;

    VAR
        wSetup: Record "Telematel Setup";
    //   cGestGoCat@1000000002 : Codeunit 50101;
    //   wIntento@1000000000 : Integer;
    //   wTimeCtrl@1000000003 : Boolean;
    PROCEDURE SendMail(prLog: Record "Go Catalog Connection Log");
    VAR
        // SMTPSetup: Record "SMTP Mail Setup";
        // SMTPMail: Codeunit "SMTP Mail";
        EmailItem: Record "Email Item";
        Out: OutStream;
        // EmailMessage: Codeunit "Email Message";
        // Email: Codeunit Email;
        // MailManagement: Codeunit "Mail Management";
        // cFunEs: Codeunit "Funciones Estel";
        // lwLogPg: Page "Go Catalog Connection Log";
        lwBody: Text;
        lwSubject: Text;
        MailFromTxt: TextConst ESP = 'Dynamics NAV 2016 (%1)';
        SubjectTxt: TextConst ESP = 'Error en Importación Go Catalog';
        // lrURL: Text;
        lText0001Txt: TextConst ESP = 'Se ha producido el siguiente Error:';
        lwErrorrMsg: Text;
    BEGIN
        // SendMail
        // #321633
        wSetup.GET();
        lwErrorrMsg := prLog.GetError();
        lwErrorrMsg := DELCHR(lwErrorrMsg, '<>');
        IF prLog.Result <> prLog.Result::Error THEN EXIT;
        IF (DELCHR(wSetup."Mail Notificacion Error", '<>') = '') OR (lwErrorrMsg = '') THEN EXIT;
        IF prLog.ErrorText[1] = '#' THEN EXIT;
        // SMTPSetup.GET();
        lwSubject := SubjectTxt;
        lwBody := lText0001Txt;
        //lwBody += cFunEs.GetReturnText + cFunEs.GetReturnText;
        lwBody += '<br><br>';
        lwBody += lwErrorrMsg;
        // SMTPMail.CreateMessage
        // (
        //   STRSUBSTNO(MailFrom, COMPANYNAME),
        //   SMTPSetup."User ID",
        //   wSetup."Mail Notificacion Error",
        //   lwSubject,
        //   lwBody,
        //   TRUE
        // );
        //   {
        //   lrURL := GETURL(CLIENTTYPE::Windows, COMPANYNAME, OBJECTTYPE::Page, PAGE::"Go Catalog Connection Log", prLog);
        //     IF lrURL <> '' THEN
        //         SMTPMail.AppendBody(lrURL);
        //   }
        EmailItem."From Name" := STRSUBSTNO(MailFromTxt, COMPANYNAME);
        // EmailItem."From Address" := SMTPSetup."User ID";
        EmailItem."Send to" := wSetup."Mail Notificacion Error";
        EmailItem.Subject := CopyStr(lwSubject, 1, MaxStrLen(EmailItem.Subject));
        EmailItem.Body.CreateOutStream(Out);
        Out.Write(lwBody);
        EmailItem."Send as HTML" := true;
        EmailItem.Send(true, "Email Scenario"::Default);
    END;
}
