Codeunit 58003 "JSON Manager"
{
    Permissions = TableData 122 = rimd;

    //     trigger OnRun()
    //     var
    //     begin
    //     end;
    VAR //JsonArray: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JArray";
        JsonArray: JsonArray;
        //         JsonObject: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JObject";
        JsonObject: JsonObject;
        //         JsonTkn: ARRAY[15] OF DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
        // JsonDoc: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
        //JsonType: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JTokenType";
        // JsonType: JsonToken;
        JsonDoc: JsonToken;
    // JSON: Record "JSON Buffer";
    // JSONRW: Codeunit "Json Text Reader/Writer";
    // JSONManagement: Codeunit "JSON Management";
    PROCEDURE SetJSON(pwJsonText: Text);
    BEGIN
        // CLEARALL;
        // JsonDoc := JsonDoc.Parse(pwJsonText);
        // CASE TRUE OF
        //     JsonDoc.Type.CompareTo(JsonType.Object) = 0:
        //         JsonObject := JsonDoc;
        //     JsonDoc.Type.CompareTo(JsonType.Array) = 0:
        //         JsonArray := JsonDoc;
        // END;
        //NEW
        JsonDoc.ReadFrom(pwJsonText);
        if JsonDoc.IsObject then
            JsonObject := JsonDoc.AsObject()
        else 
        if JsonDoc.IsArray then JsonArray := JsonDoc.AsArray()//NEW
    END;

    PROCEDURE SetJSONStream(pwJsonText: InStream) Result: Boolean;
    var
    // pwJsonTextIn: InStream;
    // pwJsonTextOut: OutStream;
    // TempBlob: Codeunit "Temp Blob";
    // Texto: Text;
    // tofile: Text;
    BEGIN
        // CLEARALL;
        // JsonDoc := JsonDoc.Parse(pwJsonText);
        // CASE TRUE OF
        //     JsonDoc.Type.CompareTo(JsonType.Object) = 0:
        //         JsonObject := JsonDoc;
        //     JsonDoc.Type.CompareTo(JsonType.Array) = 0:
        //         JsonArray := JsonDoc;
        // END;
        //NEW
        /*tofile := 'test.json';
        if DownloadFromStream(pwJsonText, 'Dialog', 'Folder', 'File', tofile) then
        ;*/
        //COMENTAR
        // if JsonDoc.ReadFrom(pwJsonText) then begin
        //     if JsonDoc.IsObject then
        //         JsonObject := JsonDoc.AsObject()
        //     else
        //         if JsonDoc.IsArray then
        //             JsonArray := JsonDoc.AsArray()
        // end else begin
        //     pwJsonText.ReadText(Texto);
        //     Error(Texto);
        // end;
        //COMENTAR
        //DESCOMENTAR
        // FIX: se comprueba el resultado de ReadFrom en vez de ignorarlo; si el stream
        // viene vacío o el JSON es inválido, Result devuelve FALSE en vez de fallar en silencio.
        Result := JsonDoc.ReadFrom(pwJsonText);
        IF NOT Result THEN
            EXIT(FALSE);
        if JsonDoc.IsObject then
            JsonObject := JsonDoc.AsObject()
        else 
        if JsonDoc.IsArray then JsonArray := JsonDoc.AsArray()//DESCOMENTAR
                                                                   //NEW
    END;

    // LOCAL PROCEDURE GetFormat(): Text[20];
    // BEGIN
    //     EXIT('json');
    // END;
    //     PROCEDURE SetObject(pwIdNode: Text) Result: Boolean;
    //     VAR
    //         lwJTkn: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
    //     BEGIN
    //         lwJTkn := JsonDoc.Item(pwIdNode);
    //         IF ISNULL(lwJTkn) THEN
    //             EXIT(FALSE);
    //         Result := lwJTkn.Type.CompareTo(JsonType.Object) = 0;
    //         IF Result THEN
    //             JsonObject := lwJTkn;
    //     END;
    //     PROCEDURE SetArray(pwIdNode: Text) Result: Boolean;
    //     VAR
    //         lwJTkn: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
    //     BEGIN
    //         lwJTkn := JsonDoc.Item(pwIdNode);
    //         IF ISNULL(lwJTkn) THEN
    //             EXIT(FALSE);
    //         Result := lwJTkn.Type.CompareTo(JsonType.Array) = 0;
    //         IF Result THEN
    //             JsonArray := lwJTkn;
    //     END;
    //     PROCEDURE SetAObj(pwIndx: Integer) Result: Boolean;
    //     VAR
    //         lwJTkn: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
    //     BEGIN
    //         // Base 0
    //         lwJTkn := JsonArray.Item(pwIndx);
    //         IF ISNULL(lwJTkn) THEN
    //             EXIT(FALSE);
    //         Result := lwJTkn.Type.CompareTo(JsonType.Object) = 0;
    //         IF Result THEN
    //             JsonObject := lwJTkn;
    //     END;
    PROCEDURE SetOArray(pwIdNode: Text) Result: Boolean;
    VAR
        //lwJTkn: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
        lwJTkn: JsonToken;
    BEGIN
        // Base 0
        // lwJTkn := JsonObject.Item(pwIdNode);
        // IF ISNULL(lwJTkn) THEN
        //     EXIT(FALSE);
        // Result := lwJTkn.Type.CompareTo(JsonType.Array) = 0;
        // IF Result THEN
        //     JsonArray := lwJTkn;
        //NEW
        if not JsonObject.Get(pwIdNode, lwJTkn) then EXIT(FALSE);
        if lwJTkn.IsArray then begin
            JsonArray := lwJTkn.AsArray();
            exit(TRUE)
        end;
        //NEW
    END;
    //     PROCEDURE SetArrayFromPath(path: Text) Result: Boolean;
    //     VAR
    //         lwJTkn: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
    //     BEGIN
    //         lwJTkn := JsonDoc.SelectToken(path);
    //         IF ISNULL(lwJTkn) THEN
    //             EXIT(FALSE);
    //         Result := lwJTkn.Type.CompareTo(JsonType.Array) = 0;
    //         IF Result THEN
    //             JsonArray := lwJTkn;
    //     END;
    //     PROCEDURE SetObjectFromPath(path: Text) Result: Boolean;
    //     VAR
    //         lwJTkn: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
    //     BEGIN
    //         lwJTkn := JsonDoc.SelectToken(path);
    //         IF ISNULL(lwJTkn) THEN
    //             EXIT(FALSE);
    //         Result := lwJTkn.Type.CompareTo(JsonType.Object) = 0;
    //         IF Result THEN
    //             JsonObject := lwJTkn;
    //     END;
    PROCEDURE JACount() Result: Integer;
    BEGIN
        Result := JsonArray.Count;
    END;
    //     PROCEDURE GetJAValue(pwIndx: Integer; VAR pwValue: Variant) Result: Boolean;
    //     VAR
    //         lwJTkn: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
    //     BEGIN
    //         // Base 0
    //         CLEAR(pwValue);
    //         lwJTkn := JsonArray.Item(pwIndx);
    //         IF NOT (ISNULL(lwJTkn)) THEN
    //             Result := GetJTokenValue(lwJTkn, pwValue);
    //     END;
    //LOCAL PROCEDURE GetJTokenValue(pwJTkn: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken"; VAR pwValue: Variant) Result: Boolean;
    LOCAL PROCEDURE GetJTokenValue(pwJTkn: JsonToken; VAR pwValue: Variant) Result: Boolean;
    VAR
        //JVal: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JValue";
        JVal: JsonValue;
        // lwInt: Integer;
        // lwText: Text;
        // lwDec: Decimal;
        // lwBol: Boolean;
        // lwDT: DateTime;
        // wlGuid: GUID;
        TextAuxiliar: Text;
        // Where: Text;
        Length: Integer;
        primercaracter: text;
        ultimocaracter: text;
    BEGIN
        // Base 0
        CLEAR(pwValue);
        /*JsonType := pwJTkn.Type;
        CASE TRUE OF
            JsonType.CompareTo(JsonType.Integer) = 0,
          JsonType.CompareTo(JsonType.String) = 0,
          JsonType.CompareTo(JsonType.Float) = 0,
          JsonType.CompareTo(JsonType.Boolean) = 0,
          JsonType.CompareTo(JsonType.Date) = 0,
          JsonType.CompareTo(JsonType.Guid) = 0:
                Result := TRUE
            ELSE
                Result := FALSE;
        END;*/
        if pwJTkn.IsValue then
            Result := TRUE
        ELSE
            Result := FALSE;
        IF Result THEN BEGIN
            JVal := pwJTkn.AsValue();
            // pwValue := JVal;
            JVal.WriteTo(TextAuxiliar);
            Length := StrLen(TextAuxiliar);
            primercaracter := COPYSTR(TextAuxiliar, 1, 1);
            ultimocaracter := COPYSTR(TextAuxiliar, Length, 1);
            if (primercaracter = '"') and (ultimocaracter = '"') then TextAuxiliar := CopyStr(TextAuxiliar, 2, Length - 2);
            //TextAuxiliar := DelChr(TextAuxiliar, Where);
            pwValue := TextAuxiliar;
        END;
    END;
    //     PROCEDURE GetATextValue(pwIndx: Integer; VAR pwValue: Text) Result: Boolean;
    //     VAR
    //         lwVal2: Variant;
    //     BEGIN
    //         // Base 0
    //         CLEAR(pwValue);
    //         Result := GetJAValue(pwIndx, lwVal2);
    //         IF Result THEN
    //             pwValue := DELCHR(FORMAT(lwVal2, 0, 9), '<>');
    //     END;
    PROCEDURE GetAObjValue(pwIndx: Integer; pwIdNode: Text; VAR pwValue: Variant) Result: Boolean;
    VAR
        //lwJTkn: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
        lwJTkn: JsonToken;
        //lwJObject: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JObject";
        lwJObject: JsonObject;
    BEGIN
        // Base 0
        // Toma el valor(pwIdNode) dentro de un Id(pwIndex)  de un Array
        CLEAR(pwValue);
        //lwJTkn := JsonArray.Item(pwIndx);
        // IF ISNULL(lwJTkn) THEN
        //     EXIT(FALSE);
        if not JsonArray.get(pwIndx, lwJTkn) then EXIT(FALSE);
        // Result := lwJTkn.Type.CompareTo(JsonType.Object) = 0;
        // IF Result THEN BEGIN
        //     lwJObject := lwJTkn;
        //     lwJTkn := lwJObject.Item(pwIdNode);
        //     Result := GetJTokenValue(lwJTkn, pwValue);
        // END;
        if lwJTkn.IsObject then begin
            lwJObject := lwJTkn.AsObject();
            lwJObject.Get(pwIdNode, lwJTkn);
            Result := GetJTokenValue(lwJTkn, pwValue);
        end;
    END;
    //     PROCEDURE GetAArrayValue(pwIndx: Integer; pwIndx2: Integer; VAR pwValue: Variant) Result: Boolean;
    //     VAR
    //         lwJTkn: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
    //         lwJArray: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JArray";
    //     BEGIN
    //         // Base 0
    //         // Toma el valor(pwIndex2) dentro de un Id(pwIndex)  de un Array
    //         CLEAR(pwValue);
    //         lwJTkn := JsonArray.Item(pwIndx);
    //         IF ISNULL(lwJTkn) THEN
    //             EXIT(FALSE);
    //         Result := lwJTkn.Type.CompareTo(JsonType.Array) = 0;
    //         IF Result THEN BEGIN
    //             lwJArray := lwJTkn;
    //             lwJTkn := lwJArray.Item(pwIndx2);
    //             Result := GetJTokenValue(lwJTkn, pwValue);
    //         END;
    //     END;
    PROCEDURE GetObjValue(pwIdNode: Text; VAR pwValue: Variant) Result: Boolean;
    VAR
        // lwJTkn: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
        lwJTkn: JsonToken;
    BEGIN
        // Base 0
        // Toma el valor(pwIdNode2) dentro de un Id(pwIdNode)  de un Objeto
        // CLEAR(pwValue);
        // lwJTkn := JsonObject.Item(pwIdNode);
        // IF ISNULL(lwJTkn) THEN
        //     EXIT(FALSE);
        // Result := GetJTokenValue(lwJTkn, pwValue);
        //NEW
        if not JsonObject.Get(pwIdNode, lwJTkn) then EXIT(FALSE);
        Result := GetJTokenValue(lwJTkn, pwValue);
        //NEW
    END;
    //     PROCEDURE GetOObjValue(pwIdNode: Text; pwIdNode2: Text; VAR pwValue: Variant) Result: Boolean;
    //     VAR
    //         lwJTkn: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JToken";
    //         lwJObject: DotNet "'Newtonsoft.Json, Version=6.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed'.Newtonsoft.Json.Linq.JObject";
    //     BEGIN
    //         // Base 0
    //         // Toma el valor(pwIdNode2) dentro de un Id(pwIdNode)  de un Objeto
    //         CLEAR(pwValue);
    //         lwJTkn := JsonObject.Item(pwIdNode);
    //         IF ISNULL(lwJTkn) THEN
    //             EXIT(FALSE);
    //         Result := lwJTkn.Type.CompareTo(JsonType.Object) = 0;
    //         IF Result THEN BEGIN
    //             lwJObject := lwJTkn;
    //             lwJTkn := lwJObject.Item(pwIdNode2);
    //             Result := GetJTokenValue(lwJTkn, pwValue);
    //         END;
    //     END;
    //     PROCEDURE SetTknId(pwInx: Integer; pwType: option Object,Array) Result: Boolean;
    //     BEGIN
    //         // Para trabajar a varias profundidades
    //         // Situa el objeto o array en un array de Tokens
    //         Result := (pwInx > 0) AND (pwInx <= ARRAYLEN(JsonTkn));
    //         IF Result THEN
    //             CASE pwType OF
    //                 pwType::"Array":
    //                     JsonTkn[pwInx] := JsonArray;
    //                 pwType::Object:
    //                     JsonTkn[pwInx] := JsonObject;
    //                 ELSE
    //                     Result := FALSE;
    //             END;
    //     END;
    //     PROCEDURE GetTknId(pwInx: Integer; pwType: option Object,Array) Result: Boolean;
    //     BEGIN
    //         // Para trabajar a varias profundidades
    //         // Posiciona el objeto o array desde un array de Tokens
    //         Result := (pwInx > 0) AND (pwInx <= ARRAYLEN(JsonTkn));
    //         IF Result THEN
    //             CASE pwType OF
    //                 pwType::"Array":
    //                     BEGIN
    //                         Result := JsonTkn[pwInx].Type.CompareTo(JsonType.Array) = 0;
    //                         IF Result THEN
    //                             JsonArray := JsonTkn[pwInx];
    //                     END;
    //                 pwType::Object:
    //                     BEGIN
    //                         Result := JsonTkn[pwInx].Type.CompareTo(JsonType.Object) = 0;
    //                         IF Result THEN
    //                             JsonObject := JsonTkn[pwInx];
    //                     END;
    //                 ELSE
    //                     Result := FALSE;
    //             END;
    //     END;
    //     EVENT JsonArray::ListChanged(sender : Variant; e: DotNet "'System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'.System.ComponentModel.ListChangedEventArgs");
    //     BEGIN
    //     END;
    //     EVENT JsonArray::AddingNew(sender : Variant; e: DotNet "'System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'.System.ComponentModel.AddingNewEventArgs");
    //     BEGIN
    //     END;
    //     EVENT JsonArray::CollectionChanged(sender : Variant; e: DotNet "'System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'.System.Collections.Specialized.NotifyCollectionChangedEventArgs");
    //     BEGIN
    //     END;
}
