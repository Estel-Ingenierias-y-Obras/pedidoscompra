codeunit 58000 GestGoCatalog
{
    TableNo = "Telematel Setup";
    //Permissions = TableData "Item Cross Reference" = rimd;
    Permissions = TableData "Item Reference" = rimd;

    var
        wTLMStp: Record "Telematel Setup";
        cFileMng: Codeunit "File Management";
        //         //         cCpmpGZIP: Codeunit 8619;
        //         //         cJsonMgt: Codeunit "Dynamics.is JSon Mgt.";
        NoSeries: Codeunit "No. Series";
        wOK: Boolean;
        Text001Lbl: TextConst ESP = 'Actualizando Marcas (%1)';
        //         Text002: TextConst ESP = '¿Confirma que quiere Actualizar todas las marcas?';
        wURLType: option " ",BrandIndex,Brand,ProductIndex,Product,Categories;
        Text003Lbl: TextConst ESP = 'Buscando Marcas Eliminadas/Perdidas';
        Text004Lbl: TextConst ESP = 'Actualizando Artículos';
        wCntArt: Integer;
        Text005Lbl: TextConst ESP = 'Va a importar %1 productos.¿Desea Seguir?';
        wTimeCtrl: Boolean;
        wToTime: DateTime;
        Text006Lbl: TextConst ESP = 'Sobrepasado Tiempo Máximo';
        wMode: option API,File;
        wInitFolder: Text;
        Text007Lbl: TextConst ESP = '#ERROR UN20#';
        Text008Lbl: TextConst ESP = 'El producto %1 de la marca %2 contiene un codigo UD %3 - codigo UD20 %4 que no existe en las tablas Unidades - Unidades UD20';

    trigger OnRun()
    begin
        // Solo Para Carga Inicial. Comentar para el resto
        // {
        // wMode := wMode::File;
        // wInitFolder := 'C:\GoCatalog Carga Inicial';
        // }
        IF LoadStup2(Rec) THEN UpdateBrands();
    end;

    procedure UpdateBrands()
    var
        lwcJMng: Codeunit "JSON Manager";
    begin
        // UpdateClients
        CLEAR(lwcJMng);
        GetBrandIndex(lwcJMng);
        UpdateAllPendingPrice();
    end;
    //     // PROCEDURE ManualUpdateAllBrands();
    //     // VAR
    //     //     lwcJMng: Codeunit "JSON Manager";
    //     // BEGIN
    //     //     // UpdateClients
    //     //     IF NOT CONFIRM(Text002, FALSE) THEN
    //     //         EXIT;
    //     //     CLEAR(lwcJMng);
    //     //     GetBrandIndex(lwcJMng);
    //     //     UpdateAllPendingPrice();
    //     // END;
    LOCAL PROCEDURE GetBrandIndex(VAR pwcJMng: Codeunit "JSON Manager") Result: Boolean;
    BEGIN
        // GetBrandIndex
        IF NOT LoadStup THEN EXIT;
        Result := RequestAndLoad(pwcJMng, wURLType::BrandIndex, 0, TRUE);
        //FALTA COMPROBAR CON RESULT
        IF Result THEN CheckAndUpdateBrands(pwcJMng);
        //FALTA COMPROBAR CON RESULT
    END;

    LOCAL PROCEDURE CheckAndUpdateBrands(VAR pwcJMng: Codeunit "JSON Manager");
    VAR
        lrBrnd: Record "Telematel Marcas";
        lrBrnd2: Record "Telematel Marcas";
        TemplrBrndTmp: Record "Telematel Marcas" TEMPORARY;
        lcDlg: Codeunit "Dialog Mng";
        lwTotal: Integer;
        lwRow: Integer;
        lwVal: Text;
        lwOk: Boolean;
        lwEnc: Boolean;
        lwId: Integer;
        lwDeleted: Boolean;
        lwActive: Boolean;
        lwLstDate: DateTime;
        lwInitDate: DateTime;
    BEGIN
        // CheckAndUpdateBrands
        lwInitDate := CURRENTDATETIME;
        CLEAR(TemplrBrndTmp);
        InitCntrls;
        lwTotal := pwcJMng.JACount;
        CLEAR(lrBrnd);
        lcDlg.InitDialog(STRSUBSTNO(Text001Lbl, lwTotal), lwTotal);
        FOR lwRow := 1 TO lwTotal DO BEGIN
            lcDlg.UpDateDialog();
            InitResult();
            GetValInt(pwcJMng, lwRow, 'id', lwId);
            GetValBool(pwcJMng, lwRow, 'deleted', lwDeleted);
            GetValBool(pwcJMng, lwRow, 'active', lwActive);
            GetValDT(pwcJMng, lwRow, 'date', lwLstDate);
            //lwOk := GetResult AND (lwId > 0);
            lwOk := lwId > 0;
            IF lwOk THEN BEGIN
                lwEnc := lrBrnd.GET(lwId);
                IF lwEnc THEN BEGIN
                    lwOk := lrBrnd."Ultima Actualizacion GOCAT" < lwLstDate;
                    // Insertamos en temporal para la comprobacion de registros perdidos
                    TemplrBrndTmp := lrBrnd;
                    TemplrBrndTmp.INSERT;
                END
                ELSE
                    lwOk := (NOT lwDeleted) AND lwActive;
            END;
            IF lwOk THEN BEGIN
                IF NOT lwEnc THEN BEGIN
                    lrBrnd.INIT;
                    lrBrnd.Id := lwId;
                    GetValText(pwcJMng, lwRow, 'brand_name', lrBrnd.NomEntidad, FALSE, MAXSTRLEN(lrBrnd.NomEntidad));
                    lrBrnd.Origen := lrBrnd.Origen::Telematel;
                    lrBrnd.INSERT(TRUE);
                END;
                IF NOT UpdateBrand(lrBrnd) THEN
                    // Por si no se ha podido actualizar
                    IF (NOT lwActive) OR lwDeleted THEN BEGIN
                        GetValCode40(pwcJMng, lwRow, 'brand_name', lrBrnd.Codigo);
                        lrBrnd.VALIDATE(Activa, lwActive);
                        lrBrnd.Eliminada := lwDeleted;
                        lrBrnd."Ultima Actualizacion GOCAT" := lwLstDate;
                        lrBrnd.UltimaActualizacion := CURRENTDATETIME;
                        IF (NOT lwActive) AND (lrBrnd.Importar) THEN lrBrnd.VALIDATE(Importar, FALSE);
                        lrBrnd.MODIFY;
                    END;
            END;
        END;
        lcDlg.CloseDialog();
        // Comprobamos las marcas Eliminadas/Perdidas
        IF wMode = wMode::API THEN BEGIN
            CLEAR(TemplrBrndTmp);
            CLEAR(lrBrnd);
            lrBrnd.SETRANGE(Importar, TRUE);
            lrBrnd.SETRANGE(Eliminada, FALSE);
            lrBrnd.SETRANGE(Origen, lrBrnd.Origen::Telematel);
            lrBrnd.SETFILTER(UltimaActualizacion, '<%1', lwInitDate);
            IF lrBrnd.FINDSET(TRUE) THEN BEGIN
                lwTotal := lrBrnd.COUNT();
                lcDlg.InitDialog(STRSUBSTNO(Text003Lbl), lwTotal);
                REPEAT
                    lcDlg.UpDateDialog();
                    IF NOT TemplrBrndTmp.GET(lrBrnd.Id) THEN BEGIN
                        lrBrnd2 := lrBrnd;
                        lrBrnd2.VALIDATE(Eliminada, TRUE);
                        lrBrnd2.Perdido := TRUE;
                        lrBrnd2.UltimaActualizacion := CURRENTDATETIME;
                        lrBrnd2.MODIFY(TRUE);
                    END;
                UNTIL lrBrnd.NEXT = 0;
                lcDlg.CloseDialog
            END;
        END;
    END;

    PROCEDURE UpdateBrand(VAR prBrnd: Record "Telematel Marcas") Result: Boolean;
    VAR
        lwcJMng2: Codeunit "JSON Manager";
        lwDeleted: Boolean;
        lwActive: Boolean;
        lwLasUpdate: DateTime;
    BEGIN
        // UpdateBrand
        // Informacion de la empresa
        IF NOT LoadStup THEN EXIT;
        Result := RequestAndLoad(lwcJMng2, wURLType::Brand, prBrnd.Id, FALSE);
        //Result := RequestAndLoad2(lwcJMng2, wURLType::Brand, prBrnd.Id, FALSE);
        IF Result THEN BEGIN
            GetValCode20(lwcJMng2, 0, 'name', prBrnd.Codigo);
            GetValInt(lwcJMng2, 0, 'entity_id', prBrnd.IdEntidad);
            GetValText(lwcJMng2, 0, 'entity_name', prBrnd.NomEntidad, FALSE, MAXSTRLEN(prBrnd.NomEntidad));
            GetValDT(lwcJMng2, 0, 'updated_at', lwLasUpdate);
            GetValBool(lwcJMng2, 0, 'active', lwActive);
            GetValBool(lwcJMng2, 0, 'deleted', lwDeleted);
            prBrnd.Origen := prBrnd.Origen::Telematel;
            IF (prBrnd.Activa <> lwActive) OR (prBrnd.Eliminada <> lwDeleted) THEN BEGIN
                prBrnd.VALIDATE(Activa, lwActive);
                prBrnd.Eliminada := lwDeleted;
                IF prBrnd.Activa THEN prBrnd.Perdido := FALSE;
                IF lwDeleted OR (NOT lwActive) THEN prBrnd.VALIDATE(Importar, FALSE);
            END;
            IF prBrnd.Importar THEN CheckAndUpdaProducts(prBrnd);
            prBrnd."Ultima Actualizacion GOCAT" := lwLasUpdate;
            prBrnd.UltimaActualizacion := CURRENTDATETIME;
            prBrnd.MODIFY(TRUE);
            IF prBrnd.Importar THEN COMMIT;
        END;
    END;

    LOCAL PROCEDURE CheckAndUpdaProducts(VAR prBrand: Record "Telematel Marcas") Result: Boolean;
    VAR
        lrArt: Record "Telematel Articulos";
        lrArt2: Record "Telematel Articulos";
        TemplrArtTmp: Record "Telematel Articulos" TEMPORARY;
        lwcJMng: Codeunit "JSON Manager";
        lcDlg: Codeunit "Dialog Mng";
        lwTotal: Integer;
        lwRow: Integer;
        lwLstDate: DateTime;
        lwCode: Code[20];
        lwEnc: Boolean;
        lwDeleted: Boolean;
        lwActive: Boolean;
        lwOk: Boolean;
        LText001Txt: TextConst ESP = 'Importando Productos %1 (%2)';
        lwInitDate: DateTime;
        LText002Txt: TextConst ESP = 'Buscando Productos Eliminados/Perdidos';
    BEGIN
        // CheckAndUpdaProducts
        IF (prBrand.Id = 0) OR (NOT prBrand.Importar) THEN EXIT(FALSE);
        lwInitDate := CURRENTDATETIME;
        CLEAR(TemplrArtTmp);
        CLEAR(lrArt);
        lrArt.SETCURRENTKEY("Id Marca", CodArt);
        lrArt.SETRANGE("Id Marca", prBrand.Id);
        Result := RequestAndLoad(lwcJMng, wURLType::ProductIndex, prBrand.Id, TRUE);
        IF Result THEN BEGIN
            lwTotal := lwcJMng.JACount;
            IF GUIALLOWED THEN IF lwTotal > 1000 THEN IF NOT CONFIRM(Text005Lbl, TRUE, lwTotal) THEN ERROR('');
            lcDlg.InitDialog(STRSUBSTNO(LText001Txt, prBrand.NomEntidad, lwTotal), lwTotal);
            FOR lwRow := 1 TO lwTotal DO BEGIN
                lcDlg.UpDateDialog();
                InitResult;
                GetValCode20(lwcJMng, lwRow, 'id', lwCode);
                GetValBool(lwcJMng, lwRow, 'deleted', lwDeleted);
                GetValBool(lwcJMng, lwRow, 'active', lwActive);
                GetValDT(lwcJMng, lwRow, 'date', lwLstDate);
                // lwOk := GetResult AND (lwCode <> '');
                lwOk := lwCode <> '';
                IF lwOk THEN BEGIN
                    lrArt.SETRANGE(CodArt, lwCode);
                    lwEnc := lrArt.FINDFIRST;
                    IF lwEnc THEN BEGIN
                        lwOk := (lrArt."Ultima Actualizacion GOCAT" < lwLstDate);
                        // Insertamos en temporal para la comprobacion de registros perdidos
                        IF NOT TemplrArtTmp.GET(lrArt.Id) THEN BEGIN
                            TemplrArtTmp := lrArt;
                            TemplrArtTmp.INSERT;
                        END;
                    END
                    ELSE
                        lwOk := lwActive AND (NOT lwDeleted);
                END;
                IF lwOk THEN BEGIN
                    CLEAR(lrArt2);
                    IF lwEnc THEN
                        lrArt2 := lrArt
                    ELSE BEGIN
                        lrArt2.INIT;
                        lrArt2.Id := 0;
                        lrArt2."Id Marca" := prBrand.Id;
                        lrArt2.CodArt := lwCode;
                        lrArt2.INSERT(TRUE);
                    END;
                    lrArt2."Ultima Actualizacion GOCAT" := lwLstDate;
                    UpDateProduct(prBrand, lrArt2);
                END;
            END;
            lcDlg.CloseDialog();
            // Comprobamos las Art¡culos Eliminados/Perdidos
            CLEAR(TemplrArtTmp);
            CLEAR(lrArt);
            CLEAR(lrArt2);
            lrArt.SETCURRENTKEY("Id Marca", CodArt);
            lrArt.SETRANGE("Id Marca", prBrand.Id);
            lrArt.SETRANGE(Activo, TRUE);
            lrArt.SETFILTER(UltimaActualizacion, '<%1', lwInitDate);
            IF lrArt.FINDSET(TRUE) THEN BEGIN
                lwTotal := lrArt.COUNT;
                lcDlg.InitDialog(STRSUBSTNO(LText002Txt), lwTotal);
                REPEAT
                    lcDlg.UpDateDialog();
                    IF NOT TemplrArtTmp.GET(lrArt.Id) THEN BEGIN
                        lrArt2 := lrArt;
                        lrArt2.VALIDATE(Activo, FALSE);
                        lrArt2.Perdido := TRUE;
                        lrArt2.UltimaActualizacion := CURRENTDATETIME;
                        lrArt2.MODIFY(TRUE);
                    END;
                UNTIL lrArt.NEXT = 0;
                lcDlg.CloseDialog;
            END;
        END
    END;

    PROCEDURE UpDateSeveralProducts(VAR prArt: Record "Telematel Articulos");
    VAR
        lrBrand: Record "Telematel Marcas";
        lcDlg: Codeunit "Dialog Mng";
    BEGIN
        // Lanzado desde pagina
        IF NOT LoadStup THEN EXIT;
        InitCntrls;
        IF prArt.FINDSET THEN BEGIN
            lcDlg.InitDialog(Text004Lbl, prArt.COUNT);
            IF lrBrand.GET(prArt."Id Marca") THEN
                REPEAT
                    lcDlg.UpDateDialog();
                    UpDateProduct(lrBrand, prArt);
                UNTIL prArt.NEXT = 0;
            lcDlg.CloseDialog;
        END;
    END;

    LOCAL PROCEDURE UpDateProduct(VAR prBrand: Record "Telematel Marcas"; VAR prArt: Record "Telematel Articulos") Result: Boolean;
    VAR
        lwcJMng: Codeunit "JSON Manager";
        lwCode: Code[20];
        lwDate: DateTime;
        TemplrArtT: Record "Telematel Articulos" TEMPORARY;
        lwRow: Integer;
        lwIgual: Boolean;
        lwAct: Boolean;
        lwDel: Boolean;
        lwUnid: Code[4];
        lwUnidUN20: Code[5];
        lwURL: Text;
    BEGIN
        // UpDateProduct
        IF NOT LoadStup THEN EXIT;
        Result := (prArt.CodArt <> '') AND (prArt.Id > 0);
        IF Result THEN Result := RequestAndLoad(lwcJMng, wURLType::Product, prArt.CodArt, FALSE);
        IF Result THEN BEGIN
            // TODO - Comprobar que los codigos son los correctos en el Doc importado
            // GetValCode20(lwcJMng, lwRow, 'id', lrArtT.CodArt);
            // GetValInt(lwcJMng, lwRow, 'brand_id', lrArtT."Id Marca");
            lwRow := 0;
            GetValBool(lwcJMng, lwRow, 'active', lwAct);
            IF lwAct <> prArt.Activo THEN
                IF lwAct THEN
                    prArt.Activo := TRUE
                ELSE
                    prArt.VALIDATE(Activo, FALSE);
            GetValBool(lwcJMng, lwRow, 'deleted', lwDel);
            IF lwDel <> prArt.Eliminado THEN prArt.VALIDATE(Eliminado, lwDel);
            IF prArt.Activo THEN prArt.Perdido := FALSE;
            GetValText(lwcJMng, lwRow, 'part_code', prArt.Referencia, TRUE, MAXSTRLEN(prArt.Referencia));
            IF prArt.Activo THEN BEGIN
                GetValCode20(lwcJMng, lwRow, 'stock_unit_code', lwUnid);
                GetValCode20(lwcJMng, lwRow, 'stock_unit_code_un20', lwUnidUN20);
                GestUnids(lwUnid, lwUnidUN20);
                IF prArt.CodigoUnidad = '' THEN // No se modifican unidades
                    prArt.CodigoUnidad := lwUnid;
                IF prArt."Unidad UN20" = '' THEN prArt."Unidad UN20" := lwUnidUN20;
                GetValCode40(lwcJMng, lwRow, 'ean', prArt.Ean);
                GetValCode20(lwcJMng, lwRow, 'unique_id', prArt."GOCAT Unique Id");
                IF lwcJMng.SetOArray('basic_information') THEN IF NOT GetValText(lwcJMng, 1, 'description_large', prArt.Descripcion, TRUE, MAXSTRLEN(prArt.Descripcion)) THEN GetValText(lwcJMng, 1, 'description_short', prArt.Descripcion, FALSE, MAXSTRLEN(prArt.Descripcion));
                UpdatePrices(lwcJMng, prArt);
                // JPT 16/07/20 #321633 "Mejoras Modulo Go Catalog" -  Crear el registro de  producto Nav bajo demanda.
                // No se crea el Producto Nav en la importacion sino al momento de solicitarlo
                //prArt."No.Item" := UpdateItem(prArt, prBrand); // Crea el item navision
                IF prArt."No.Item" <> '' THEN // Solo se actulizan las que existan
                    UpdateItem(prArt, prBrand); // Crea el item navision
                // #321633 JPT 03/08/2020 - Inlcusion de im genes de Articulos
                CLEAR(lwURL);
                GetValText(lwcJMng, 0, 'img_high', lwURL, TRUE, MAXSTRLEN(lwURL));
                IF DELCHR(lwURL, '<>') = '' THEN GetValText(lwcJMng, 0, 'img_low', lwURL, TRUE, MAXSTRLEN(lwURL));
                IF DELCHR(lwURL, '<>') = '' THEN GetValText(lwcJMng, 0, 'img_thumb', lwURL, TRUE, MAXSTRLEN(lwURL));
                UpdateArtImage(prArt, lwURL);
                // P gina Web
                CLEAR(lwURL);
                GetValText(lwcJMng, 0, 'url', lwURL, TRUE, MAXSTRLEN(lwURL));
                UpdateArWebPage(prArt, lwURL);
                UpdateProductClassification(lwcJMng, prArt);
            END;
            prArt."Codigo Marca" := prBrand.Codigo;
            prArt.UltimaActualizacion := CURRENTDATETIME;
            prArt.MODIFY(TRUE);
            wCntArt += 1;
            // Commits por producto
            IF wTLMStp."Productos x Commit" > 0 THEN BEGIN
                IF wCntArt >= wTLMStp."Productos x Commit" THEN BEGIN
                    CLEAR(wCntArt);
                    COMMIT;
                    IF wTimeCtrl THEN IF CURRENTDATETIME > wToTime THEN ERROR(Text006Lbl);
                END;
            END
            ELSE BEGIN
                IF wTimeCtrl THEN
                    IF CURRENTDATETIME > wToTime THEN BEGIN
                        COMMIT;
                        ERROR(Text006Lbl);
                    END;
            END;
        END;
    END;

    PROCEDURE HYperlinkProductRequest(VAR prArt: Record "Telematel Articulos") Result: Boolean;
    VAR
        lwUrl: Text;
    BEGIN
        // UpDateProduct
        Result := (prArt.CodArt <> '') AND (prArt.Id > 0);
        lwUrl := GetGOCATURL(wURLType::Product, prArt.CodArt);
        lwUrl := AddURLPar(lwUrl) + '&format=xml';
        HYPERLINK(lwUrl);
    END;

    PROCEDURE UpdatePrices(VAR pwcJMng: Codeunit "JSON Manager"; VAR prArt: Record "Telematel Articulos");
    VAR
        lrTPrice: Record "Telematel Precios Articulo";
        lrCurrTLM: Record "Telematel Currency";
        lwIgual: Boolean;
        lwExists: Boolean;
        lwCurr: Code[10];
        lwText: Text[30];
        lwDT: DateTime;
        lwD: Date;
        lwEnc: Boolean;
        lwRow: Integer;
        lwTotal: Integer;
        lwUnid: Code[4];
        lwUnidUN20: Code[5];
        lwToday: Date;
    BEGIN
        // UpdatePrices
        // Los precios para un articulo se borran todos y se vuelven a crear
        CLEAR(lrTPrice);
        lrTPrice.SETCURRENTKEY(IdArticulo);
        lrTPrice.SETRANGE(IdArticulo, prArt.Id);
        lrTPrice.SETRANGE(Manual, FALSE); // No borramos las lineas manuales
        IF lrTPrice.FIND('-') THEN lrTPrice.DELETEALL;
        IF pwcJMng.SetOArray('public_prices') THEN BEGIN
            lwTotal := pwcJMng.JACount;
            lwToday := TODAY;
            FOR lwRow := 1 TO lwTotal DO BEGIN
                CLEAR(lrTPrice);
                lrTPrice.IdArticulo := prArt.Id;
                lrTPrice.CodArt := prArt.CodArt;
                lrTPrice.IdMarca := prArt."Id Marca";
                GetValDate(pwcJMng, lwRow, 'rate_start_date', lrTPrice."Fecha Inicio");
                GetValCode20(pwcJMng, lwRow, 'price_unit_code', lrTPrice."Unit of Measure Code");
                GetValCode20(pwcJMng, lwRow, 'price_unit_code', lwUnid);
                GetValCode20(pwcJMng, lwRow, 'price_unit_code_un20', lwUnidUN20);
                GestUnids(lwUnid, lwUnidUN20);
                lrTPrice."Codigo Unidad" := lwUnid;
                lrTPrice."Unidad UN20" := lwUnidUN20;
                // Buscamos la correspondencia de unidades
                //lrTPrice."Unit of Measure Code" := GetUNiNav(lwUnid, lwUnidUN20)//-#450540
                //+#450540
                IF GetUNiNav(lwUnid, lwUnidUN20) <> Text007Lbl THEN
                    lrTPrice."Unit of Measure Code" := GetUNiNav(lwUnid, lwUnidUN20)
                ELSE
                    ERROR(Text008Lbl, lrTPrice.CodArt, lrTPrice.IdMarca, lwUnid, lwUnidUN20);
                //-#450540
                // Tenemos que convertir la divisa
                GetValCode20(pwcJMng, lwRow, 'currency', lwCurr);
                IF lwCurr <> '' THEN BEGIN
                    CLEAR(lrCurrTLM);
                    lrCurrTLM.GET(lwCurr);
                    IF NOT lrCurrTLM."Local Currency" THEN BEGIN
                        lrCurrTLM.TESTFIELD("Currency Code");
                        lrTPrice."Currency Code" := lrCurrTLM."Currency Code";
                    END;
                    lrTPrice."Telematel Currency" := lwCurr;
                END;
                GetValDec(pwcJMng, lwRow, 'price_unit_min_sale', lrTPrice."Minimum Quantity");
                GetValDec(pwcJMng, lwRow, 'price', lrTPrice.Precio);
                GetValDate(pwcJMng, lwRow, 'expiration_date', lrTPrice."Fecha Final");
                GetValDec(pwcJMng, lwRow, 'price_unit_quantity', lrTPrice.Quantity);
                GetValDec(pwcJMng, lwRow, 'recycling_tax', lrTPrice.RAEE);
                lrTPrice.Pendiente := lrTPrice."Fecha Inicio" > lwToday;
                lrTPrice.INSERT;
            END;
        END;
    END;

    PROCEDURE InsertCrssRf(prItem: Record "Item"; pwType: Enum "Item Reference Type"; pwCode: Code[40]; pwDescripcion: Text[30]);
    VAR
        //lrCrossR: Record 5717;
        lrCrossR: Record "Item Reference";
        lwEnc: Boolean;
        lwIgual: Boolean;
    BEGIN
        // InsertRefCruz
        CLEAR(lrCrossR);
        lrCrossR."Item No." := prItem."No.";
        lrCrossR."Variant Code" := '';
        lrCrossR."Unit of Measure" := prItem."Base Unit of Measure";
        lrCrossR."Reference Type" := pwType;
        lrCrossR."Reference Type No." := '';
        lrCrossR."Reference No." := pwCode;
        lwEnc := lrCrossR.FIND;
        lwIgual := lrCrossR.Description = pwDescripcion;
        lrCrossR.Description := pwDescripcion;
        IF lwEnc THEN BEGIN
            IF NOT lwIgual THEN lrCrossR.MODIFY
        END
        ELSE
            lrCrossR.INSERT;
    END;

    LOCAL PROCEDURE GestUnids(VAR pwUnid: Code[4]; pwUnidUN20: Code[5]);
    VAR
        lrUndsUN20: Record "Unidades UN20";
        lrUns: Record "Telematel Unidades";
    BEGIN
        IF pwUnid <> '' THEN
            IF pwUnidUN20 <> '' THEN BEGIN
                IF lrUns.GET(pwUnid) AND lrUndsUN20.GET(pwUnidUN20) THEN BEGIN
                    IF (lrUndsUN20."Nav Code" = '') OR (lrUndsUN20."Telematel Code" = '') THEN BEGIN
                        IF lrUndsUN20."Nav Code" = '' THEN lrUndsUN20."Nav Code" := lrUns."Codigo Nav";
                        ;
                        IF lrUndsUN20."Telematel Code" = '' THEN lrUndsUN20."Telematel Code" := pwUnid;
                        lrUndsUN20.MODIFY;
                    END;
                END;
            END
            ELSE BEGIN
                IF lrUndsUN20.GET(pwUnidUN20) THEN pwUnid := lrUndsUN20."Telematel Code";
            END;
    END;

    LOCAL PROCEDURE GetUNiNav(pwUnid: Code[4]; pwUnidUN20: Code[5]) Result: Code[20];
    VAR
        lrUnds: Record "Telematel Unidades";
        lrUndsUN20: Record "Unidades UN20";
    BEGIN
        Result := '';
        // Buscamos la correspondencia de unidades
        CLEAR(lrUnds);
        IF lrUnds.GET(pwUnid) THEN BEGIN
            lrUnds.TESTFIELD("Codigo Nav");
            Result := lrUnds."Codigo Nav";
        END
        ELSE BEGIN
            CLEAR(lrUndsUN20);
            //+#450540
            // {
            // lrUndsUN20.GET(pwUnidUN20);//Provoca error si la unidad no existe en la tabla Unidades UN20
            // lrUndsUN20.TESTFIELD("Nav Code");
            // Result := lrUndsUN20."Nav Code";
            // }
            IF lrUndsUN20.GET(pwUnidUN20) THEN BEGIN
                lrUndsUN20.TESTFIELD("Nav Code");
                Result := lrUndsUN20."Nav Code";
            END
            ELSE
                Result := Text007Lbl;
            //+#450540
        END;
    END;

    PROCEDURE UpdateItem(VAR prArt: Record "Telematel Articulos"; prBrand: Record "Telematel Marcas") Result: Code[20];
    VAR
        lrItem: Record 27;
        Item: Record 27;
        // lrCrossR: Record 5717;
        lrConv: Record "GOCAT Arts. Conversion";
        lwPrecTLM: Record "Telematel Precios Articulo";
        lrClaArt: Record "Clasificacion Articulos";
        lwOk: Boolean;
        LT0001Txt: TextConst ESP = 'No Producto Telematel', ESM = 'No Producto Telematel';
        LT0002Txt: TextConst ESP = 'No Referencia Fabricante', ESM = 'No Referencia Fabricante';
        lwOk2: Boolean;
        lwEnc: Boolean;
        lwIgual: Boolean;
        lwPrecio: Decimal;
        LT0003Txt: TextConst ESP = 'EAN';
        lwUnidNav: Code[20];
        lwModify: Boolean;
    BEGIN
        // UpdateItem
        IF NOT LoadStup THEN EXIT;
        lwEnc := FALSE;
        lwModify := FALSE;
        CLEAR(lrItem);
        lwOk := prArt."No.Item" = '';
        IF NOT lwOk THEN BEGIN
            lwEnc := lrItem.GET(prArt."No.Item");
            lwOk := NOT lwEnc;
        END;
        IF lwOk THEN BEGIN
            IF NOT lwEnc THEN BEGIN
                lrItem.INIT;
                lrItem."No." := NoSeries.GetNextNo(wTLMStp."Items Serie", 0D);
                Item.ReadIsolation(IsolationLevel::ReadUncommitted);
                Item.SetLoadFields(Item."No.");
                while Item.get(lrItem."No.") do
                    lrItem."No." := NoSeries.GetNextNo(wTLMStp."Items Serie", 0D);
            END;
            lrItem.Description := prArt.Descripcion;
            lrItem."No. 2" := prArt.CodArt;
            lrItem."Search Description" := prArt.Referencia;
            IF NOT lwEnc THEN BEGIN
                //lrItem."Cod. Prod.  fabricante"
                lrItem.VALIDATE("Inventory Posting Group", wTLMStp."Inventory Posting");
                lrItem.VALIDATE("Gen. Prod. Posting Group", wTLMStp."Gen. Prod. Posting");
            END;
            lrItem."Last Date Modified" := TODAY;
            lrItem.Capitulo := prArt.Capitulo;
            IF lwEnc THEN
                lwModify := TRUE
            ELSE
                lrItem.INSERT(TRUE);
            prArt.VALIDATE("No.Item", lrItem."No.");
            // prArt.MODIFY;
        END;
        // Buscamos la correspondencia de unidades
        //lwUnidNav := GetUNiNav(prArt.CodigoUnidad, prArt."Unidad UN20");//-#450540
        //+#450540
        IF GetUNiNav(prArt.CodigoUnidad, prArt."Unidad UN20") <> Text007Lbl THEN
            lwUnidNav := GetUNiNav(prArt.CodigoUnidad, prArt."Unidad UN20")
        ELSE
            ERROR(Text008Lbl, prArt.CodArt, prArt."Id Marca", prArt.CodigoUnidad, prArt."Unidad UN20");
        //-#450540
        // Comprobamos si puede cambiarse la unidad de medida base
        IF lwUnidNav <> lrItem."Base Unit of Measure" THEN BEGIN
            lwOk2 := lrItem."Base Unit of Measure" = '';
            IF NOT lwOk2 THEN lwOk2 := CanChangeBaseUnit(lrItem."No.", lwUnidNav);
            IF lwOk2 THEN BEGIN
                lrItem.VALIDATE("Base Unit of Measure", lwUnidNav);
                lwModify := TRUE;
            END;
            // Creamos unidades medidad producto
            AddItemUnit(lrItem."No.", lwUnidNav, 1);
        END;
        // Referencias cruzadas
        // 2= Vendor, 3= Ean
        InsertCrssRf(lrItem, "Item Reference Type".FromInteger(2), prArt.CodArt, LT0001Txt);
        InsertCrssRf(lrItem, "Item Reference Type".FromInteger(2), prArt.Referencia, LT0002Txt); // Referencia Frabricante
        IF prArt.Ean <> '' THEN // ean
            InsertCrssRf(lrItem, "Item Reference Type".FromInteger(3), prArt.Ean, LT0003Txt);
        // Buscamos el precio actual del articulo
        lwPrecio := GetPrecio(prArt, TODAY);
        // Comparamos los datos telematel y actualizamos si han cambiado
        lwIgual := (lrItem."Id Marca TLM" = prArt."Id Marca") AND (lrItem."Marca TLM" = prBrand.Codigo) AND (lrItem."Id Articulo TLM" = prArt.Id) AND (lrItem."Referencia TLM" = prArt.Referencia) AND (lrItem.Description = prArt.Descripcion) AND (lrItem."Unit List Price" = lwPrecio); // Precio referencia = PVP
        IF NOT lwIgual THEN BEGIN
            lrItem."Id Marca TLM" := prArt."Id Marca";
            lrItem.Description := prArt.Descripcion;
            lrItem."Marca TLM" := prBrand.Codigo;
            lrItem."Id Articulo TLM" := prArt.Id;
            lrItem."Referencia TLM" := prArt.Referencia;
            lrItem."Unit List Price" := lwPrecio; // Precio referencia = PVP
            lrItem."Last Direct Cost" := lwPrecio;
            lwModify := TRUE;
        END;
        IF lwModify THEN lrItem.MODIFY(TRUE);
        // RAEE
        CLEAR(lwPrecTLM);
        lwPrecTLM.SETCURRENTKEY(IdArticulo, "Fecha Inicio", "Fecha Final");
        lwPrecTLM.SETRANGE(IdArticulo, prArt.Id);
        IF lwPrecTLM.FINDSET THEN
            REPEAT
                GestRaee(prArt."No.Item", lwPrecTLM.RAEE, lwPrecTLM."Fecha Inicio", lwPrecTLM."Fecha Final");
            UNTIL lwPrecTLM.NEXT = 0;
        IF (NOT lwEnc) AND (prArt.Id <> 0) THEN BEGIN
            CLEAR(lrClaArt);
            lrClaArt.SETRANGE("Id Articulo", prArt.Id);
            IF NOT lrClaArt.ISEMPTY THEN lrClaArt.MODIFYALL("Cod Item", prArt."No.Item");
        END;
        Result := prArt."No.Item";
        // Conversiones (Unidades x Producto)
        CLEAR(lrConv);
        lrConv.SETCURRENTKEY("Art Id");
        lrConv.SETRANGE("Art Id", prArt.Id);
        IF lrConv.FINDSET THEN BEGIN
            REPEAT
                IF lrConv.Valor <> 0 THEN AddItemUnit(lrItem."No.", lrConv."Unit of Measure Code", 1 / lrConv.Valor);
            UNTIL lrConv.NEXT = 0;
        END;
    END;

    PROCEDURE UpdateItemPrice(VAR prItem: Record Item) Result: Boolean;
    VAR
        lrArt: Record "Telematel Articulos";
        lwPrecio: Decimal;
    BEGIN
        Result := FALSE;
        IF prItem."Id Articulo TLM" <> 0 THEN
            IF lrArt.GET(prItem."Id Articulo TLM") THEN BEGIN
                // Buscamos el precio actual del articulo
                lwPrecio := GetPrecio(lrArt, TODAY);
                Result := prItem."Unit List Price" <> lwPrecio;
                IF Result THEN BEGIN
                    prItem."Unit List Price" := lwPrecio;
                    // prItem.MODIFY(TRUE);
                END;
            END;
    END;

    PROCEDURE UpdateAllPendingPrice();
    VAR
        lrPrec: Record "Telematel Precios Articulo";
        lrItem: Record Item;
        lcDlg: Codeunit "Dialog Mng";
        lText0001Txt: TextConst ESP = 'Actualizando Precios';
        lwLastId: Integer;
    BEGIN
        CLEAR(lrItem);
        CLEAR(lrPrec);
        lrPrec.SETCURRENTKEY(Pendiente, "Fecha Inicio");
        lrPrec.SETRANGE(Pendiente, TRUE);
        lrPrec.SETFILTER("Fecha Inicio", '<=%1', TODAY);
        lrPrec.SETAUTOCALCFIELDS("No.Item");
        IF lrPrec.FINDSET THEN BEGIN
            lcDlg.InitDialog(lText0001Txt, lrPrec.COUNT);
            CLEAR(lwLastId);
            REPEAT
                lcDlg.UpDateDialog();
                IF lwLastId <> lrPrec.IdArticulo THEN IF lrItem.GET(lrPrec."No.Item") THEN IF UpdateItemPrice(lrItem) THEN lrItem.MODIFY(TRUE);
                lwLastId := lrPrec.IdArticulo;
            UNTIL lrPrec.NEXT = 0;
            lcDlg.CloseDialog();
            lrPrec.MODIFYALL(Pendiente, FALSE);
        END;
    END;

    LOCAL PROCEDURE AddItemUnit(pwItemNo: Code[20]; pwUnit: Code[10]; pwQtyBUn: Decimal);
    VAR
        lrUnItm: Record 5404;
    BEGIN
        IF NOT lrUnItm.GET(pwItemNo, pwUnit) THEN BEGIN
            lrUnItm.INIT;
            lrUnItm."Item No." := pwItemNo;
            lrUnItm.Code := pwUnit;
            lrUnItm."Qty. per Unit of Measure" := pwQtyBUn;
            lrUnItm.INSERT(TRUE);
        END;
    END;

    LOCAL PROCEDURE CanChangeBaseUnit(pwItemNo: Code[20]; pwUnit: Code[10]) Result: Boolean;
    VAR
        ItemLedgEntry: Record 32;
        lrUnItm: Record 5404;
    BEGIN
        // Devuelve true cuando No tiene Mov producto pendiente
        ItemLedgEntry.SETCURRENTKEY("Item No.", Open);
        ItemLedgEntry.SETRANGE("Item No.", pwItemNo);
        //ItemLedgEntry.SETRANGE(Open,TRUE);
        Result := ItemLedgEntry.ISEMPTY;
        IF Result THEN BEGIN
            CLEAR(lrUnItm);
            IF lrUnItm.GET(pwItemNo, pwUnit) THEN Result := lrUnItm."Qty. per Unit of Measure" = 1;
        END;
    END;

    PROCEDURE GestRaee(pwCodProd: Code[20]; pwRAEE: Decimal; pwFechaDesde: Date; pwFechaHasta: Date);
    VAR
        lrLinTasa: Record "Importe Tasa Producto";
        lrRelTAsa: Record "Relacion Tasa Producto";
        lrRelTAsa2: Record "Relacion Tasa Producto";
        lwEnc: Boolean;
        lwIsNull: Boolean;
        lwDif: Boolean;
    BEGIN
        // GestRaee
        lwIsNull := pwRAEE = 0;
        lwEnc := FALSE;
        IF (pwCodProd = '') THEN EXIT;
        IF wTLMStp."Codigo RAEE" = '' THEN EXIT;
        IF NOT lwIsNull THEN BEGIN
            CLEAR(lrLinTasa);
            lrLinTasa.SETRANGE("Codigo Tasa/Prod", wTLMStp."Codigo RAEE");
            lrLinTasa.SETRANGE(Importe, pwRAEE);
            IF NOT lrLinTasa.FIND('-') THEN BEGIN
                // Si no existe el tipo lo creamos
                lrLinTasa.INIT;
                lrLinTasa.VALIDATE("Codigo Tasa/Prod", wTLMStp."Codigo RAEE");
                lrLinTasa.VALIDATE(Importe, pwRAEE);
                lrLinTasa.INSERT(TRUE);
            END;
        END;
        CLEAR(lrRelTAsa);
        lrRelTAsa.SETCURRENTKEY(Item, "Codigo Tasa/Prod", "Id Lin Precio");
        lrRelTAsa.ASCENDING(FALSE);
        lrRelTAsa.SETRANGE(Item, pwCodProd);
        lrRelTAsa.SETRANGE("Codigo Tasa/Prod", lrLinTasa."Codigo Tasa/Prod");
        //IF NOT lwIsNull THEN
        //  lrRelTAsa.SETRANGE("Id Lin Precio"   , lrLinTasa.Id);
        IF pwFechaHasta <> 0D THEN lrRelTAsa.SETFILTER("Fecha Desde", '<=%1', pwFechaHasta);
        lrRelTAsa.SETFILTER("Fecha Hasta", '>=%1|%2', pwFechaDesde, 0D);
        lwEnc := lrRelTAsa.FIND('-');
        IF (NOT lwEnc) THEN BEGIN
            IF NOT lwIsNull THEN BEGIN
                lrRelTAsa.INIT;
                lrRelTAsa.Item := pwCodProd;
                lrRelTAsa."Codigo Tasa/Prod" := lrLinTasa."Codigo Tasa/Prod";
                lrRelTAsa."Fecha Desde" := pwFechaDesde;
                lrRelTAsa."Fecha Hasta" := pwFechaHasta;
            END;
        END
        ELSE BEGIN
            IF lwIsNull THEN lrRelTAsa.DELETE;
        END;
        // ** Borramos lineas que pueda tener de otro tipo
        CLEAR(lrRelTAsa2);
        lrRelTAsa2.SETCURRENTKEY(Item, "Codigo Tasa/Prod", "Id Lin Precio");
        lrRelTAsa2.SETRANGE(Item, pwCodProd);
        lrRelTAsa2.SETRANGE("Codigo Tasa/Prod", lrLinTasa."Codigo Tasa/Prod");
        IF (NOT lwIsNull) THEN lrRelTAsa2.SETFILTER("Id Lin Precio", '<>%1', lrLinTasa.Id);
        IF pwFechaHasta <> 0D THEN lrRelTAsa2.SETFILTER("Fecha Desde", '<=%1', pwFechaHasta);
        IF lwEnc THEN lrRelTAsa2.SETFILTER(Id, '<>%1', lrRelTAsa.Id);
        lrRelTAsa2.SETFILTER("Fecha Hasta", '>=%1|%2', pwFechaDesde, 0D);
        lrRelTAsa2.DELETEALL;
        IF lwEnc THEN BEGIN
            // Por si acaso hubiese alguna linea m s del mismo tipo
            lrRelTAsa2.SETFILTER(Id, '<>%1', lrRelTAsa.Id);
            lrRelTAsa2.SETRANGE("Id Lin Precio", lrLinTasa.Id);
            lrRelTAsa2.DELETEALL;
        END;
        // **
        IF NOT lwIsNull THEN BEGIN
            lwDif := (lrRelTAsa."Id Lin Precio" <> lrLinTasa.Id) OR (lrRelTAsa."Fecha Desde" <> pwFechaDesde) OR (lrRelTAsa."Fecha Hasta" <> pwFechaHasta);
            IF lwDif THEN BEGIN
                lrRelTAsa."Id Lin Precio" := lrLinTasa.Id;
                lrRelTAsa."Fecha Desde" := pwFechaDesde;
                lrRelTAsa."Fecha Hasta" := pwFechaHasta;
                IF lwEnc THEN
                    lrRelTAsa.MODIFY
                ELSE
                    lrRelTAsa.INSERT;
            END;
        END;
    END;

    PROCEDURE UpdateProductClassification(VAR pwcJMng: Codeunit "JSON Manager"; VAR prArt: Record "Telematel Articulos");
    VAR
        lrClaArt: Record "Clasificacion Articulos";
        TemplrClaArt: Record "Clasificacion Articulos" TEMPORARY;
        lrClas: Record "Clasificaciones";
        lrTipoC: Record "Tipos Clasificacion";
        lwExists: Boolean;
        lwIgual: Boolean;
        lwTotal: Integer;
        lwNivel: Integer;
        lwVal: Integer;
        lwParentId: Integer;
        lwRow: Integer;
        lwIdClasT: Integer;
        lwOk: Boolean;
        lwClassTp: Text[60];
        lwClassName: Text[60];
    BEGIN
        // UpdateProductClassification
        // Clasificaciones por articulos
        IF pwcJMng.SetOArray('classifications') THEN BEGIN
            lwTotal := pwcJMng.JACount;
            FOR lwRow := 1 TO lwTotal DO BEGIN
                CLEAR(TemplrClaArt);
                TemplrClaArt."Id Articulo" := prArt.Id;
                TemplrClaArt."Cod Item" := prArt."No.Item";
                GetValText(pwcJMng, lwRow, 'type', lwClassTp, FALSE, MAXSTRLEN(lwClassTp));
                lwIdClasT := GetClassificacionTypeId(lwClassTp);
                lrTipoC.GET(lwIdClasT);
                TemplrClaArt."Codigo Clasificacion" := lwIdClasT;
                lwParentId := 0;
                lwOk := TRUE;
                FOR lwNivel := 1 TO 3 DO BEGIN
                    IF lwOk THEN BEGIN
                        GetValInt(pwcJMng, lwRow, STRSUBSTNO('level%1_id', lwNivel), lwVal);
                        GetValText(pwcJMng, lwRow, STRSUBSTNO('level%1_name', lwNivel), lwClassName, FALSE, MAXSTRLEN(lwClassName));
                        lwClassName := DELCHR(lwClassName, '<>');
                        CLEAR(lrClas);
                        lrClas.SETRANGE("Tipo Clasificacion", lwIdClasT);
                        lrClas.SETRANGE(Nivel, lwNivel);
                        IF lrTipoC.SubType = lrTipoC.SubType::brand THEN BEGIN
                            lrClas.SETRANGE(Descripcion, lwClassName);
                            lrClas.SETRANGE("Id Marca", prArt."Id Marca");
                        END
                        ELSE
                            lrClas.SETRANGE("Id Telematel", lwVal);
                        lrClas.SETRANGE("Id Subordinado", lwParentId);
                        lwOk := lrClas.FINDFIRST;
                        IF NOT lwOk AND (lrTipoC.SubType <> lrTipoC.SubType::telematel) AND (lwClassName <> '') THEN BEGIN
                            CLEAR(lrClas);
                            lrClas."Tipo Clasificacion" := lwIdClasT;
                            IF lrTipoC.SubType = lrTipoC.SubType::brand THEN lrClas."Id Marca" := prArt."Id Marca";
                            lrClas."Id Telematel" := lwVal;
                            lrClas.Nivel := lwNivel;
                            lrClas.Descripcion := lwClassName;
                            lrClas."Id Subordinado" := lwParentId;
                            lrClas.INSERT;
                            lwOk := TRUE;
                        END;
                        IF lwOk THEN BEGIN
                            TemplrClaArt.AsignaLevelId(lwNivel, lrClas.Id);
                            lwParentId := lrClas.Id;
                        END;
                    END;
                END;
                lwExists := lrClaArt.GET(TemplrClaArt."Id Articulo", lwIdClasT);
                IF NOT lwExists THEN BEGIN
                    CLEAR(lrClaArt);
                    lrClaArt.COPY(TemplrClaArt);
                END
                ELSE BEGIN
                    lwIgual := (lrClaArt."Cod Item" = TemplrClaArt."Cod Item");
                    FOR lwNivel := 1 TO 3 DO lwIgual := lwIgual AND (lrClaArt.GetLevelId(lwNivel) = TemplrClaArt.GetLevelId(lwNivel));
                    lrClaArt."Cod Item" := TemplrClaArt."Cod Item";
                    FOR lwNivel := 1 TO 3 DO BEGIN
                        lrClaArt.ValidateLevelId(lwNivel, TemplrClaArt.GetLevelId(lwNivel));
                    END;
                END;
                IF lwExists THEN BEGIN
                    IF NOT lwIgual THEN lrClaArt.MODIFY
                END
                ELSE
                    lrClaArt.INSERT;
            END;
        END;
    END;
    //     //     LOCAL PROCEDURE UpdateConversions(VAR pwcJMng: Codeunit "JSON Manager"; VAR prArt: Record "Telematel Articulos");
    //     //     VAR
    //     //         lwTotal: Integer;
    //     //         lwRow: Integer;
    //     //         lrConv: Record "GOCAT Arts. Conversion";
    //     //         lwUnid: Code[4];
    //     //         lwUnidUN20: Code[5];
    //     //     BEGIN
    //     //         IF prArt.Id = 0 THEN
    //     //             EXIT;
    //     //         CLEAR(lrConv);
    //     //         lrConv.SETCURRENTKEY("Art Id");
    //     //         lrConv.SETRANGE("Art Id", prArt.Id);
    //     //         IF pwcJMng.SetOArray('stock_conversion') THEN BEGIN
    //     //             lwTotal := pwcJMng.JACount;
    //     //             FOR lwRow := 1 TO lwTotal DO BEGIN
    //     //                 CLEAR(lrConv);
    //     //                 GetValCode20(pwcJMng, lwRow, 'stock_unit_code', lwUnid);
    //     //                 GetValCode20(pwcJMng, lwRow, 'stock_unit_code_un20', lwUnidUN20);
    //     //                 GestUnids(lwUnid, lwUnidUN20);
    //     //                 lrConv."Art Id" := prArt.Id;
    //     //                 lrConv."Codigo Unidad" := lwUnid;
    //     //                 lrConv."Unidad UN20" := lwUnidUN20;
    //     //                 // Buscamos la correspondencia de unidades
    //     //                 //lrConv."Unit of Measure Code" := GetUNiNav(lwUnid, lwUnidUN20);//-#450540
    //     //                 //+#450540
    //     //                 IF GetUNiNav(lwUnid, lwUnidUN20) <> Text007 THEN
    //     //                     lrConv."Unit of Measure Code" := GetUNiNav(lwUnid, lwUnidUN20)
    //     //                 ELSE
    //     //                     ERROR(Text008, prArt.CodArt, prArt."Id Marca", lwUnid, lwUnidUN20);
    //     //                 //-#450540
    //     //                 GetValDec(pwcJMng, lwRow, 'conversion_value', lrConv.Valor);
    //     //                 lrConv.INSERT;
    //     //             END;
    //     //         END;
    //     //     END;
    LOCAL PROCEDURE GetClassificacionTypeId(pwClsTypeName: Text[60]) Result: Integer;
    VAR
        lrTipoC: Record "Tipos Clasificacion";
    BEGIN
        Result := 0;
        pwClsTypeName := DELCHR(pwClsTypeName, '<>');
        IF pwClsTypeName = '' THEN EXIT;
        // Greate a New One if not exists
        CLEAR(lrTipoC);
        lrTipoC.SETRANGE("Tipo Go Catalog", pwClsTypeName);
        IF NOT lrTipoC.FINDFIRST THEN BEGIN
            CLEAR(lrTipoC);
            lrTipoC.Id := lrTipoC.GetLastId + 1;
            lrTipoC."Tipo Go Catalog" := pwClsTypeName;
            lrTipoC.Nombre := pwClsTypeName;
            IF NOT EVALUATE(lrTipoC.SubType, pwClsTypeName) THEN lrTipoC.SubType := lrTipoC.SubType::None;
            lrTipoC.INSERT(TRUE)
        END;
        Result := lrTipoC.Id;
    END;

    PROCEDURE UpdateClassificacions() Result: Boolean;
    VAR
        lwcJMng: Codeunit "JSON Manager";
        lrClass: Record "Clasificaciones";
        TemplrClass: Record "Clasificaciones" TEMPORARY;
        lcDlg: Codeunit "Dialog Mng";
        lwTotal: Integer;
        lwCnt: Integer;
        lwRow: Integer;
        lwNivel: Integer;
        lwIdClasT: Integer;
        lwId: Integer;
        lwParentId: Integer;
        lwIdLevelAnt: Integer;
        lwExists: Boolean;
        lwAct: Boolean;
        lwCambiaDesc: Boolean;
        lwIgual: Boolean;
        lText001Txt: TextConst ESP = 'Clasificaciones Nivel %1';
    BEGIN
        Result := RequestAndLoad(lwcJMng, wURLType::Categories, 0, FALSE);
        IF Result THEN BEGIN
            lwIdClasT := GetClassificacionTypeId('telematel');
            FOR lwNivel := 1 TO 3 DO BEGIN
                IF lwcJMng.SetOArray(STRSUBSTNO('levels_%1', lwNivel)) THEN BEGIN
                    lwTotal := lwcJMng.JACount;
                    lcDlg.InitDialog(STRSUBSTNO(lText001Txt, lwNivel), lwTotal);
                    FOR lwRow := 1 TO lwTotal DO BEGIN
                        lcDlg.UpDateDialog();
                        CLEAR(lwParentId);
                        CLEAR(lwIdLevelAnt);
                        CLEAR(TemplrClass);
                        GetValInt(lwcJMng, lwRow, 'id', TemplrClass."Id Telematel");
                        GetValInt(lwcJMng, lwRow, 'order', TemplrClass.Orden);
                        GetValText(lwcJMng, lwRow, 'name', TemplrClass.Descripcion, FALSE, MAXSTRLEN(TemplrClass.Descripcion));
                        GetValBool(lwcJMng, lwRow, 'active', lwAct);
                        IF (lwNivel > 1) AND lwAct THEN BEGIN
                            GetValInt(lwcJMng, lwRow, STRSUBSTNO('level_%1_id', lwNivel - 1), lwIdLevelAnt);
                            // Buscamos el Id del anterior
                            CLEAR(lrClass);
                            lrClass.SETCURRENTKEY(Nivel, "Id Subordinado", "Id Telematel");
                            lrClass.SETRANGE("Tipo Clasificacion", lwIdClasT);
                            lrClass.SETRANGE(Nivel, lwNivel - 1);
                            lrClass.SETRANGE("Id Telematel", lwIdLevelAnt);
                            IF lrClass.FINDFIRST THEN lwParentId := lrClass.Id;
                        END;
                        CLEAR(lrClass);
                        lrClass.SETCURRENTKEY(Nivel, "Id Subordinado", "Id Telematel");
                        lrClass.SETRANGE("Tipo Clasificacion", lwIdClasT);
                        lrClass.SETRANGE(Nivel, lwNivel);
                        lrClass.SETRANGE("Id Telematel", TemplrClass."Id Telematel");
                        IF lwParentId > 0 THEN lrClass.SETRANGE("Id Subordinado", lwParentId);
                        lwExists := lrClass.FINDFIRST;
                        IF (NOT lwAct) THEN BEGIN // No est  activo
                            IF lwExists THEN lrClass.DELETE(TRUE);
                        END
                        ELSE BEGIN
                            lwCambiaDesc := FALSE;
                            IF NOT lwExists THEN BEGIN
                                CLEAR(lrClass);
                                lrClass."Tipo Clasificacion" := lwIdClasT;
                                lrClass.Nivel := lwNivel;
                                lrClass."Id Telematel" := TemplrClass."Id Telematel";
                                lrClass."Id Subordinado" := lwParentId;
                            END
                            ELSE BEGIN
                                lwCambiaDesc := lrClass.Descripcion <> TemplrClass.Descripcion;
                                lwIgual := (lrClass.Orden = TemplrClass.Orden) AND (NOT lwCambiaDesc);
                            END;
                            lrClass.Orden := TemplrClass.Orden;
                            lrClass.Descripcion := TemplrClass.Descripcion;
                            IF lwExists THEN BEGIN
                                IF NOT lwIgual THEN BEGIN
                                    // IF lwCambiaDesc THEN lrClass.CambiaDescripcion;
                                    lrClass.MODIFY
                                END;
                            END
                            ELSE
                                lrClass.INSERT;
                        END;
                    END;
                    lcDlg.CloseDialog();
                END;
            END;
        END;
    END;

    LOCAL PROCEDURE GetGOCATURL(pwType: Integer; pwValue: Variant) Result: Text;
    BEGIN
        CASE pwType OF
            wURLType::BrandIndex:
                Result := 'https://api.telematel.com/updates?by=brand'; //  Brand Index
            wURLType::Brand:
                Result := STRSUBSTNO('https://api.telematel.com/brands?&id=%1', pwValue); // Brand
            wURLType::ProductIndex:
                Result := STRSUBSTNO('https://api.telematel.com/products?brand_id=%1', pwValue); // Brand Products Index
            wURLType::Product:
                Result := STRSUBSTNO('https://api.telematel.com/products?id=%1', pwValue); // Product
            wURLType::Categories:
                Result := 'https://api.telematel.com/files?id=categories';
        END;
    END;

    LOCAL PROCEDURE RequestAndLoad(VAR pwcJMng: Codeunit "JSON Manager"; pwType: Integer; pwValue: Variant; pwComp: Boolean) Result: Boolean;
    VAR
        lwUrl: Text;
        lwResponse: Text;
        lwResponseOutStream: OutStream;
        lwResponseInStream: InStream;
        TempBlob: Codeunit "Temp Blob";
        lText0009Txt: TextConst ESP = 'GoCatalog: la respuesta recibida está vacía o no es un JSON válido (URL: %1).';
    BEGIN
        // FIX: el InStream se creaba antes de escribir nada en el OutStream, por lo que
        // siempre se leía un blob vacío. Ahora se crea DESPUÉS de rellenar el OutStream.
        TempBlob.CreateOutStream(lwResponseOutStream);
        CLEAR(pwcJMng);
        CASE wMode OF
            wMode::API:
                BEGIN
                    lwUrl := GetGOCATURL(pwType, pwValue);
                    lwUrl := AddURLParF(lwUrl);
                    IF pwComp THEN // Comprimido
                        Result := GetCompResponse(lwResponseOutStream, lwUrl)
                    ELSE
                        //Result := GetResponse(lwResponseOutStream, lwUrl);
                        Result := GetCompResponse(lwResponseOutStream, lwUrl)
                END;
            wMode::File:
                Error('Not Implemented');
        //Result := GetFileContent(pwType, pwValue, lwResponse);
        END;
        IF Result THEN BEGIN //pwcJMng.SetJSON(lwResponse);
            TempBlob.CreateInStream(lwResponseInStream);
            Result := pwcJMng.SetJSONStream(lwResponseInStream);
            IF NOT Result THEN
                ERROR(lText0009Txt, lwUrl);
        END;
    END;
    // LOCAL PROCEDURE GetResponse(VAR pwResponse: OutStream; pwUrl: Text) Result: Boolean;
    // BEGIN
    //     Result := HttpClientCall(pwResponse, pwUrl, 'GET');
    // END;
    //LOCAL PROCEDURE GetCompResponse(VAR pwResponse: Text; pwUrl: Text) Result: Boolean;
    LOCAL PROCEDURE GetCompResponse(VAR pwResponse: OutStream; pwUrl: Text) Result: Boolean;
    BEGIN
        // Compress File
        Result := HttpGetClientStrm(pwResponse, pwUrl);
        /*IF Result THEN
                Result := pwResponse <> '';*/
    END;
    // LOCAL PROCEDURE HttpClientCall(VAR pwContentResponse: OutStream; pwUrl: Text; pwMethod: Text[5]) Result: Boolean;
    // VAR
    //     // HttpResponseMessage: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.HttpResponseMessage";
    //     // HttpRequestMessage: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.HttpRequestMessage";
    //     // HttpClient: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.HttpClient";
    //     // HttpContent: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.HttpContent";
    //     // HttpMethod: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.HttpMethod";
    //     // HttpHeadersMediaType: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.Headers.MediaTypeHeaderValue";
    //     // StringContent: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.StringContent";
    //     // Encoding: DotNet "'mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'.System.Text.Encoding";
    //     ContentType: Text;
    //     Status: Integer;
    //     lwErrText: Text;
    //     HttpClient: HttpClient;
    //     HttpRequestMessage: HttpRequestMessage;
    //     HttpContent: HttpContent;
    //     HttpResponseMessage: HttpResponseMessage;
    //     TempBlob: Codeunit "Temp Blob";
    //     lwInStrm: InStream;
    //     Response: Text;
    //     tofile: text;
    // BEGIN
    //     IF NOT LoadStup THEN
    //         EXIT;
    //     //HttpClient := HttpClient.HttpClient();        
    //     IF wTLMStp.TimeOut > 0 THEN
    //         HttpClient.Timeout := wTLMStp.TimeOut;
    //     // El valor predeterminado es 100.000 milisegundos (100 segundos).
    //     //HttpRequestMessage := HttpRequestMessage.HttpRequestMessage;
    //     //*** HttpResponseMessage := HttpResponseMessage.HttpResponseMessage;
    //     IF pwMethod IN ['POST', 'PUT'] THEN BEGIN
    //         Error('NOT IMPLEMENTED');
    //         /*ContentType := 'application/json';
    //         HttpContent := StringContent.StringContent(pwContentResponse, Encoding.UTF8, ContentType);*/
    //         //StringContent := StringContent.StringContent(pwContentResponse,Encoding.UTF8);
    //         //StringContent.Headers.ContentType := HttpHeadersMediaType.Parse(ContentType);
    //         //HttpRequestMessage.Content := StringContent;
    //     END;
    //     // Get response
    //     CASE pwMethod OF
    //         'GET':
    //             //HttpResponseMessage := HttpClient.GetAsync(pwUrl).Result;
    //             Result := HttpClient.Get(pwUrl, HttpResponseMessage);
    //         'POST':
    //             //HttpResponseMessage := HttpClient.PostAsync(pwUrl, HttpContent).Result;
    //             Result := HttpClient.Post(pwUrl, HttpContent, HttpResponseMessage);
    //         'PUT':
    //             //HttpResponseMessage := HttpClient.PutAsync(pwUrl, HttpContent).Result;
    //             Result := HttpClient.Put(pwUrl, HttpContent, HttpResponseMessage);
    //         'DELETE':
    //             //HttpResponseMessage := HttpClient.DeleteAsync(pwUrl).Result;
    //             Result := HttpClient.Delete(pwUrl, HttpResponseMessage);
    //     END;
    //     Status := HttpResponseMessage.HttpStatusCode;
    //     //pwContentResponse := HttpResponseMessage.Content.ReadAsStringAsync().Result;
    //     HttpResponseMessage.Content.ReadAs(Response);
    //     TempBlob.CreateInStream(lwInStrm);
    //     Result := HttpResponseMessage.Content.ReadAs(lwInStrm);
    //     // tofile := 'data.json';
    //     // if DownloadFromStream(lwInStrm, 'Dialog', 'Folder', 'File', tofile) then
    //     //     Message('Descargado');
    //     System.CopyStream(pwContentResponse, lwInStrm);
    //     // Check reponse status
    //     IF NOT HttpResponseMessage.IsSuccessStatusCode THEN BEGIN
    //         lwErrText := ProcessMessage(HttpClient, HttpResponseMessage, Response);
    //         //DUDA
    //         // HttpClient.DeleteAsync(HttpResponseMessage.RequestMessage.RequestUri);
    //         // HttpClient.Dispose;
    //         //DUDA
    //         lwErrText := 'GoCatlog:' + lwErrText;
    //         ERROR(lwErrText);
    //     END;
    //     Result := TRUE;
    //     //DUDA
    //     // HttpClient.Dispose;
    //     //HttpClient.Clear();
    //     //DUDA
    // END;
    //LOCAL PROCEDURE HttpGetClientStrm(VAR pwResponse: Text; pwUrl: Text) Result: Boolean;
    LOCAL PROCEDURE HttpGetClientStrm(VAR pwResponse: OutStream; pwUrl: Text) Result: Boolean;
    VAR
        // HttpResponseMessage: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.HttpResponseMessage";
        HttpResponseMessage: HttpResponseMessage;
        // HttpRequestMessage: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.HttpRequestMessage";
        HttpRequestMessage: HttpRequestMessage;
        // HttpClient: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.HttpClient";
        HttpClient: HttpClient;
        // HttpContent: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.HttpContent";
        // HttpTask: DotNet "'mscorlib'.System.Threading.Tasks.Task";
        HttpTask: HttpContent;
        Status: Integer;
        lwTimeOut: Integer;
        // lwInStrm: DotNet "'mscorlib'.System.IO.Stream";
        lwInStrm: InStream;
        // lwOutStrm: DotNet "'mscorlib'.System.IO.Stream";
        lwOutStrm: OutStream;
        // lwFile: DotNet "'mscorlib'.System.IO.File";
        lwFile: File;
        // lwFileMode: DotNet "'mscorlib'.System.IO.FileMode";
        lwFileName: Text;
        lwFileName2: Text;
        lwErrorText: Text;
        lwErrorText2: Text;
        Headers: HttpHeaders;
        //new
        DataCompression: Codeunit "Data Compression";
        tofile: Text;
        TempBlob: Codeunit "Temp Blob";
        datos: Text;
        lwInStrm2: InStream;
        pwUrl2: Text;
        //content: Text;
        Content: HttpContent;
        ContentHeaders: HttpHeaders;
        Texto: Text;
        TempBlobFile: Codeunit "Temp Blob";
        TextoError: Text;
        trimpwUrl: Text;
    BEGIN
        IF NOT LoadStup THEN EXIT;
        //pwUrl2 := 'http://192.168.3.206:7104/api/Llamadas/PostPasarelaCompResponse';        
        //pwUrl2 := 'http://192.168.3.159:7104/api/Llamadas/PostPasarelaCompResponse';
        pwUrl2 := wTLMStp.URL + ':' + format(wTLMStp.Port) + '/api/Llamadas/PostPasarelaCompResponse';
        Content.WriteFrom('{"uri": "' + pwUrl + '"}');
        Content.GetHeaders(ContentHeaders);
        ContentHeaders.Clear();
        ContentHeaders.Add('Content-Type', 'application/json');
        IF wTLMStp.TimeOut > 0 THEN HttpClient.Timeout := wTLMStp.TimeOut;
        Result := HttpClient.Post(pwUrl2, Content, HttpResponseMessage);
        Status := HttpResponseMessage.HttpStatusCode;
        // Check reponse status
        IF NOT HttpResponseMessage.IsSuccessStatusCode() THEN BEGIN
            //lwErrorText := HttpResponseMessage.Content.ReadAsStringAsync().Result;
            HttpResponseMessage.Content.ReadAs(lwErrorText);
            //pwResponse := lwErrorText;
            pwResponse.WriteText(lwErrorText);
            lwErrorText2 := ProcessMessage(HttpClient, HttpResponseMessage, lwErrorText, pwUrl2);
            //DUDA
            //HttpClient.DeleteAsync(HttpResponseMessage.RequestMessage.RequestUri);
            //HttpClient.Dispose;
            HttpClient.Clear();
            //DUDA
            ERROR(lwErrorText2);
        END;
        TempBlob.CreateInStream(lwInStrm);
        // trimpwUrl := pwUrl.Substring(1, 37);
        // if trimpwUrl = 'https://api.telematel.com/brands?&id=' then begin
        //     Message('Debug');
        //     //     Result := HttpResponseMessage.Content.ReadAs(TextoError);
        //     //     //TextoError := TextoError.Substring(2);
        //     //     Error(TextoError);
        // end;
        Result := HttpResponseMessage.Content.ReadAs(lwInStrm);
        // if pwUrl = 'https://api.telematel.com/brands?&id=98&format=json&v=1.0&token=157070716' then begin
        //     lwInStrm.ReadText(TextoError);
        //     Error(TextoError);
        // end;
        // tofile := 'updated_brands.json.gz';
        // if DownloadFromStream(lwInStrm, 'Dialog', 'Folder', 'File', tofile) then
        //Message('Descargado');
        // ;
        lwTimeOut := wTLMStp.TimeOut;
        IF lwTimeOut < 100000 THEN lwTimeOut := 100000; // 100 Segundos Timeout como minimo
        if Result then begin
            TempBlobFile.CreateOutStream(lwOutStrm);
            TempBlobFile.CreateInStream(lwInStrm2);
            // lwFileName := cFileMng.CreateAndWriteToServerFile('', GetFormat());
            // lwFile.WriteMode(true);
            // lwFile.Open(lwFileName);
            // lwFile.CreateOutStream(lwOutStrm);
            // lwFile.CreateInStream(lwInStrm2);
            if DataCompression.IsGZip(lwInStrm) then begin
                DataCompression.GZipDecompress(lwInStrm, pwResponse);
                /*//lwInStrm2.ReadText(Texto);
                    // datos := '';
                    // if Exists(lwFileName) then begin
                    tofile := 'updated_brands.json';
                    if DownloadFromStream(lwInStrm2, 'Dialog', 'Folder', 'File', tofile) then
                        //lwInStrm2.ReadText(Texto);
                        ;
                    // end;*/
            end
            else
                //pwResponse.Write(Result);
                //pwResponse.WriteText(Result);
                //lwFileName2 := lwFileName;
                CopyStream(pwResponse, lwInStrm);
            //pwResponse := ReadFromFile(lwFileName);
            //pwResponse.Write(lwOutStrm);
        end;
        /*IF FILE.EXISTS(lwFileName2) THEN
                FILE.ERASE(lwFileName2);
            IF FILE.EXISTS(lwFileName) THEN
                FILE.ERASE(lwFileName);*/
        //FALTA
        // if cFileMng.ServerFileExists(lwFileName2) then
        //     cFileMng.DeleteServerFile(lwFileName2);
        // if cFileMng.ServerFileExists(lwFileName) then
        //     cFileMng.DeleteServerFile(lwFileName);
        //FALTA
        // HttpClient.Dispose;
        //FALTA
    END;
    /*LOCAL PROCEDURE GetFileContent(pwType: Integer; pwValue: Variant; VAR pwResponse: Text) Result: Boolean;
    VAR
        lwFileName: Text;
        lwFileName2: Text;
        lwTxt: Text;
        lwUrl: Text;
    BEGIN
        // Carga Inicial
        // NOTA : Dada lo complejidad de descomprimir/separar ficheros TAR de UNIX optamos por descomprimirlos manualmente mediante un programa Externo
        // WinRaR por lo que una vez aqui se le supone todo descomprimido. La carga inicial debe de hacerse una sola vez.

        CLEAR(Result);
        CLEAR(pwResponse);
        IF wInitFolder = '' THEN
            EXIT(FALSE);

        CASE pwType OF
            wURLType::BrandIndex:
                lwFileName := AddFlnm(wInitFolder, 'updated_brands.json'); //  Brand Index
            wURLType::Brand:
                BEGIN
                    lwUrl := GetGOCATURL(pwType, pwValue);
                    lwUrl := AddURLParF(lwUrl);
                    Result := GetResponse(pwResponse, lwUrl);
                    EXIT(Result);
                END;
            wURLType::ProductIndex:
                lwFileName := AddFlnm(wInitFolder, STRSUBSTNO('%1\products.json', pwValue)); // Brand Products Index
            wURLType::Product:
                BEGIN // Product
                    lwTxt := FORMAT(pwValue);
                    lwFileName := AddFlnm(wInitFolder, DELCHR(COPYSTR(lwTxt, 1, 4), '<', '0'));
                    lwFileName := AddFlnm(lwFileName, COPYSTR(lwTxt, 5, 3));
                    lwFileName := AddFlnm(lwFileName, STRSUBSTNO('%1.json', pwValue));
                END;
        END;
        //   {
        //     // Si est  comprimido lo descomprimimos
        //     IF cFileMng.IsGZip(lwFileName) THEN
        //       GetDeComPressFile(lwFileName,lwFileName2)
        //     ELSE
        //       lwFileName2 := lwFileName;
        //   }

        Result := EXISTS(lwFileName);
        IF Result THEN
            pwResponse := ReadFromFile(lwFileName);
    END;*/
    //LOCAL PROCEDURE ProcessMessage(VAR HttpClient: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.HttpClient"; VAR HttpResponseMessage: DotNet "'System.Net.Http, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.System.Net.Http.HttpResponseMessage"; MessageRcvd: Text) NewMessage: Text;
    LOCAL PROCEDURE ProcessMessage(VAR HttpClient: HttpClient; VAR HttpResponseMessage: HttpResponseMessage; MessageRcvd: Text; pwUrl: Text) NewMessage: Text;
    VAR
        ResponseErr: TextConst ENU = 'An error occurred while requesting the API:\ \URL: %1\ \Status: %2\ \%3.', ESP = 'Se ha producido un error al realizar la petición al API:\ \URL: %1\ \Estado: %2\ \%3.';
        ResponseMsgErr: TextConst ENU = 'An error occurred while requesting the API:\ \%1.', ESP = 'Se ha producido un error al realizar la petición al API:\ \%1.';
        String: Text;
    BEGIN
        // FIX: Content.ReadAs devuelve un Boolean (si pudo leer o no) y el texto sale
        // por referencia en "String" - antes se pasaba el propio Boolean a STRSUBSTNO,
        // lo que mostraba "Sí"/"No" en vez del cuerpo de la respuesta.
        // FIX: se usa la URL real (pwUrl) en vez de HttpClient.GetBaseAddress, que
        // siempre está vacío porque nunca se establece.
        IF MessageRcvd = '' THEN BEGIN
            HttpResponseMessage.Content.ReadAs(String);
            IF String = '' THEN
                String := FORMAT(HttpResponseMessage.ReasonPhrase);
            EXIT(STRSUBSTNO(ResponseErr, pwUrl, HttpResponseMessage.HttpStatusCode, String));
        END;
        IF NOT (COPYSTR(MessageRcvd, 1, 1) IN ['{', '<']) THEN EXIT(STRSUBSTNO(ResponseMsgErr, MessageRcvd));
        NewMessage := MessageRcvd;
    END;
    //     //     LOCAL PROCEDURE DeCompressFile(pwSourceFile: Text; pwDestinationFile: Text) Result: Boolean;
    //     //     BEGIN
    //     //         // DeCompressFile
    //     //         Result := cCpmpGZIP.ServersideDecompress(pwSourceFile, pwDestinationFile);
    //     //     END;
    //     //     LOCAL PROCEDURE GetDeComPressFile(pwSourceFile: Text; VAR pwDestinationFile: Text) Result: Boolean;
    //     //     VAR
    //     //         lwServerDestFile: Text;
    //     //         lwServerFolder: Text;
    //     //         lwServerTempFile: Text;
    //     //         lwExt: Text;
    //     //     BEGIN
    //     //         // GetDeComPressFile
    //     //         pwSourceFile := DELCHR(pwSourceFile, '<>');
    //     //         IF pwSourceFile = '' THEN
    //     //             EXIT(FALSE);
    //     //         lwExt := cFileMng.GetExtension(pwSourceFile);
    //     //         pwDestinationFile := DELCHR(pwDestinationFile, '<>');
    //     //         IF pwDestinationFile = '' THEN
    //     //             pwDestinationFile := 'DECOMPRESSED';
    //     //         pwDestinationFile := cFileMng.GetFileNameWithoutExtension(pwDestinationFile);
    //     //         pwDestinationFile := cFileMng.CombinePath(cFileMng.GetDirectoryName(pwSourceFile), STRSUBSTNO('%1.%2', pwDestinationFile, lwExt));
    //     //         IF FILE.EXISTS(pwDestinationFile) THEN
    //     //             FILE.ERASE(pwDestinationFile);
    //     //         Result := DeCompressFile(pwSourceFile, pwDestinationFile);
    //     //     END;
    LOCAL PROCEDURE GetFormat(): Text[20];
    BEGIN
        EXIT('json');
    END;

    LOCAL PROCEDURE AddURLParF(prUrl: Text) Result: Text;
    BEGIN
        // AddURLParF
        prUrl := DELCHR(prUrl, '<>');
        IF prUrl = '' THEN EXIT;
        Result := prUrl;
        Result += '&format=' + GetFormat;
        Result := AddURLPar(Result);
    END;

    LOCAL PROCEDURE AddURLPar(prUrl: Text) Result: Text;
    BEGIN
        // AddURLParF
        prUrl := DELCHR(prUrl, '<>');
        IF prUrl = '' THEN EXIT;
        LoadStup();
        Result := prUrl;
        IF wTLMStp."GOC Version" <> '' THEN Result += '&v=' + wTLMStp."GOC Version";
        Result += '&token=' + wTLMStp.HashCode;
    END;
    // LOCAL PROCEDURE ReadFromFile(pwFilename: Text) Result: Text;
    // VAR
    //     //lwFile: DotNet "'mscorlib'.System.IO.File";
    //     lwFile: File;
    // BEGIN
    //     // if Exists(pwFilename) then
    //     //     Error('Existe el archivo ' + pwFilename) else
    //     //     Error('No Existe el archivo ' + pwFilename);
    //     //Result := lwFile.ReadAllText(pwFilename);
    //     lwFile.Open(pwFilename);
    //     lwFile.Read(Result);
    // END;
    //     //     LOCAL PROCEDURE OpenClientFile() Result: Text;
    //     //     BEGIN
    //     //         // OpenClientFile
    //     //         // Para Desarrollo Y Test
    //     //         // Devuelve el nombre del archivo en Servidor
    //     //         Result := cFileMng.UploadFile('Subir Archivo', '');
    //     //     END;
    LOCAL PROCEDURE LoadStup() Result: Boolean;
    BEGIN
        // LoadStup
        IF NOT wTLMStp.Loaded THEN BEGIN
            wTLMStp.GET();
            wTLMStp.Loaded := TRUE;
            IF wTLMStp.Activo THEN BEGIN
                wTLMStp.TESTFIELD(HashCode);
                wTLMStp.TESTFIELD("Items Serie"); // Comprobamos que se haya configurado la nueva serie de articulos
                wTLMStp.TESTFIELD("Inventory Posting");
                wTLMStp.TESTFIELD("Gen. Prod. Posting");
            END;
        END;
        Result := wTLMStp.Activo;
    END;

    LOCAL PROCEDURE LoadStup2(VAR pwTLMStp: Record "Telematel Setup") Result: Boolean;
    BEGIN
        // LoadStup2
        wTLMStp := pwTLMStp;
        wTLMStp.Loaded := TRUE;
        IF wTLMStp.Activo THEN BEGIN
            wTLMStp.TESTFIELD(HashCode);
            wTLMStp.TESTFIELD("Items Serie"); // Comprobamos que se haya configurado la nueva serie de articulos
            wTLMStp.TESTFIELD("Inventory Posting");
            wTLMStp.TESTFIELD("Gen. Prod. Posting");
        END;
        Result := wTLMStp.Activo;
    END;

    LOCAL PROCEDURE GetValue(VAR pwcJMng: Codeunit "JSON Manager"; pwIndx: Integer; pwIdNode: Text; VAR pwValue: Variant) Result: Boolean;
    BEGIN
        CLEAR(pwValue);
        IF pwIndx > 0 THEN
            Result := pwcJMng.GetAObjValue(pwIndx - 1, pwIdNode, pwValue) // Los Array Json son Base 0
        ELSE
            Result := pwcJMng.GetObjValue(pwIdNode, pwValue);
    END;

    LOCAL PROCEDURE GetValText(VAR pwcJMng: Codeunit "JSON Manager"; pwIndx: Integer; pwIdNode: Text; VAR pwValue: Text; pwJustWhole: Boolean; MAXLEN: Integer) Result: Boolean;
    VAR
        lwValue: Variant;
        lwTExt2: Text;
        lwMax: Integer;
    BEGIN
        // pwJustWhole -> Unicamente se aplicar  el valor si la longitud es suficiente. Si es false se truncar  el texto
        pwValue := '';
        Result := GetValue(pwcJMng, pwIndx, pwIdNode, lwValue);
        IF Result THEN Result := lwValue.ISTEXT;
        IF Result THEN BEGIN
            lwTExt2 := lwValue;
            lwMax := MAXSTRLEN(pwValue);
            IF pwJustWhole THEN BEGIN
                IF MAXLEN >= STRLEN(lwTExt2) THEN
                    pwValue := lwTExt2
                ELSE
                    Result := FALSE;
            END
            ELSE
                pwValue := COPYSTR(lwTExt2, 1, MAXLEN);
        END;
        IsOk(Result);
    END;

    LOCAL PROCEDURE GetValInt(VAR pwcJMng: Codeunit "JSON Manager"; pwIndx: Integer; pwIdNode: Text; VAR pwValue: Integer) Result: Boolean;
    VAR
        lwValue: Variant;
        lwText: Text;
    BEGIN
        CLEAR(pwValue);
        Result := GetValue(pwcJMng, pwIndx, pwIdNode, lwValue);
        IF Result THEN Result := lwValue.ISINTEGER OR lwValue.ISBIGINTEGER;
        IF Result THEN
            pwValue := lwValue
        ELSE IF lwValue.ISTEXT THEN BEGIN
            lwText := lwValue;
            Result := EVALUATE(pwValue, lwText, 9);
        END;
        IsOk(Result);
    END;

    LOCAL PROCEDURE GetValCode20(VAR pwcJMng: Codeunit "JSON Manager"; pwIndx: Integer; pwIdNode: Text; VAR pwValue: Code[20]) Result: Boolean;
    VAR
        lwValue: Variant;
        lwText: Text;
    BEGIN
        CLEAR(pwValue);
        Result := GetValue(pwcJMng, pwIndx, pwIdNode, lwValue);
        IF Result THEN Result := lwValue.ISTEXT;
        IF Result THEN BEGIN
            lwText := lwValue;
            Result := MAXSTRLEN(pwValue) >= STRLEN(lwText);
        END;
        IF IsOk(Result) THEN pwValue := lwText;
    END;

    LOCAL PROCEDURE GetValCode40(VAR pwcJMng: Codeunit "JSON Manager"; pwIndx: Integer; pwIdNode: Text; VAR pwValue: Code[40]) Result: Boolean;
    VAR
        lwValue: Variant;
        lwText: Text;
    BEGIN
        CLEAR(pwValue);
        Result := GetValue(pwcJMng, pwIndx, pwIdNode, lwValue);
        IF Result THEN Result := lwValue.ISTEXT;
        IF Result THEN BEGIN
            lwText := lwValue;
            Result := MAXSTRLEN(pwValue) >= STRLEN(lwText);
        END;
        IF IsOk(Result) THEN pwValue := lwValue;
    END;

    LOCAL PROCEDURE GetValDec(VAR pwcJMng: Codeunit "JSON Manager"; pwIndx: Integer; pwIdNode: Text; VAR pwValue: Decimal) Result: Boolean;
    VAR
        lwValue: Variant;
        lwText: Text;
    BEGIN
        CLEAR(pwValue);
        Result := GetValue(pwcJMng, pwIndx, pwIdNode, lwValue);
        IF Result THEN Result := lwValue.ISDECIMAL;
        IF Result THEN
            pwValue := lwValue
        ELSE IF lwValue.ISTEXT THEN BEGIN
            lwText := lwValue;
            Result := EVALUATE(pwValue, lwText, 9);
        END;
        IsOk(Result);
    END;

    LOCAL PROCEDURE GetValBool(VAR pwcJMng: Codeunit "JSON Manager"; pwIndx: Integer; pwIdNode: Text; VAR pwValue: Boolean) Result: Boolean;
    VAR
        lwValue: Variant;
        lwText: Text;
    BEGIN
        CLEAR(pwValue);
        Result := GetValue(pwcJMng, pwIndx, pwIdNode, lwValue);
        IF Result THEN Result := lwValue.ISBOOLEAN;
        IF Result THEN
            pwValue := lwValue
        ELSE IF lwValue.ISTEXT THEN BEGIN
            lwText := lwValue;
            Result := EVALUATE(pwValue, lwText, 9);
        END;
        IsOk(Result);
    END;

    LOCAL PROCEDURE GetValDate(VAR pwcJMng: Codeunit "JSON Manager"; pwIndx: Integer; pwIdNode: Text; VAR pwValue: Date) Result: Boolean;
    VAR
        lwValue: Variant;
        lwText: Text;
    BEGIN
        CLEAR(pwValue);
        Result := GetValue(pwcJMng, pwIndx, pwIdNode, lwValue);
        IF Result THEN Result := lwValue.ISDATE;
        IF Result THEN
            pwValue := lwValue
        ELSE IF lwValue.ISTEXT THEN BEGIN
            lwText := lwValue;
            Result := EVALUATE(pwValue, lwText, 9);
        END;
        IsOk(Result);
    END;

    LOCAL PROCEDURE GetValDT(VAR pwcJMng: Codeunit "JSON Manager"; pwIndx: Integer; pwIdNode: Text; VAR pwValue: DateTime) Result: Boolean;
    VAR
        lwValue: Variant;
        lwDate: Date;
        lwTime: Time;
        lwText: Text;
    BEGIN
        // GetValDT (Date Time)
        // El Datetime Json lo devuelve como una cadena
        // OJO: Aqui el Evaluate No hacemos en XML 9. Eso es as¡ ya que el formado XML en Nav utiliza el formato UTC :
        // 2003-04-05T03:35:55.553Z - Que No es el utiliza Go Cataloc - ISO 8601
        // Lo que hacemos es formatear separadamente Date y Time
        CLEAR(pwValue);
        Result := GetValue(pwcJMng, pwIndx, pwIdNode, lwValue);
        IF Result THEN Result := lwValue.ISTEXT;
        IF Result THEN BEGIN
            lwText := lwValue;
            Result := EVALUATE(lwDate, COPYSTR(lwText, 1, 10), 9);
            IF Result THEN Result := EVALUATE(lwTime, COPYSTR(lwText, 11), 9);
            IF Result THEN pwValue := CREATEDATETIME(lwDate, lwTime);
            IsOk(Result);
        END;
    END;

    LOCAL PROCEDURE IsOk(pwOk: Boolean) Result: Boolean;
    BEGIN
        // Devuevel el mismo valor que le pasamos
        // Pero se guarda en wOk si todos los valores han sido Ok
        wOK := wOK AND pwOk;
        Result := pwOk;
    END;
    //     //     LOCAL PROCEDURE GetResult() Result: Boolean;
    //     //     BEGIN
    //     //         Result := wOK;
    //     //     END;
    LOCAL PROCEDURE InitResult();
    BEGIN
        //InitResult
        wOK := TRUE;
    END;

    PROCEDURE GetPrecio(prArt: Record "Telematel Articulos"; pwDate: Date) Result: Decimal;
    VAR
        lrPrec: Record "Telematel Precios Articulo";
    BEGIN
        CLEAR(Result);
        CLEAR(lrPrec);
        IF BuscaPrecio2(prArt.Id, pwDate, '', prArt."Base Unit of Measure", lrPrec) THEN Result := GecCalPrince('', pwDate, lrPrec);
    END;
    //     PROCEDURE BuscaPrecio(prPurchHeader: Record "Purchase Header"; prPurchLine: Record "Purchase Line"; VAR prPrec: Record "Telematel Precios Articulo") ok: Boolean;
    //     VAR
    //         lwDate: Date;
    //     BEGIN
    //         // BuscaPrecio
    //         ok := FALSE;
    //         IF prPurchLine."Id Articulo Marca TLM" = 0 THEN
    //             EXIT;
    //         lwDate := GetPurchDate(prPurchHeader);
    //         ok := BuscaPrecio2(prPurchLine."Id Articulo Marca TLM", lwDate, prPurchHeader."Pay-to Vendor No.", prPurchLine."Unit of Measure", prPrec);
    //     END;
    LOCAL PROCEDURE BuscaPrecio2(pwIdArt: Integer; pwDate: Date; pwVendor: Code[20]; pwUnid: Code[10]; VAR prPrec: Record "Telematel Precios Articulo") Result: Boolean;
    VAR
        lrArt: Record "Telematel Articulos";
        lrUnItm: Record 5404;
        lrConv: Record "GOCAT Arts. Conversion";
        lwUnid2: Code[10];
    BEGIN
        // BuscaPrecio
        Result := FALSE;
        IF pwIdArt = 0 THEN EXIT;
        lrArt.GET(pwIdArt);
        IF pwUnid = '' THEN BEGIN
            lrArt.CALCFIELDS("Base Unit of Measure");
            pwUnid := lrArt."Base Unit of Measure";
        END;
        CLEAR(prPrec);
        prPrec.SETCURRENTKEY(IdArticulo, "Fecha Inicio", "Fecha Final");
        prPrec.ASCENDING(FALSE);
        prPrec.SETRANGE(IdArticulo, pwIdArt);
        prPrec.SETFILTER("Fecha Inicio", '<=%1', pwDate);
        prPrec.SETFILTER("Fecha Final", '>=%1|%2', pwDate, 0D);
        // JPT Se solicito no filtrar por cantidad minima
        //prPrec.SETFILTER("Minimum Quantity", '<=%1', prPurchLine.Quantity);
        // Buscamos primero por el proveedor, si no lo encuentra buscamos por proveedor en blanco
        IF pwVendor <> '' THEN BEGIN
            prPrec.SETRANGE(Vendor, pwVendor);
            Result := NOT prPrec.ISEMPTY;
        END;
        IF NOT Result THEN BEGIN
            prPrec.SETFILTER(Vendor, '=%1', '');
            Result := NOT prPrec.ISEMPTY;
        END;
        lwUnid2 := pwUnid;
        IF Result THEN BEGIN
            prPrec.SETRANGE("Unit of Measure Code", pwUnid);
            Result := prPrec.FINDFIRST;
            IF NOT Result THEN BEGIN
                // Buscamos la correspondencia de unidades
                //lwUnid2 := GetUNiNav(lrArt.CodigoUnidad, lrArt."Unidad UN20");//-#450540
                //+#450540
                IF GetUNiNav(lrArt.CodigoUnidad, lrArt."Unidad UN20") <> Text007Lbl THEN
                    lwUnid2 := GetUNiNav(lrArt.CodigoUnidad, lrArt."Unidad UN20")
                ELSE
                    ERROR(Text008Lbl, lrArt.CodArt, lrArt."Id Marca", lrArt.CodigoUnidad, lrArt."Unidad UN20");
                //-#450540
                IF lwUnid2 <> pwUnid THEN BEGIN
                    prPrec.SETRANGE("Unit of Measure Code", lwUnid2);
                    Result := prPrec.FINDFIRST;
                END;
            END;
            IF NOT Result THEN BEGIN
                prPrec.SETRANGE("Unit of Measure Code");
                Result := prPrec.FINDFIRST;
                IF Result THEN lwUnid2 := prPrec."Unit of Measure Code";
            END;
            IF Result THEN BEGIN
                IF prPrec.Quantity = 0 THEN prPrec.Quantity := 1;
                IF (lwUnid2 <> pwUnid) THEN BEGIN
                    CLEAR(lrConv);
                    lrConv.SETCURRENTKEY("Art Id");
                    lrConv.SETRANGE("Art Id", pwIdArt);
                    lrConv.SETRANGE("Unit of Measure Code", lwUnid2);
                    IF lrConv.FINDFIRST THEN
                        prPrec.Quantity := prPrec.Quantity * lrConv.Valor
                    ELSE IF lrUnItm.GET(lrArt."No.Item", lwUnid2) THEN IF lrUnItm."Qty. per Unit of Measure" <> 0 THEN prPrec.Quantity := prPrec.Quantity / lrUnItm."Qty. per Unit of Measure";
                END;
            END;
        END;
    END;
    //     //     PROCEDURE BuscaDto(prPurchHeader: Record "Purchase Header"; prPurchLine: Record "Purchase Line"; VAR prDto: Record "Telematel Descuentos") OK: Boolean;
    //     //     VAR
    //     //         lwDate: Date;
    //     //     BEGIN
    //     //         OK := FALSE;
    //     //         IF prPurchLine.Type <> prPurchLine.Type::Item THEN
    //     //             EXIT;
    //     //         IF prPurchLine."Id Marca TLM" = 0 THEN
    //     //             EXIT;
    //     //         IF prPurchHeader."Document Type" IN [prPurchHeader."Document Type"::Invoice, prPurchHeader."Document Type"::"Credit Memo"] THEN
    //     //             lwDate := prPurchHeader."Posting Date"
    //     //         ELSE
    //     //             lwDate := prPurchHeader."Order Date";
    //     //         OK := BuscaDto2(lwDate, prPurchHeader."Buy-from Vendor No.", prPurchLine, prDto);
    //     //     END;
    //     //     PROCEDURE BuscaDto2(pwDate: Date; pwCodVendor: Code[20]; prPurchLine: Record "Purchase Line"; VAR prDto: Record "Telematel Descuentos") OK: Boolean;
    //     //     VAR
    //     //         lrArt: Record "Telematel Articulos";
    //     //         lwArtFind: Boolean;
    //     //         lwN: Integer;
    //     //     BEGIN
    //     //         //BuscaDto2
    //     //         OK := FALSE;
    //     //         IF prPurchLine.Type <> prPurchLine.Type::Item THEN
    //     //             EXIT;
    //     //         IF prPurchLine."Id Marca TLM" = 0 THEN
    //     //             EXIT;
    //     //         // Miramos si se encuentra primero por articulo, luego por por serie y finalmente por grupo descuento telematel
    //     //         CLEAR(prDto);
    //     //         prDto.SETCURRENTKEY("Id Marca", "Tipo Descuento", "Starting Date", "Ending Date");
    //     //         prDto.ASCENDING(FALSE);
    //     //         prDto.SETRANGE("Id Marca", prPurchLine."Id Marca TLM");
    //     //         prDto.SETFILTER("Starting Date", '<=%1', pwDate);
    //     //         prDto.SETFILTER("Ending Date", '>=%1|%2', pwDate, 0D);
    //     //         prDto.SETRANGE(Vendor, pwCodVendor);
    //     //         FOR lwN := 1 TO 2 DO BEGIN // Dos pasadas: una con proveedor y la otra con proveedor en blanco
    //     //             IF lwN = 2 THEN
    //     //                 prDto.SETFILTER(Vendor, '=%1', '');
    //     //             // Por Articulo
    //     //             IF NOT OK THEN BEGIN
    //     //                 prDto.SETRANGE("Tipo Descuento", prDto."Tipo Descuento"::Articulo);
    //     //                 prDto.SETRANGE("Id Dto", prPurchLine."Id Articulo Marca TLM");
    //     //                 OK := prDto.FINDFIRST;
    //     //             END;
    //     //             IF NOT OK THEN BEGIN
    //     //                 CLEAR(lrArt);
    //     //                 lwArtFind := lrArt.GET(prPurchLine."Id Articulo Marca TLM");
    //     //             END;
    //     //             // Por serie Estel
    //     //             IF NOT OK THEN BEGIN
    //     //                 IF lwArtFind THEN BEGIN
    //     //                     prDto.SETRANGE("Id Dto");
    //     //                     prDto.SETRANGE("Tipo Descuento", prDto."Tipo Descuento"::Serie);
    //     //                     prDto.SETRANGE("Codigo Dto", lrArt."Series Estel");
    //     //                     OK := prDto.FINDFIRST;
    //     //                 END;
    //     //             END;
    //     //             // Finalmente por Descuento Marca
    //     //             IF NOT OK THEN BEGIN
    //     //                 IF lwArtFind THEN BEGIN
    //     //                     prDto.SETRANGE("Codigo Dto");
    //     //                     prDto.SETRANGE("Tipo Descuento", prDto."Tipo Descuento"::Marca);
    //     //                     // En GOCAT deja de venir el codigo de descuento Telematel - Ahora ser  Por marca - JPT 09/06/2020
    //     //                     //prDto.SETRANGE("Id Dto"        , lrArt."Id Dto TLM");
    //     //                     OK := prDto.FINDFIRST;
    //     //                 END;
    //     //             END;
    //     //             IF OK THEN
    //     //                 lwN := 2;
    //     //         END;
    //     //     END;
    //     //     PROCEDURE FindPurchLinePrice(prPurchHeader: Record "Purchase Header"; VAR prPurchLine: Record "Purchase Line") ok: Boolean;
    //     //     VAR
    //     //         lrPrec: Record "Telematel Precios Articulo";
    //     //         lwPc: Decimal;
    //     //     BEGIN
    //     //         // FindPurcLinePrice
    //     //         ok := FALSE;
    //     //         IF prPurchLine."Id Articulo Marca TLM" = 0 THEN
    //     //             EXIT;
    //     //         ok := BuscaPrecio(prPurchHeader, prPurchLine, lrPrec);
    //     //         IF ok THEN BEGIN
    //     //             lwPc := GecCalPrince('', GetPurchDate(prPurchHeader), lrPrec);
    //     //             prPurchLine.VALIDATE("Direct Unit Cost", lwPc);
    //     //             prPurchLine."Minimum Quantity" := lrPrec."Minimum Quantity";
    //     //         END
    //     //         ELSE BEGIN
    //     //             prPurchLine.VALIDATE("Direct Unit Cost", 0);
    //     //             prPurchLine."Minimum Quantity" := 0;
    //     //         END;
    //     //     END;
    //     //     PROCEDURE FindPurchLineLineDisc(prPurchHeader: Record "Purchase Header"; VAR prPurchLine: Record "Purchase Line") OK: Boolean;
    //     //     VAR
    //     //         lrDto: Record "Telematel Descuentos";
    //     //     BEGIN
    //     //         // FindPurchLineLineDisc
    //     //         OK := BuscaDto(prPurchHeader, prPurchLine, lrDto);
    //     //         IF OK THEN
    //     //             prPurchLine."Line Discount %" := lrDto."Line Discount %"
    //     //         ELSE
    //     //             prPurchLine."Line Discount %" := 0;
    //     //     END;
    LOCAL PROCEDURE GecCalPrince(pwCurrency: Code[10]; pwDate: Date; VAR prPrec: Record "Telematel Precios Articulo") Result: Decimal;
    VAR
        lrCurrency: Record 4;
        lrCurrExchRate: Record 330;
    BEGIN
        CLEAR(lrCurrency);
        IF prPrec.Quantity = 0 THEN prPrec.Quantity := 1;
        Result := prPrec.Precio / prPrec.Quantity;
        IF pwCurrency = '' THEN
            lrCurrency.InitRoundingPrecision
        ELSE BEGIN
            lrCurrency.GET(pwCurrency);
            lrCurrency.TESTFIELD("Amount Rounding Precision");
        END;
        IF pwCurrency <> prPrec."Unit of Measure Code" THEN Result := lrCurrExchRate.ExchangeAmtFCYToFCY(pwDate, prPrec."Currency Code", pwCurrency, Result);
        Result := ROUND(Result, lrCurrency."Unit-Amount Rounding Precision")
    END;
    //     //     LOCAL PROCEDURE GetPurchDate(prPurchHeader: Record "Purchase Header") Result: Date;
    //     //     BEGIN
    //     //         IF prPurchHeader."Document Type" IN [prPurchHeader."Document Type"::Invoice, prPurchHeader."Document Type"::"Credit Memo"] THEN
    //     //             Result := prPurchHeader."Posting Date"
    //     //         ELSE
    //     //             Result := prPurchHeader."Order Date";
    //     //         IF Result = 0D THEN
    //     //             Result := WORKDATE;
    //     //     END;
    LOCAL PROCEDURE InitCntrls();
    BEGIN
        CLEAR(wCntArt);
        wTimeCtrl := wTLMStp."Tiempo Maximo" > 0;
        IF wTimeCtrl THEN BEGIN
            IF wTLMStp."Init Process" = 0DT THEN BEGIN
                wTLMStp."Init Process" := CURRENTDATETIME;
                wTLMStp."Ent Process" := 0DT;
            END;
            IF wTLMStp."Ent Process" = 0DT THEN wTLMStp."Ent Process" := wTLMStp."Init Process" + (wTLMStp."Tiempo Maximo" * 60000);
            wToTime := wTLMStp."Ent Process";
        END;
    END;

    LOCAL PROCEDURE UpdateArtImage(prArt: Record "Telematel Articulos"; pwURL: Text);
    VAR
        lrRef: Record "GOCAT Referencias Articulos";
    BEGIN
        // UpdateArtImage
        UpdateArRef(prArt, lrRef.Tipo::Imagen.AsInteger(), pwURL)
    END;

    LOCAL PROCEDURE UpdateArWebPage(prArt: Record "Telematel Articulos"; pwURL: Text);
    VAR
        lrRef: Record "GOCAT Referencias Articulos";
    BEGIN
        // UpdateArWebPage
        UpdateArRef(prArt, lrRef.Tipo::WebPage.AsInteger(), pwURL)
    END;

    LOCAL PROCEDURE UpdateArRef(prArt: Record "Telematel Articulos"; pwTipo: Integer; pwURL: Text);
    VAR
        lrRef: Record "GOCAT Referencias Articulos";
        lwIdArt: Integer;
    BEGIN
        // UpdateArRef
        // #321633 JPT 03/08/2020 - Inlcusion de im genes de Articulos
        lwIdArt := prArt.Id;
        pwURL := DELCHR(pwURL, '<>');
        IF (lwIdArt <> 0) AND (pwTipo > 0) THEN BEGIN
            CLEAR(lrRef);
            lrRef.SETCURRENTKEY("Id Articulo");
            lrRef.SETRANGE(Tipo, pwTipo);
            lrRef.SETRANGE("Id Articulo", lwIdArt);
            IF NOT lrRef.ISEMPTY THEN lrRef.DELETEALL;
            IF (pwURL <> '') AND (STRLEN(pwURL) <= MAXSTRLEN(lrRef.Url)) THEN BEGIN
                CLEAR(lrRef);
                lrRef.Tipo := "GoCat Referencia Tipo".FromInteger(pwTipo);
                lrRef."Id Articulo" := lwIdArt;
                lrRef.Url := pwURL;
                lrRef.INSERT;
            END;
        END;
    END;

    PROCEDURE ShowArtImage(pwIdArt: Integer);
    VAR
        lrRef: Record "GOCAT Referencias Articulos";
    BEGIN
        // ShowArtImage
        ShowArRef(pwIdArt, lrRef.Tipo::Imagen.AsInteger());
    END;

    PROCEDURE ShowArtWebPage(pwIdArt: Integer);
    VAR
        lrRef: Record "GOCAT Referencias Articulos";
    BEGIN
        // ShowArtWebPage
        ShowArRef(pwIdArt, lrRef.Tipo::WebPage.AsInteger());
    END;

    LOCAL PROCEDURE ShowArRef(pwIdArt: Integer; pwTipo: Integer) Result: Boolean;
    VAR
        lrRef: Record "GOCAT Referencias Articulos";
        lwURL: Text;
    BEGIN
        // ShowArRef
        // #321633 JPT 03/08/2020 - Inlcusion de im genes de Articulos
        IF (pwIdArt <> 0) AND (pwTipo > 0) THEN BEGIN
            CLEAR(lrRef);
            lrRef.SETCURRENTKEY("Id Articulo");
            lrRef.SETRANGE(Tipo, pwTipo);
            lrRef.SETRANGE("Id Articulo", pwIdArt);
            Result := lrRef.FINDFIRST;
            IF Result THEN BEGIN
                lwURL := DELCHR(lrRef.Url, '<>');
                Result := lwURL <> '';
                IF Result THEN HYPERLINK(lwURL);
            END;
        END;
    END;

    LOCAL PROCEDURE HaveArtRef(pwIdArt: Integer; pwTipo: Integer) Result: Boolean;
    VAR
        lrRef: Record "GOCAT Referencias Articulos";
    BEGIN
        // HaveRef
        // #321633 JPT 03/08/2020 - Inlcusion de im genes de Articulos
        CLEAR(Result);
        IF (pwIdArt <> 0) AND (pwTipo > 0) THEN BEGIN
            CLEAR(lrRef);
            lrRef.SETCURRENTKEY("Id Articulo");
            lrRef.SETRANGE(Tipo, pwTipo);
            lrRef.SETRANGE("Id Articulo", pwIdArt);
            Result := NOT lrRef.ISEMPTY;
        END;
    END;

    PROCEDURE HaveArtImage(pwIdArt: Integer) Result: Boolean;
    VAR
        lrRef: Record "GOCAT Referencias Articulos";
    BEGIN
        //  HaveArtImage
        // #321633 JPT 03/08/2020 - Inlcusion de im genes de Articulos
        Result := HaveArtRef(pwIdArt, lrRef.Tipo::Imagen.AsInteger());
    END;

    PROCEDURE HaveArtWebPage(pwIdArt: Integer) Result: Boolean;
    VAR
        lrRef: Record "GOCAT Referencias Articulos";
    BEGIN
        //  HaveArtWebPage
        // #321633 JPT 03/08/2020 - Inlcusion de im genes de Articulos
        Result := HaveArtRef(pwIdArt, lrRef.Tipo::WebPage.AsInteger());
    END;
    // LOCAL PROCEDURE AddFlnm(pwFilename: Text; pwAdd: Text) Result: Text;
    // BEGIN
    //     //   {
    //     //   Result := DELCHR(pwFilename,'<>');
    //     //   pwAdd := DELCHR(pwAdd,'<>');
    //     //   IF Result <> '' THEN
    //     //     IF Result[STRLEN(Result)] = '\' THEN
    //     //       Result := DELSTR(Result, STRLEN(Result));
    //     //   IF pwAdd <> '' THEN BEGIN
    //     //     IF pwAdd[1] = '\' THEN
    //     //       pwAdd := COPYSTR(pwAdd,2);
    //     //     Result += '\' + pwAdd;
    //     //   END;
    //     //   }
    //     Result := cFileMng.CombinePath(pwFilename, pwAdd);
    // END;
}
