Codeunit 58009 UpdateDataTelematelAuto
//C_58007_UpdateDataTelematel
{
    trigger OnRun()
    BEGIN
        UpdateCnc();
    END;

    VAR
        wSetup: Record "Telematel Setup";
        cGestGoCat: Codeunit GestGoCatalog;
        wIntento: Integer;
        wTimeCtrl: Boolean;

    LOCAL PROCEDURE UpdateCnc();
    VAR
        lwOK: Boolean;
    BEGIN
        wSetup.GET();
        IF GUIALLOWED THEN
            wSetup.TESTFIELD(Activo)
        ELSE 
        IF NOT wSetup.Activo THEN EXIT;
        DeleteLog();
        wSetup."Init Process" := 0DT;
        wSetup."Ent Process" := 0DT;
        wTimeCtrl := wSetup."Tiempo Maximo" > 0;
        IF wTimeCtrl THEN BEGIN
            wSetup."Init Process" := CURRENTDATETIME;
            wSetup."Ent Process" := wSetup."Init Process" + (wSetup."Tiempo Maximo" * 60000);
        END;
        IF wSetup."Numero Intentos" < 1 THEN wSetup."Numero Intentos" := 1;
        CLEAR(wIntento);
        CLEAR(lwOK);
        REPEAT
            wIntento += 1;
            lwOK := NewUpdate();
            IF NOT lwOK THEN lwOK := wSetup."Numero Intentos" <= wIntento;
            IF (NOT lwOK) AND wTimeCtrl THEN lwOK := CURRENTDATETIME >= wSetup."Ent Process";
            IF (NOT lwOK) AND (wSetup."Tiempo entre Intentos" > 0) THEN SLEEP(wSetup."Tiempo entre Intentos" * 1000);
        UNTIL lwOK;
    END;

    LOCAL PROCEDURE DeleteLog();
    VAR
        lrLog: Record "Go Catalog Connection Log";
        lwDias: Integer;
        lwDateRf: Date;
        lwToday: Date;
    BEGIN
        IF FORMAT(wSetup."Log Duration") = '' THEN EXIT;
        lwToday := TODAY;
        lwDateRf := CALCDATE(wSetup."Log Duration", lwToday);
        lwDias := ABS(lwDateRf - lwToday);
        lwDateRf := lwToday - lwDias;
        CLEAR(lrLog);
        lrLog.SETFILTER(Date, '<%1', lwDateRf);
        IF NOT lrLog.ISEMPTY THEN lrLog.DELETEALL();
    END;

    LOCAL PROCEDURE NewUpdate() Result: Boolean;
    VAR
        lrLog: Record "Go Catalog Connection Log";
        lwError: Boolean;
        wInitTime: DateTime;
        wEndTime: DateTime;
        wErrorMessage: Text;

    BEGIN
        wInitTime := CURRENTDATETIME;
        wErrorMessage := '';
        CLEAR(lrLog);
        lrLog.Date := TODAY;
        lrLog.InitCnt := wInitTime;
        lrLog.Intento := wIntento;
        lrLog.INSERT();
        COMMIT();
        CLEAR(cGestGoCat);
        lwError := NOT cGestGoCat.RUN(wSetup);
        IF lwError THEN BEGIN
            wErrorMessage := GETLASTERRORTEXT;
            IF GUIALLOWED THEN MESSAGE(wErrorMessage);
        END;
        wEndTime := CURRENTDATETIME;
        lrLog.EndCnt := wEndTime;
        lrLog.Duration := ROUND(wEndTime - wInitTime, 1000);
        IF lwError THEN BEGIN
            lrLog.Result := lrLog.Result::Error;
            lrLog.ErrorText := COPYSTR(wErrorMessage, 1, MAXSTRLEN(lrLog.ErrorText));
            CODEUNIT.RUN(CODEUNIT::ErrorMailTelematel, lrLog); // Send Mail
        END
        ELSE
            lrLog.Result := lrLog.Result::Ok;
        lrLog.MODIFY();
        Result := lrLog.Result = lrLog.Result::Ok;
    END;
    //     BEGIN
    //     {
    //       #321633Mejoras Modulo Go Catalog
    //     }
    //     END.
    // }
}
