Codeunit 58006 "Funciones Estel"
//C_58006_FuncionesEstel
{
//   OBJECT-PROPERTIES
//   {
//     Date=28/01/22;
//     Time=14:17:47;
//     Modified=Yes;
//     Version List=Dynasoft,#83979,#90575,#103165,#247959,#341475;
//   }
//   PROPERTIES
//   {
//     Permissions=TableData 21=rimd,
//                 TableData 112=rimd,
//                 TableData 169=rimd;
//     OnRun=BEGIN
//           END;
//   }
//   CODE
//   {
//     VAR
//       wWindow@1000000001 : DotNet "'Microsoft.VisualBasic, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.Microsoft.VisualBasic.Interaction" RUNONCLIENT;
//       cFileMng@1000000000 : Codeunit 419;
//     [EventSubscriber(Codeunit,90,OnBeforePostPurchaseDoc)]
//     LOCAL PROCEDURE OnBeforePostPurchaseDoc@1000000000(VAR PurchaseHeader@1000000000 : Record 38);
//     BEGIN
//       ControlFacturaDuplicada(PurchaseHeader);
//     END;
//     [EventSubscriber(Codeunit,90,OnAfterPostPurchaseDoc)]
//     LOCAL PROCEDURE OnAfterPostPurchaseDoc@1000000008(VAR PurchaseHeader@1000000000 : Record 38;VAR GenJnlPostLine@1000000001 : Codeunit 12;PurchRcpHdrNo@1000000002 : Code[20];RetShptHdrNo@1000000003 : Code[20];PurchInvHdrNo@1000000004 : Code[20];PurchCrMemoHdrNo@1000000005 : Code[20]);
//     VAR
//       PurPostingNo@1000000006 : Code[20];
//     BEGIN
//       ModifyJobLedgerEntryPurch(PurchaseHeader,PurchInvHdrNo,PurchCrMemoHdrNo);//#83979
//     END;
//     [EventSubscriber(Codeunit,80,OnAfterPostSalesDoc)]
//     LOCAL PROCEDURE OnAfterPostSalesDoc@1000000009(VAR SalesHeader@1000000000 : Record 36;VAR GenJnlPostLine@1000000001 : Codeunit 12;SalesShptHdrNo@1000000002 : Code[20];RetRcpHdrNo@1000000003 : Code[20];SalesInvHdrNo@1000000004 : Code[20];SalesCrMemoHdrNo@1000000005 : Code[20]);
//     BEGIN
//       ModifyJobLedgerEntrySales(SalesHeader,SalesInvHdrNo,SalesCrMemoHdrNo);//#83979
//       InitNuevaFechaSales(SalesHeader,SalesInvHdrNo,SalesCrMemoHdrNo);//#341475
//     END;
//     [EventSubscriber(Table,36,OnAfterValidateEvent,"No Proyecto")]
//     LOCAL PROCEDURE OnAfterValSalesNoProyecto@1000000006(VAR Rec@1000000000 : Record 36;VAR xRec@1000000001 : Record 36;CurrFieldNo@1000000002 : Integer);
//     BEGIN
//       ModifyJobLedgerEntryNoProyecto(Rec."Posting Date",Rec."No.");
//     END;
//     [EventSubscriber(Table,38,OnAfterValidateEvent,"No Proyecto")]
//     LOCAL PROCEDURE OnAfterValPurchaseNoProyecto@1000000004(VAR Rec@1000000000 : Record 38;VAR xRec@1000000001 : Record 38;CurrFieldNo@1000000002 : Integer);
//     BEGIN
//       ModifyJobLedgerEntryNoProyecto(Rec."Posting Date",Rec."No.");
//     END;
//     [EventSubscriber(Table,112,OnAfterModifyEvent)]
//     LOCAL PROCEDURE OnAfterModifySalesInvHeader@1000000011(VAR Rec@1000000000 : Record 112;VAR xRec@1000000001 : Record 112;RunTrigger@1000000002 : Boolean);
//     BEGIN
//       //INI #341475
//       IF Rec."Nueva fecha"<>xRec."Nueva fecha" THEN
//         ModifyCustLedgEntryNuevaFecha(Rec."Nueva fecha",Rec."Cust. Ledger Entry No.");
//       //FIN #341475
//     END;
//     LOCAL PROCEDURE ControlFacturaDuplicada@1000000002(VAR prCabComp@1000000000 : Record 38);
//     VAR
//       lwImp@1000000001 : Decimal;
//       lrCabFactC@1000000002 : Record 122;
//       lwFecha@1000000003 : Date;
//       lText001@1000000004 : TextConst 'ESP=Est  a punto de registrar una factura para el proveedor %1 %2 por un importe de %3. En el £ltimo a¤o ya se ha registrado al menos una factura con el mismo importe para este proveedor. Es posible que se est‚ duplicando la factura.';
//       lwText@1000000005 : Text;
//       lText002@1000000006 : TextConst 'ESP=­ADVERTENCIA!';
//       lText003@1000000007 : TextConst 'ESP=¨Desea continuar?';
//     BEGIN
//       //ControlFacturaDuplicada
//       // #83104 JPT 02/08/2017 ControlFacturaDuplicada. Control y aviso cuando hay una factura por el mismo importe y proveedor en el £ltimo a¤o
//       IF prCabComp."Document Type" <> prCabComp."Document Type"::Invoice THEN
//         EXIT;
//       // Buscamos el total del importe de la factura
//       prCabComp.CALCFIELDS("Amount Including VAT");
//       lwImp := prCabComp."Amount Including VAT";
//       // Buscamos todas las facturas del proveedor en el ultimo a¤o y vamos comparando su importe
//       CLEAR(lrCabFactC);
//       lrCabFactC.SETCURRENTKEY("Buy-from Vendor No.");
//       lrCabFactC.ASCENDING(FALSE);
//       lrCabFactC.SETRANGE("Buy-from Vendor No.", prCabComp."Buy-from Vendor No.");
//       lwFecha := CALCDATE('<-1Y>', prCabComp."Posting Date");
//       lrCabFactC.SETFILTER("Posting Date", '>=%1', lwFecha);
//       IF lrCabFactC.FINDSET THEN BEGIN
//         REPEAT
//           lrCabFactC.CALCFIELDS("Amount Including VAT");
//           IF lrCabFactC."Amount Including VAT" = lwImp THEN BEGIN
//             lwText := STRSUBSTNO(lText001, prCabComp."Buy-from Vendor No.", prCabComp."Buy-from Vendor Name", lwImp);
//             lwText := lwText + GetReturnText + lText003;
//             //IF NOT CONFIRM(lwText, FALSE) THEN
//             IF GetMsgBox(lwText,lText002,49) <> 1 THEN
//               ERROR(''); // Rollback
//             EXIT; // En cualquier caso solo queremos que aparezca una vez
//           END;
//         UNTIL lrCabFactC.NEXT=0;
//       END;
//     END;
//     PROCEDURE GetImput@1000000020(pwCaption@1000000000 : Text;pwTitle@1000000001 : Text;VAR pwValor@1000000002 : Text) : Text;
//     BEGIN
//       //GetImput
//       pwValor := wWindow.InputBox(pwCaption,pwTitle,pwValor,-1,-1);
//       EXIT(pwValor);
//     END;
//     PROCEDURE GetMsgBox@1000000005(pwMessage@1000000000 : Text;pwCaption@1000000001 : Text;pwButtons@1000000002 : Integer) wResult : Integer;
//     BEGIN
//       // Para documentacion ver
//       // https://msdn.microsoft.com/es-es/library/139z2azd(v=vs.90).aspx
//       wResult := wWindow.MsgBox(pwMessage, pwButtons, pwCaption);
//     END;
//     PROCEDURE GetReturnText@1000000003() wResult : Text;
//     VAR
//       LF@1000000000 : Char;
//       CR@1000000001 : Char;
//     BEGIN
//       // Devuelve retorno de carro y salto de linea
//       LF := 10;
//       CR := 13;
//       wResult := FORMAT(CR,0,'<CHAR>') + FORMAT(LF,0,'<CHAR>');
//     END;
//     LOCAL PROCEDURE ModifyJobLedgerEntryPurch@1000000012(PurchaseHeader@1000000007 : Record 38;PurchInvHdrNo@1000000003 : Code[20];PurchCrMemoHdrNo@1000000000 : Code[20]);
//     VAR
//       JobLedgerEntry@1000000001 : Record 169;
//     BEGIN
//       //#83979 #90575
//       JobLedgerEntry.SETCURRENTKEY("Document No.","Posting Date");
//       IF NOT PurchaseHeader.Invoice THEN
//         EXIT;
//       IF (PurchInvHdrNo='') AND (PurchCrMemoHdrNo = '') THEN
//         EXIT;
//       CASE PurchaseHeader."Document Type" OF
//         PurchaseHeader."Document Type"::Invoice, PurchaseHeader."Document Type"::Order :
//           JobLedgerEntry.SETRANGE("Document No.",PurchInvHdrNo);
//         PurchaseHeader."Document Type"::"Credit Memo", PurchaseHeader."Document Type"::"Return Order" :
//           JobLedgerEntry.SETRANGE("Document No.",PurchCrMemoHdrNo);
//       END;
//       JobLedgerEntry.SETRANGE("Posting Date",PurchaseHeader."Posting Date");
//       IF NOT JobLedgerEntry.FINDSET THEN
//         EXIT;
//       JobLedgerEntry.MODIFYALL("Vendor No.",PurchaseHeader."Buy-from Vendor No.");
//       //#83979 #90575
//     END;
//     LOCAL PROCEDURE ModifyJobLedgerEntrySales@1000000001(SalesHeader@1000000007 : Record 36;SalesInvHdrNo@1000000003 : Code[20];SalesCrMemoHdrNo@1000000000 : Code[20]);
//     VAR
//       JobLedgerEntry@1000000001 : Record 169;
//     BEGIN
//       //#83979 #90575
//       JobLedgerEntry.SETCURRENTKEY("Document No.","Posting Date");
//       IF NOT SalesHeader.Invoice THEN
//         EXIT;
//       IF (SalesInvHdrNo = '') AND (SalesCrMemoHdrNo = '') THEN
//         EXIT;
//       CASE SalesHeader."Document Type" OF
//         SalesHeader."Document Type"::Invoice, SalesHeader."Document Type"::Order :
//           JobLedgerEntry.SETRANGE("Document No.",SalesInvHdrNo);
//         SalesHeader."Document Type"::"Credit Memo", SalesHeader."Document Type"::"Return Order" :
//           JobLedgerEntry.SETRANGE("Document No.",SalesCrMemoHdrNo);
//       END;
//       JobLedgerEntry.SETRANGE("Posting Date",SalesHeader."Posting Date");
//       IF NOT JobLedgerEntry.FINDSET THEN
//         EXIT;
//       JobLedgerEntry.MODIFYALL("Customer No.",SalesHeader."Sell-to Customer No.");
//       //#83979 #90575
//     END;
//     LOCAL PROCEDURE ModifyJobLedgerEntryNoProyecto@1000000007("Posting Date"@1000000001 : Date;DocumentNo@1000000002 : Code[20]);
//     VAR
//       JobLedgerEntry@1000000000 : Record 169;
//     BEGIN
//     END;
//     PROCEDURE CreaLimpiaFolder@1000000025(lwPath@1000000000 : Text[1024]);
//     VAR
//       lrFiles@1000000001 : TEMPORARY Record 823;
//       lwOK@1000000003 : Boolean;
//     BEGIN
//       // CreaLimpiaFolder
//       // Creamos la carpeta si no existe
//       IF NOT cFileMng.ServerDirectoryExists(lwPath) THEN
//         cFileMng.ServerCreateDirectory(lwPath);
//       // La limpiamos de archivos anteriores
//       CLEAR(lrFiles);
//       cFileMng.GetServerDirectoryFilesList(lrFiles, lwPath);
//       IF lrFiles.FIND('-') THEN BEGIN
//         REPEAT
//           lwOK := cFileMng.DeleteServerFile(lrFiles.Name);
//         UNTIL lrFiles.NEXT=0;
//       END;
//     END;
//     LOCAL PROCEDURE InitNuevaFechaSales@1000000010(SalesHeader@1000000007 : Record 36;SalesInvHdrNo@1000000003 : Code[20];SalesCrMemoHdrNo@1000000000 : Code[20]);
//     VAR
//       SalesInvoiceHdr@1000000001 : Record 112;
//     BEGIN
//       //INI #341475
//       IF NOT SalesHeader.Invoice THEN
//         EXIT;
//       IF SalesCrMemoHdrNo <> '' THEN
//         EXIT;
//       IF (SalesInvHdrNo = '') AND (SalesCrMemoHdrNo = '') THEN
//         EXIT;
//       IF SalesHeader."Document Type" = SalesHeader."Document Type"::Invoice THEN BEGIN
//         SalesInvoiceHdr.GET(SalesInvHdrNo);
//         SalesInvoiceHdr."Nueva fecha":=SalesInvoiceHdr."Due Date";
//         SalesInvoiceHdr.MODIFY;
//       END;
//       //FIN #341475
//     END;
//     LOCAL PROCEDURE ModifyCustLedgEntryNuevaFecha@1000000013(InvNuevaFecha@1000000000 : Date;CustLENo@1000000001 : Integer);
//     VAR
//       CustLedgerEntry@1000000002 : Record 21;
//     BEGIN
//       //INI #341475
//       CustLedgerEntry.GET(CustLENo);
//       CustLedgerEntry."Nueva fecha":=InvNuevaFecha;
//       CustLedgerEntry.MODIFY;
//       //FIN #341475
//       //ALXIA
//     END;
//     [EventSubscriber(Table,36,OnAfterValidateEvent,"Posting Date")]
//     LOCAL PROCEDURE T36OnModifyPostingDate@1000000014(VAR Rec@1000000000 : Record 36;VAR xRec@1000000001 : Record 36;CurrFieldNo@1000000002 : Integer);
//     BEGIN
//       IF Rec."Posting Date" <> 0D THEN BEGIN
//         Rec."SII Operation Date" := Rec."Posting Date";
//         Rec.MODIFY;
//       END;
//     END;
//     [EventSubscriber(Table,38,OnAfterValidateEvent,"Posting Date")]
//     LOCAL PROCEDURE T38OnModifyPostingDate@1000000015(VAR Rec@1000000000 : Record 38;VAR xRec@1000000001 : Record 38;CurrFieldNo@1000000002 : Integer);
//     BEGIN
//       IF Rec."Posting Date" <> 0D THEN BEGIN
//         Rec."SII Operation Date" := Rec."Posting Date";
//         Rec.MODIFY;
//       END;
//     END;
//     [EventSubscriber(Codeunit,80,OnBeforePostSalesDoc)]
//     LOCAL PROCEDURE C80OnBeforePostSalesDoc@1000000016(VAR SalesHeader@1000000000 : Record 36);
//     BEGIN
//       IF SalesHeader."Posting Date" <> SalesHeader."SII Operation Date" THEN BEGIN
//         SalesHeader."SII Operation Date" := SalesHeader."Posting Date";
//         SalesHeader.MODIFY;
//       END;
//     END;
//     [EventSubscriber(Codeunit,90,OnBeforePostPurchaseDoc)]
//     LOCAL PROCEDURE C90OnBeforePostPurchaseDoc@1000000017(VAR PurchaseHeader@1000000000 : Record 38);
//     BEGIN
//       IF PurchaseHeader."Posting Date" <> PurchaseHeader."SII Operation Date" THEN BEGIN
//         PurchaseHeader."SII Operation Date" := PurchaseHeader."Posting Date";
//         PurchaseHeader.MODIFY;
//       END;
//     END;
//     BEGIN
//     {
//       JPT 02/08/2017 Codeunit creada para funciones generales personalizadas para Estel
//       #83104  JPT 02/08/2017 ControlFacturaDuplicada. Control y aviso cuando hay una factura por el mismo importe y proveedor en el £ltimo a¤o
//       #83979  KOS 09/08/2017 Se crea una funcion para rellenar el nuevo campo de Vendor No. en la tabla de Lineas de proyecto (169)
//       #90575  JDJ 31/08/2017 Hemos modificado la funcion que rellena el campo Vendor No. para que no vuelva a cambiar el proveedor de todos los una misma fecha.
//       #103165 KOS 07/12/2017 Se crea una funcion para rellenar el nuevo campo de Vendor No. (T169) con los pedidos.
//       #103165 JDJ 12/12/2017 Se comentan funciones que rellenaban el campo de Vendor No. con los pedidos, ahora se hace al registrar el diario.
//       #341475 KOS 21/10/2020 Se a¤ade la recogida de "Due Date" para el campo "Nueva Fecha" despues de los eventos de registro(NFFV) y modificacion(NFMC) de FV
//         //En MX es la CU50013 Event Management Estel
//     }
//     END.
//   }
}
