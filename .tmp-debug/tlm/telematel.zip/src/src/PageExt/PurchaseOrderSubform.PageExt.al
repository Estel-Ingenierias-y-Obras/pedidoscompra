pageextension 58001 "Purchase Order Subform" extends "Purchase Order Subform"
//P_Ext_58001_Purchase_Order_Subform
{
    layout
    {
        addafter("No.")
        {
            field("Codigo Marca TLM"; Rec."Codigo Marca TLM")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the value of the Codigo Marca TLM field.';
            }
            field("Ref. Articulo Marca TLM"; Rec."Ref. Articulo Marca TLM")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the value of the Ref. Articulo Marca TLM field.';

                trigger OnValidate()
                begin
                    SetEditPrice();
                end;

                trigger OnDrillDown()
                var
                    lrArtClas: Record "Clasificacion Articulos";
                    lrArt: Record "Telematel Articulos";
                begin
                    CLEAR(lrArtClas);
                    IF Rec."Id Articulo Marca TLM" <> 0 THEN lrArtClas."Id Articulo" := Rec."Id Articulo Marca TLM";
                    IF PAGE.RUNMODAL(PAGE::"Articulos x Clasificacion", lrArtClas) = ACTION::LookupOK THEN BEGIN
                        Rec.Type := Rec.Type::Item;
                        IF lrArt.GET(lrArtClas."Id Articulo") THEN Rec.VALIDATE("No.", lrArt.GetItemCode());
                        //Rec.VALIDATE("Ref. Articulo Marca TLM", "Ref. Articulo Marca TLM");
                        //VALIDATE("No.",  lrArtClas."Cod Item");
                    END;
                    SetEditPrice(); // #336441
                end;
            }
        }
    }
    VAR
        CFunComp: Codeunit "Funciones Compras";

    LOCAL PROCEDURE SetEditPrice();
    BEGIN
        // #336441 Bloqueo de Precios y Descuentos en Pedidos Compra
        CFunComp.BloqueaPrecLinPedido(Rec);
    END;
}
