pageextension 58002 "Purchase Lines" extends "Purchase Lines"
{
    layout
    {
        addafter("No.")
        {
            field("Codigo Marca TLM"; Rec."Codigo Marca TLM")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the value of the Codigo Marca TLM field.';
            }
            field("Ref. Articulo Marca TLM"; Rec."Ref. Articulo Marca TLM")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the value of the Ref. Articulo Marca TLM field.';
                trigger OnDrillDown()
                var
                    lrArtClas: Record "Clasificacion Articulos";
                begin
                    CLEAR(lrArtClas);
                    IF Rec."Id Articulo Marca TLM" <> 0 THEN
                        lrArtClas."Id Articulo" := Rec."Id Articulo Marca TLM";
                    PAGE.RUN(PAGE::"Articulos x Clasificacion", lrArtClas);

                end;
            }
        }
    }
}
