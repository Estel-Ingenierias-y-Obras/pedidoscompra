tableextension 58007 "User Setup" extends "User Setup"
//T_Ext_58007_User_Setup
{
    fields
    {
        field(50012; "Editar Prec/Dto Pedido Compra"; Boolean)
        {
            CaptionML = ESP = 'Editar Precio/Dto. Pedido Compra';
            Description = '#336441. Permite Editar El precio y Dto en una l¡nea pedido aunque el Producto no tenga "Precio Libre"';
        }
    }
}
