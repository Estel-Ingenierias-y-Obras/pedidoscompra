tableextension 58001 Purchase_Line_Gocat extends "Purchase Line"
{
    fields
    {
        field(58000; "Id Marca TLM"; Integer)
        {
            TableRelation = "Telematel Marcas".Id;

            trigger OnValidate()
            var
                lrMarca: record "Telematel Marcas";
                lwId: Integer;
            begin
                lwId := "Id Marca TLM";
                IF "Id Marca TLM" <> xRec."Id Marca TLM" THEN VALIDATE("Id Articulo Marca TLM", 0);
                "Id Marca TLM" := lwId;
                IF "Id Marca TLM" = 0 THEN
                    "Codigo Marca TLM" := ''
                ELSE BEGIN
                    CLEAR(lrMarca);
                    IF lrMarca.GET("Id Marca TLM") THEN "Codigo Marca TLM" := lrMarca.Codigo;
                END;
            end;
        }
        field(58001; "Codigo Marca TLM"; code[30])
        {
            trigger OnValidate()
            var
                lrMarca: record "Telematel Marcas";
            begin
                IF "Codigo Marca TLM" = '' THEN
                    VALIDATE("Id Marca TLM", 0)
                ELSE BEGIN
                    CLEAR(lrMarca);
                    lrMarca.SETCURRENTKEY(Codigo);
                    lrMarca.SETRANGE(Codigo, "Codigo Marca TLM");
#pragma warning disable AA0181
                    lrMarca.FindSet();
#pragma warning restore AA0181
                    VALIDATE("Id Marca TLM", lrMarca.Id)
                END;
            end;

            trigger OnLookup()
            var
                lrMarca: record "Telematel Marcas";
            begin
                CLEAR(lrMarca);
                lrMarca.SETCURRENTKEY(Codigo);
                lrMarca.GET("Id Marca TLM");
                IF PAGE.RUNMODAL(0, lrMarca) = ACTION::LookupOK THEN VALIDATE("Id Marca TLM", lrMarca.Id);
            end;
        }
        field(58002; "Id Articulo Marca TLM"; Integer)
        {
            TableRelation = "Telematel Articulos".Id;

            trigger OnValidate()
            var
                lrArt: Record "Telematel Articulos";
            begin
                IF "Id Articulo Marca TLM" = 0 THEN
                    VALIDATE("No.", '')
                ELSE BEGIN
                    CLEAR(lrArt);
                    lrArt.GET("Id Articulo Marca TLM");
                    VALIDATE("No.", lrArt.GetItemCode());
                END;
            end;
        }
        field(58003; "Ref. Articulo Marca TLM"; text[40])
        {
            trigger OnValidate()
            var
                lrArt: record "Telematel Articulos";
                aux: Text[40];
            begin
                aux := "Ref. Articulo Marca TLM";
                IF "Ref. Articulo Marca TLM" = '' THEN
                    VALIDATE("No.", '')
                ELSE BEGIN
                    CLEAR(lrArt);
                    lrArt.SETCURRENTKEY("Id Marca", Referencia);
                    lrArt.SETRANGE(Referencia, "Ref. Articulo Marca TLM");
                    lrArt.FIND('-');
                    IF lrArt.COUNT > 1 THEN BEGIN
                        IF PAGE.RUNMODAL(0, lrArt) <> ACTION::LookupOK THEN 
                            "Ref. Articulo Marca TLM" := xRec."Ref. Articulo Marca TLM";
                            EXIT;
                        END;
                    VALIDATE(Type, Type::Item);
                    VALIDATE("No.", lrArt.GetItemCode());
                    "Ref. Articulo Marca TLM" := aux;
                END;
            end;

            trigger OnLookup()
            var
                lrArt: record "Telematel Articulos";
            begin
                CLEAR(lrArt);
                lrArt.SETCURRENTKEY("Id Marca", Referencia);
                lrArt.SETRANGE(Activo, TRUE);
                lrArt.GET("Id Articulo Marca TLM");
                IF PAGE.RUNMODAL(0, lrArt) = ACTION::LookupOK THEN BEGIN
                    Type := Type::Item;
                    VALIDATE("No.", lrArt.GetItemCode());
                END;
            end;
        }
        //         field(58004; "Minimum Quantity"; decimal)
        //         {
        //             Caption = 'Cantidad Mínima';
        //             MinValue = 0;
        //             Editable = False;
        //         }
        //         field(58005; "Codigo Tasa Producto"; Code[20])
        //         {
        //             TableRelation = "Tasa Producto".Codigo;
        //         }
        //         field(58006; "Id Precio Tasa Producto"; Integer)
        //         {
        //             TableRelation = "Importe Tasa Producto".Id WHERE("Codigo Tasa/Prod" = FIELD("Codigo Tasa Producto"));
        //         }
        modify("No.")
        {
            trigger OnAfterValidate()
            var
                Item: Record Item;
            begin
                if type = type::Item then 
                    if Item.get("No.") then begin
                        //DUDA
                        //"Nº producto importado" := Item."Cód. Prod.  fabricante";
                        //DUDA
                        // **** PRYTO-2016/159 JPT 20/06/16 Productos Telematel
                        "Id Marca TLM" := Item."Id Marca TLM";
                        "Codigo Marca TLM" := Item."Marca TLM";
                        "Id Articulo Marca TLM" := Item."Id Articulo TLM";
                        "Ref. Articulo Marca TLM" := Item."Referencia TLM";
                        IF "Vendor Item No." = '' THEN 
                            IF STRLEN("Ref. Articulo Marca TLM") <= MAXSTRLEN("Vendor Item No.") THEN VALIDATE("Vendor Item No.", "Ref. Articulo Marca TLM");
                    end;
            end;
        }
    }
    //     PROCEDURE SigLinNo() No: Integer;
    //     VAR
    //         lrLines: Record 39;
    //         lwNo: Integer;
    //     BEGIN
    //         // SigLinNo
    //         CLEAR(lwNo);
    //         CLEAR(lrLines);
    //         lrLines.SETRANGE("Document Type", "Document Type");
    //         lrLines.SETRANGE("Document No.", "Document No.");
    //         lrLines.ASCENDING(FALSE);
    //         IF lrLines.FIND('-') THEN
    //             lwNo := lrLines."Line No.";
    //         No := lwNo + 10000;
    //     END;
}
